#include "CameraLightingRenderWidgets.h"
#include "Widgets/SOverlay.h"
#include "CameraLightingPipelineTools.h"
#include "Widgets/Notifications/SProgressBar.h"
#include "Widgets/Layout/SExpandableArea.h"
#include "CameraLightingStyle.h"
#include "CameraLightingMinimalWidgets.h"
#include "CameraLightingRenderService.h"
#include "CameraLightingEditorModule.h"
#include "CameraLightingCapture.h"
#include "Editor.h"
#include "GameFramework/Actor.h"
#include "HAL/PlatformProcess.h"
#include "DesktopPlatformModule.h"
#include "IDesktopPlatform.h"
#include "Widgets/Input/SButton.h"
#include "Widgets/Input/SNumericEntryBox.h"
#include "Widgets/Input/SEditableTextBox.h"
#include "Widgets/Input/SCheckBox.h"
#include "Widgets/Input/SComboButton.h"
#include "Widgets/Layout/SBorder.h"
#include "Widgets/Layout/SBox.h"
#include "Widgets/Layout/SScrollBox.h"
#include "Widgets/Layout/SWrapBox.h"
#include "Widgets/Text/STextBlock.h"
#include "Framework/MultiBox/MultiBoxBuilder.h"
#include "Styling/AppStyle.h"

namespace
{
 UCameraLightingRenderService* Service() {return GEditor ? GEditor->GetEditorSubsystem<UCameraLightingRenderService>() : nullptr;}
 FLinearColor Background(){return FLinearColor::FromSRGBColor(FColor(26,29,37));}
 FLinearColor Toolbar(){return FLinearColor::FromSRGBColor(FColor(23,26,33));}
 FLinearColor Field(){return FLinearColor::FromSRGBColor(FColor(37,39,46));}
 FLinearColor Blue(){return FLinearColor::FromSRGBColor(FColor(0,120,255));}
 TSharedRef<STextBlock> Text(const FString& Value,int32 Size=10)
 {return SNew(STextBlock).Text(FText::FromString(Value)).Font(CameraLightingStyle::Font(Size)).ColorAndOpacity(FLinearColor(.89f,.91f,.94f));}
 TSharedRef<SWidget> Button(const FString& Label,TFunction<void()> Action,bool bPrimary=false)
 {return SNew(SButton).ButtonStyle(&CameraLightingStyle::Button()).ButtonColorAndOpacity(FLinearColor::FromSRGBColor(FColor(37,39,46))).ButtonColorAndOpacity(bPrimary?Blue():Field()).ContentPadding(FMargin(12,8)).HAlign(HAlign_Center)
  .OnClicked_Lambda([Action]{Action();return FReply::Handled();})[Text(Label)];}
 TSharedRef<SWidget> Chip(const FString& Label,TFunction<void()> Action,TFunction<bool()> IsActive)
 {return SNew(SButton).ButtonStyle(&CameraLightingStyle::Button()).ButtonColorAndOpacity(FLinearColor::FromSRGBColor(FColor(37,39,46))).ButtonColorAndOpacity_Lambda([IsActive]{return IsActive()?Blue():Field();}).ContentPadding(FMargin(11,8)).HAlign(HAlign_Center)
  .OnClicked_Lambda([Action]{Action();return FReply::Handled();})[Text(Label,9)];}
 TSharedRef<SWidget> Group(const FString& Label,TSharedRef<SWidget> Content)
 {return SNew(SVerticalBox)+SVerticalBox::Slot().AutoHeight().Padding(0,0,0,12)[Text(Label,9)]
  +SVerticalBox::Slot().AutoHeight()[Content];}
 TSharedRef<SWidget> OutputPath()
 {return SNew(SHorizontalBox)
  +SHorizontalBox::Slot().FillWidth(1)
  [SNew(SEditableTextBox).Style(&CameraLightingStyle::Field()).Text_Lambda([]{auto* S=Service();return FText::FromString(S?S->OutputDirectory:FString());})
   .ToolTipText(FText::FromString(TEXT("Render output location"))).OnTextCommitted_Lambda([](const FText& Value,ETextCommit::Type){if(auto* S=Service()){S->OutputDirectory=Value.ToString();S->PersistSettings();}})]
  +SHorizontalBox::Slot().AutoWidth().Padding(4,0)
  [SNew(SButton).ContentPadding(7).ToolTipText(FText::FromString(TEXT("Choose output location"))).OnClicked_Lambda([]{
   auto* S=Service();if(S)if(auto* Desktop=FDesktopPlatformModule::Get()) {FString Result;if(Desktop->OpenDirectoryDialog(nullptr,TEXT("Render output location"),S->OutputDirectory,Result)){S->OutputDirectory=Result;S->PersistSettings();}}
   return FReply::Handled();})[Text(TEXT("..."))]];}
 TSharedRef<SWidget> PrefixField()
 {return SNew(SBox).MinDesiredWidth(100)[SNew(SEditableTextBox).Style(&CameraLightingStyle::Field()).Text_Lambda([]{auto* S=Service();return FText::FromString(S?S->FilePrefix:FString());})
  .ToolTipText(FText::FromString(TEXT("Prefix for exported filenames"))).OnTextCommitted_Lambda([](const FText& Value,ETextCommit::Type){if(auto* S=Service()){S->FilePrefix=Value.ToString();S->PersistSettings();}})];}
 FString StateName(ECameraLightingJobState State)
 {switch(State){case ECameraLightingJobState::Waiting:return TEXT("Waiting");case ECameraLightingJobState::Rendering:return TEXT("Rendering");case ECameraLightingJobState::Completed:return TEXT("Completed");case ECameraLightingJobState::Failed:return TEXT("Failed");default:return TEXT("Canceled");}}
 FString FormatName(ECameraLightingImageFormat Format)
 {switch(Format){case ECameraLightingImageFormat::JPEG:return TEXT("JPEG");case ECameraLightingImageFormat::EXR:return TEXT("EXR");default:return TEXT("PNG");}}
 bool IsHistoryState(ECameraLightingJobState State)
 {return State==ECameraLightingJobState::Completed || State==ECameraLightingJobState::Failed || State==ECameraLightingJobState::Canceled;}
 TSharedRef<SWidget> FormatMenu()
 {FMenuBuilder Menu(true,nullptr);for(auto Value:{ECameraLightingImageFormat::PNG,ECameraLightingImageFormat::JPEG,ECameraLightingImageFormat::EXR})
  Menu.AddMenuEntry(FText::FromString(FormatName(Value)),FText(),FSlateIcon(),FUIAction(FExecuteAction::CreateLambda([Value]{if(auto* S=Service()){S->Format=Value;S->PersistSettings();}})));
  return Menu.MakeWidget();}
 TSharedRef<SWidget> QualityMenu()
 {FMenuBuilder Menu(true,nullptr);for(int32 Samples:{1,8,32,64})
  Menu.AddMenuEntry(FText::FromString(FString::Printf(TEXT("%d spatial samples"),Samples)),FText(),FSlateIcon(),FUIAction(FExecuteAction::CreateLambda([Samples]{if(auto* S=Service()){S->SpatialSamples=Samples;S->PersistSettings();}})));
  return Menu.MakeWidget();}
}

TSharedRef<SWidget> MakeCameraLightingRenderSettings(bool Batch)
{
 auto Row=SNew(SWrapBox).UseAllottedSize(true).InnerSlotPadding(FVector2D(10,8));
 Row->AddSlot()[Group(TEXT("Render template"),SNew(SBox).MinDesiredWidth(180)[MakeCameraLightingTemplateSelector()])];
 Row->AddSlot()[Group(TEXT("Check"),Button(TEXT("Preflight"),[]{GEditor->GetEditorSubsystem<UCameraLightingPipelineTools>()->InspectCurrentCamera();FCameraLightingEditorModule::OpenTab(FCameraLightingEditorModule::PipelineTabId);}))];
 Row->AddSlot()[Group(TEXT("Advanced"),Button(TEXT("Full MRQ..."),[]{Service()->EditFullPreset();}))];
 Row->AddSlot()[Group(TEXT("Template"),Button(TEXT("Edit template..."),[]{Service()->EditTemplate();}))];
 auto Number=[Row](const FString& N,TFunction<float()> Get,TFunction<void(float)> Set,float Min,float Max){Row->AddSlot()[Group(N,SNew(SBox).WidthOverride(80)[MakeCameraLightingDragNumber(Get,Set,Min,Max,1,0)])];};
 Number(TEXT("Width"),[]{return float(Service()->Width);},[](float V){Service()->SetImageWidth(V);},64,16384);Number(TEXT("Height"),[]{return float(Service()->Height);},[](float V){Service()->SetImageHeight(V);},64,16384);
 Number(TEXT("Spatial"),[]{return float(Service()->GetTemplateSamples());},[](float V){Service()->SetTemplateSamples(V);},1,4096);Number(TEXT("Temporal"),[]{return float(Service()->GetTemplateTemporalSamples());},[](float V){Service()->SetTemplateTemporalSamples(V);},1,4096);
 Row->AddSlot()[Group(TEXT("Format"),SNew(SComboButton).ButtonStyle(&CameraLightingStyle::Button()).ButtonColorAndOpacity(Field()).ContentPadding(8).OnGetMenuContent_Lambda([]{return FormatMenu();}).ButtonContent()[SNew(STextBlock).Text_Lambda([]{return FText::FromString(FormatName(Service()->Format));}).Font(CameraLightingStyle::Font(9))])];
 auto Extra=SNew(SWrapBox).UseAllottedSize(true).InnerSlotPadding(FVector2D(10,8));
 Extra->AddSlot()[Group(TEXT("Warm-up (both)"),SNew(SBox).WidthOverride(85)[MakeCameraLightingDragNumber([]{return float(Service()->GetTemplateWarmup());},[](float V){Service()->SetTemplateWarmup(V);},0,600,1,0)])];
 for(bool Reflections:{false,true})Extra->AddSlot()[SNew(SBox).Visibility_Lambda([]{auto* T=Service()->GetCurrentTemplate();return T && T->Renderer==ECameraLightingRenderer::Lumen?EVisibility::Visible:EVisibility::Collapsed;})[Group(Reflections?TEXT("Reflections"):TEXT("Lumen lighting"),SNew(SBox).WidthOverride(85)[MakeCameraLightingDragNumber([Reflections]{auto* T=Service()->GetCurrentTemplate();return T?(Reflections?T->ReflectionQuality:T->FinalGatherQuality):1.f;},[Reflections](float V){if(auto* T=Service()->GetCurrentTemplate()){T->Modify();if(Reflections)T->ReflectionQuality=V;else T->FinalGatherQuality=V;Service()->SaveTemplate();}},.25f,8,.1f,2)])]];
 Extra->AddSlot()[SNew(SBox).Visibility_Lambda([]{auto* T=Service()->GetCurrentTemplate();return T && T->Renderer==ECameraLightingRenderer::PathTracer?EVisibility::Visible:EVisibility::Collapsed;})[Group(TEXT("Max bounces"),SNew(SBox).WidthOverride(85)[MakeCameraLightingDragNumber([]{return float(Service()->GetCurrentTemplate()->MaxBounces);},[](float V){auto* T=Service()->GetCurrentTemplate();T->Modify();T->MaxBounces=V;Service()->SaveTemplate();},1,100,1,0)])]];
 Extra->AddSlot()[SNew(SBox).Visibility_Lambda([]{auto* T=Service()->GetCurrentTemplate();return T && T->Renderer==ECameraLightingRenderer::PathTracer?EVisibility::Visible:EVisibility::Collapsed;})[SNew(SCheckBox).IsChecked_Lambda([]{return Service()->GetCurrentTemplate()->bDenoise?ECheckBoxState::Checked:ECheckBoxState::Unchecked;}).OnCheckStateChanged_Lambda([](ECheckBoxState V){auto* T=Service()->GetCurrentTemplate();T->Modify();T->bDenoise=V==ECheckBoxState::Checked;Service()->SaveTemplate();})[Text(TEXT("Denoise"),9)]]];
 auto Body=SNew(SVerticalBox)+SVerticalBox::Slot().AutoHeight()[Row]+SVerticalBox::Slot().AutoHeight().Padding(0,8)[SNew(SExpandableArea).InitiallyCollapsed(true).HeaderContent()[Text(TEXT("Lighting, bounces & warm-up"),9)].BodyContent()[Extra]];
 if(Batch)Body->AddSlot().AutoHeight().Padding(0,4)[SNew(SHorizontalBox)+SHorizontalBox::Slot().FillWidth(1)[SNew(SCheckBox).IsChecked_Lambda([]{return Service()->bUseBatchSettings?ECheckBoxState::Checked:ECheckBoxState::Unchecked;}).OnCheckStateChanged_Lambda([](ECheckBoxState V){Service()->bUseBatchSettings=V==ECheckBoxState::Checked;Service()->PersistSettings();})[Text(TEXT("Use these MRQ settings for selected waiting jobs"),9)]]+SHorizontalBox::Slot().AutoWidth()[Button(TEXT("Apply now"),[]{Service()->ApplySettingsToSelectedJobs();})]];
 return SNew(SBorder).BorderImage(FAppStyle::GetBrush("WhiteBrush")).BorderBackgroundColor(Toolbar()).Padding(10)[Body];
}

TSharedRef<SWidget> MakeCameraLightingImagePanel()
{
 auto Numeric=[](TFunction<int32()> Get,TFunction<void(int32)> Set,int32 Min,int32 Max)->TSharedRef<SWidget>{return MakeCameraLightingDragNumber([Get]{return float(Get());},[Set](float Value){Set(FMath::RoundToInt(Value));},float(Min),float(Max),1,0);};
 auto Specific=SNew(SVerticalBox);
 // These concise rows switch live with the selected template. Advanced controls live behind the dots.
 Specific->AddSlot().AutoHeight().Padding(0,12)[SNew(SHorizontalBox)
 +SHorizontalBox::Slot().FillWidth(1)[Text(TEXT("Spatial samples"),9)]
 +SHorizontalBox::Slot().AutoWidth()[SNew(SBox).WidthOverride(100)[Numeric([]{return Service()?Service()->GetTemplateSamples():8;},[](int32 V){if(Service())Service()->SetTemplateSamples(V);},1,4096)]]];
 Specific->AddSlot().AutoHeight().Padding(0,0,0,12)[SNew(SHorizontalBox)
 +SHorizontalBox::Slot().FillWidth(1)[Text(TEXT("Temporal samples"),9)]
 +SHorizontalBox::Slot().AutoWidth()[SNew(SBox).WidthOverride(100)[Numeric([]{return Service()?Service()->GetTemplateTemporalSamples():1;},[](int32 V){if(Service())Service()->SetTemplateTemporalSamples(V);},1,4096)]]];
 auto LumenRow=[](const FString& Name,bool Reflections)->TSharedRef<SWidget>{return SNew(SHorizontalBox)
 +SHorizontalBox::Slot().FillWidth(1)[Text(Name,9)]
 +SHorizontalBox::Slot().AutoWidth()[SNew(SBox).WidthOverride(100)[MakeCameraLightingDragNumber([Reflections]{auto* T=Service()?Service()->GetCurrentTemplate():nullptr;return T?(Reflections?T->ReflectionQuality:T->FinalGatherQuality):1.f;},[Reflections](float V){if(auto* S=Service())if(auto* T=S->GetCurrentTemplate()){T->Modify();if(Reflections)T->ReflectionQuality=V;else T->FinalGatherQuality=V;S->SaveTemplate();}},.25f,8,.1f,2)]];};
 Specific->AddSlot().AutoHeight().Padding(0,0,0,12)[SNew(SBox).Visibility_Lambda([]{auto* T=Service()?Service()->GetCurrentTemplate():nullptr;return T && T->Renderer==ECameraLightingRenderer::Lumen?EVisibility::Visible:EVisibility::Collapsed;})[SNew(SVerticalBox)
 +SVerticalBox::Slot().AutoHeight().Padding(0,0,0,12)[LumenRow(TEXT("Lighting quality"),false)]
 +SVerticalBox::Slot().AutoHeight()[LumenRow(TEXT("Reflections"),true)]]];
 Specific->AddSlot().AutoHeight().Padding(0,0,0,12)[SNew(SBox).Visibility_Lambda([]{auto* T=Service()?Service()->GetCurrentTemplate():nullptr;return T && T->Renderer==ECameraLightingRenderer::PathTracer?EVisibility::Visible:EVisibility::Collapsed;})[SNew(SVerticalBox)
 +SVerticalBox::Slot().AutoHeight().Padding(0,0,0,12)[SNew(SHorizontalBox)+SHorizontalBox::Slot().FillWidth(1)[Text(TEXT("Max bounces"),9)]+SHorizontalBox::Slot().AutoWidth()[SNew(SBox).WidthOverride(100)[Numeric([]{auto* T=Service()?Service()->GetCurrentTemplate():nullptr;return T?T->MaxBounces:8;},[](int32 V){if(auto* S=Service())if(auto* T=S->GetCurrentTemplate()){T->Modify();T->MaxBounces=V;S->SaveTemplate();}},1,100)]]]
 +SVerticalBox::Slot().AutoHeight()[SNew(SCheckBox).IsChecked_Lambda([]{auto* T=Service()?Service()->GetCurrentTemplate():nullptr;return T && T->bDenoise?ECheckBoxState::Checked:ECheckBoxState::Unchecked;}).OnCheckStateChanged_Lambda([](ECheckBoxState V){if(auto* S=Service())if(auto* T=S->GetCurrentTemplate()){T->Modify();T->bDenoise=V==ECheckBoxState::Checked;S->SaveTemplate();}})[Text(TEXT("Denoise"),9)]]]];
 return SNew(SBorder).BorderImage(FAppStyle::GetBrush("WhiteBrush")).BorderBackgroundColor(Background()).Padding(0)
 [MakeCameraLightingArtPanel(SNew(SScrollBox)+SScrollBox::Slot()[SNew(SBox).MinDesiredWidth(280).MaxDesiredWidth(620)[SNew(SVerticalBox)
 +SVerticalBox::Slot().AutoHeight().Padding(0,0,0,14)[SNew(SHorizontalBox)
 +SHorizontalBox::Slot().FillWidth(1)[MakeCameraLightingTemplateSelector()]
 +SHorizontalBox::Slot().AutoWidth().Padding(6,0)[SNew(SComboButton).ButtonStyle(&CameraLightingStyle::Button()).ButtonColorAndOpacity(FLinearColor::FromSRGBColor(FColor(37,39,46))).HasDownArrow(false).ContentPadding(FMargin(10,4)).ToolTipText(FText::FromString(TEXT("Template settings")))
 .OnGetMenuContent_Lambda([]{FMenuBuilder Menu(true,nullptr);auto Add=[&](const TCHAR* Name,TFunction<void()> Action){Menu.AddMenuEntry(FText::FromString(Name),FText(),FSlateIcon(),FUIAction(FExecuteAction::CreateLambda([Action]{Action();})));};
 Add(TEXT("Edit template..."),[]{if(Service())Service()->EditTemplate();});Add(TEXT("Full MRQ settings..."),[]{if(Service())Service()->EditFullPreset();});Add(TEXT("Duplicate template"),[]{if(Service())Service()->DuplicateTemplate();});Add(TEXT("Save template"),[]{if(Service())Service()->SaveTemplate();});return Menu.MakeWidget();}).ButtonContent()[Text(TEXT("..."),12)]]]
 +SVerticalBox::Slot().AutoHeight()[SNew(SHorizontalBox)
 +SHorizontalBox::Slot().FillWidth(1)[Numeric([]{return Service()?Service()->Width:1920;},[](int32 V){if(Service())Service()->SetImageWidth(V);},64,16384)]
 +SHorizontalBox::Slot().AutoWidth().Padding(8,4)[Text(TEXT("x"),9)]
 +SHorizontalBox::Slot().FillWidth(1)[Numeric([]{return Service()?Service()->Height:1080;},[](int32 V){if(Service())Service()->SetImageHeight(V);},64,16384)]
 +SHorizontalBox::Slot().AutoWidth().Padding(8,0,0,0)[SNew(SComboButton).ButtonStyle(&CameraLightingStyle::Button()).ButtonColorAndOpacity(FLinearColor::FromSRGBColor(FColor(37,39,46))).OnGetMenuContent_Lambda([]{return FormatMenu();}).ButtonContent()[SNew(STextBlock).Text_Lambda([]{return FText::FromString(FormatName(Service()?Service()->Format:ECameraLightingImageFormat::PNG));})]]]
 +SVerticalBox::Slot().AutoHeight().Padding(0,8,0,0)[SNew(SHorizontalBox)
 +SHorizontalBox::Slot().AutoWidth()[SNew(SCheckBox).IsChecked_Lambda([]{return Service() && Service()->bLockAspect?ECheckBoxState::Checked:ECheckBoxState::Unchecked;}).OnCheckStateChanged_Lambda([](ECheckBoxState V){if(Service()){Service()->bLockAspect=V==ECheckBoxState::Checked;Service()->PersistSettings();}})[Text(TEXT("Link size"),8)]]
 +SHorizontalBox::Slot().FillWidth(1)
 +SHorizontalBox::Slot().AutoWidth()[SNew(SComboButton).ButtonStyle(FAppStyle::Get(),"NoBorder").OnGetMenuContent_Lambda([]{FMenuBuilder Menu(true,nullptr);for(FString Aspect:{TEXT("Original"),TEXT("16:9"),TEXT("4:3"),TEXT("3:2"),TEXT("1:1")})Menu.AddMenuEntry(FText::FromString(Aspect),FText(),FSlateIcon(),FUIAction(FExecuteAction::CreateLambda([Aspect]{if(Service())Service()->SetAspectPreset(Aspect);})));for(int32 K:{2,4,6,8,16})Menu.AddMenuEntry(FText::FromString(FString::Printf(TEXT("%dk"),K)),FText(),FSlateIcon(),FUIAction(FExecuteAction::CreateLambda([K]{if(Service())Service()->SetPresetSize(K*1024);})));return Menu.MakeWidget();}).ButtonContent()[Text(TEXT("Size"),8)]]]
 +SVerticalBox::Slot().AutoHeight().Padding(0,6,0,0)[SNew(STextBlock).Visibility_Lambda([]{auto* S=Service();const float Crop=S?S->GetCameraCropRatio():0;return S && Crop>0 && FMath::Abs(float(S->Width)/S->Height-Crop)>.005f?EVisibility::Visible:EVisibility::Collapsed;}).Text_Lambda([]{auto* S=Service();const float Crop=S?S->GetCameraCropRatio():0;return FText::FromString(S && Crop>0?FString::Printf(TEXT("Camera crop: still exports at %d x %d. Match output in Camera to use these dimensions for clips too."),S->Width,FMath::RoundToInt(S->Width/Crop)):FString());}).AutoWrapText(true).Font(CameraLightingStyle::Font(8)).ColorAndOpacity(FLinearColor(.6f,.65f,.73f))]
 +SVerticalBox::Slot().AutoHeight()[Specific]
 +SVerticalBox::Slot().AutoHeight().Padding(0,6,0,12)[SNew(STextBlock).Visibility_Lambda([]{return Service() && !Service()->GetTemplateReadiness().IsEmpty()?EVisibility::Visible:EVisibility::Collapsed;}).Text_Lambda([]{return FText::FromString(Service()?Service()->GetTemplateReadiness():FString());}).AutoWrapText(true).ColorAndOpacity(FLinearColor(.85f,.5f,.25f)).Font(CameraLightingStyle::Font(8))]
 +SVerticalBox::Slot().AutoHeight().Padding(0,0,0,12)[OutputPath()]
 +SVerticalBox::Slot().AutoHeight()[SNew(SHorizontalBox)
 +SHorizontalBox::Slot().FillWidth(1)[SNew(SButton).ButtonStyle(&CameraLightingStyle::Button()).ButtonColorAndOpacity(FLinearColor::FromSRGBColor(FColor(37,39,46))).ButtonColorAndOpacity(Blue()).HAlign(HAlign_Center).ContentPadding(10).IsEnabled_Lambda([]{return Service() && !Service()->IsRendering();}).OnClicked_Lambda([]{if(Service())Service()->RenderCamera(Service()->ResolveCamera(true));return FReply::Handled();})[Text(TEXT("Render"),10)]]
 +SHorizontalBox::Slot().AutoWidth().Padding(6,0)[Button(TEXT("Draft"),[]{if(Service())Service()->RenderDraftCamera(Service()->ResolveCamera(true));})]
 +SHorizontalBox::Slot().AutoWidth().Padding(6,0)[Button(TEXT("Add to queue"),[]{if(Service())Service()->QueueCamera(Service()->ResolveCamera(true));})]
 +SHorizontalBox::Slot().AutoWidth().Padding(6,0)[SNew(SButton).ButtonStyle(&CameraLightingStyle::Button()).ButtonColorAndOpacity(FLinearColor::FromSRGBColor(FColor(37,39,46))).ContentPadding(8).ToolTipText(FText::FromString(TEXT("Queue and history"))).OnClicked_Lambda([]{FCameraLightingEditorModule::OpenTab(FCameraLightingEditorModule::QueueTabId);return FReply::Handled();})[MakeCameraLightingGlyph(TEXT("Queue"),20)]]]
 +SVerticalBox::Slot().AutoHeight().Padding(0,10)[SNew(STextBlock).Text_Lambda([]{return FText::FromString(Service()?Service()->GetProgressText():FString());}).AutoWrapText(true).Font(CameraLightingStyle::Font(8)).ColorAndOpacity(FLinearColor(.5f,.57f,.65f))]
 ]],14)];
}

TSharedRef<SWidget> MakeCameraLightingQueuePanel(){return SNew(SCameraLightingQueuePanel);}
void SCameraLightingQueuePanel::Construct(const FArguments& Args)
{
 if(auto* S=Service())S->OnChanged.AddSP(this,&SCameraLightingQueuePanel::InvalidateRows);
 ChildSlot[SNew(SBorder).BorderImage(FAppStyle::GetBrush("WhiteBrush")).BorderBackgroundColor(Background()).Padding(0)
  [SNew(SOverlay)+SOverlay::Slot()[MakeCameraLightingCornerArt()]+SOverlay::Slot().Padding(16)[SNew(SVerticalBox)
   +SVerticalBox::Slot().AutoHeight().Padding(0,12,0,22)
   [SNew(SHorizontalBox)
    +SHorizontalBox::Slot().AutoWidth().Padding(0,0,8,0)[Chip(TEXT("Queue"),[this]{bHistory=false;bNeedsRefresh=true;},[this]{return !bHistory;})]
    +SHorizontalBox::Slot().AutoWidth()[Chip(TEXT("History"),[this]{bHistory=true;bNeedsRefresh=true;},[this]{return bHistory;})]
    +SHorizontalBox::Slot().FillWidth(1)
    +SHorizontalBox::Slot().AutoWidth().Padding(0,0,8,0)[Button(TEXT("Preflight / video"),[]{GEditor->GetEditorSubsystem<UCameraLightingPipelineTools>()->RunPreflight();FCameraLightingEditorModule::OpenTab(FCameraLightingEditorModule::PipelineTabId);})]
    +SHorizontalBox::Slot().AutoWidth().Padding(0,0,8,0)[Button(TEXT("Compare"),[]{FCameraLightingEditorModule::OpenTab(FCameraLightingEditorModule::CompareTabId);})]
    +SHorizontalBox::Slot().AutoWidth()[Button(TEXT("Add All Scenes"),[]{if(auto* S=Service())S->QueueAllCameras();})]]
   +SVerticalBox::Slot().AutoHeight().Padding(0,0,0,12)[MakeCameraLightingRenderSettings(true)]
   +SVerticalBox::Slot().AutoHeight().Padding(0,0,0,16)
   [SNew(SHorizontalBox)
    +SHorizontalBox::Slot().AutoWidth().Padding(0,0,12,0)[SNew(SCheckBox).IsEnabled_Lambda([this]{return !bHistory;})
     .IsChecked_Lambda([]{auto* S=Service();if(!S)return ECheckBoxState::Unchecked;bool bAny=false;for(const auto& Job:S->Jobs)if(Job.State==ECameraLightingJobState::Waiting){bAny=true;if(!Job.bSelected)return ECheckBoxState::Unchecked;}return bAny?ECheckBoxState::Checked:ECheckBoxState::Unchecked;})
     .OnCheckStateChanged_Lambda([](ECheckBoxState State){if(auto* S=Service()){TArray<FString> Ids;for(const auto& Job:S->Jobs)if(Job.State==ECameraLightingJobState::Waiting)Ids.Add(Job.Id);for(const FString& Id:Ids)S->SetJobSelected(Id,State==ECheckBoxState::Checked);}})[Text(TEXT("All"),9)]]
    +SHorizontalBox::Slot().AutoWidth().Padding(0,0,10,0)[SNew(SComboButton).ButtonStyle(&CameraLightingStyle::Button()).ButtonColorAndOpacity(FLinearColor::FromSRGBColor(FColor(37,39,46))).ButtonColorAndOpacity(FLinearColor::FromSRGBColor(FColor(37,39,46))).OnGetMenuContent(this,&SCameraLightingQueuePanel::MakeSortMenu).ButtonContent()[SNew(STextBlock).Text_Lambda([this]{return FText::FromString(bNewest?TEXT("Newest First"):TEXT("Oldest First"));})]]
    +SHorizontalBox::Slot().AutoWidth()[SNew(SComboButton).ButtonStyle(&CameraLightingStyle::Button()).ButtonColorAndOpacity(FLinearColor::FromSRGBColor(FColor(37,39,46))).ButtonColorAndOpacity(FLinearColor::FromSRGBColor(FColor(37,39,46))).OnGetMenuContent(this,&SCameraLightingQueuePanel::MakeStateMenu).ButtonContent()[SNew(STextBlock).Text_Lambda([this]{return FText::FromString(StateFilter);})]]
    +SHorizontalBox::Slot().FillWidth(1)
    +SHorizontalBox::Slot().AutoWidth()[Text(TEXT("Stills & clips"),9)]]
   +SVerticalBox::Slot().FillHeight(1)[SNew(SScrollBox)+SScrollBox::Slot()[SAssignNew(Rows,SVerticalBox)]]
   +SVerticalBox::Slot().AutoHeight()[SNew(SProgressBar).Visibility_Lambda([]{return GEditor->GetEditorSubsystem<UCameraLightingPipelineTools>()->IsBusy()?EVisibility::Visible:EVisibility::Collapsed;}).Percent_Lambda([]{return GEditor->GetEditorSubsystem<UCameraLightingPipelineTools>()->GetTaskProgress();})]
   +SVerticalBox::Slot().AutoHeight().Padding(0,6)[SNew(STextBlock).Text_Lambda([]{return FText::FromString(GEditor->GetEditorSubsystem<UCameraLightingPipelineTools>()->Status);}).AutoWrapText(true).Font(CameraLightingStyle::Font(8))]
   +SVerticalBox::Slot().AutoHeight()[SNew(SProgressBar).Visibility_Lambda([]{return Service() && Service()->IsRendering()?EVisibility::Visible:EVisibility::Collapsed;}).Percent_Lambda([]{return Service()?Service()->GetBatchProgress():0.f;})]
   +SVerticalBox::Slot().AutoHeight().Padding(0,12,0,12)[SNew(STextBlock).Text_Lambda([]{auto* S=Service();return FText::FromString(S?S->GetProgressText():FString());}).AutoWrapText(true).ColorAndOpacity(FLinearColor(.55f,.65f,.8f))]
   +SVerticalBox::Slot().AutoHeight()
   [SNew(SWrapBox).UseAllottedSize(true).InnerSlotPadding(FVector2D(12,12))
    +SWrapBox::Slot()[Group(TEXT("Location"),SNew(SBox).WidthOverride(300)[OutputPath()])]
    +SWrapBox::Slot()[Group(TEXT("Prefix"),PrefixField())]
    +SWrapBox::Slot()[Group(TEXT("Output"),Button(TEXT("Open Folder"),[]{if(auto* S=Service())S->OpenOutputDirectory();}))]
    +SWrapBox::Slot()[Group(TEXT("Render"),SNew(SButton).ButtonStyle(&CameraLightingStyle::Button()).ButtonColorAndOpacity(FLinearColor::FromSRGBColor(FColor(37,39,46))).ButtonColorAndOpacity(Blue()).ContentPadding(FMargin(16,9))
     .IsEnabled_Lambda([]{auto* S=Service();if(!S || S->IsRendering())return false;for(const auto& J:S->Jobs)if(J.State==ECameraLightingJobState::Waiting && J.bSelected)return true;return false;})
     .OnClicked_Lambda([]{if(auto* S=Service()){if(S->bUseBatchSettings)S->ApplySettingsToSelectedJobs();S->RenderQueued();}return FReply::Handled();})[Text(TEXT("Save & Render"))])]
    +SWrapBox::Slot()[Group(TEXT(""),SNew(SButton).ContentPadding(FMargin(12,9)).IsEnabled_Lambda([]{auto* S=Service();return S && S->IsRendering();})
     .OnClicked_Lambda([]{if(auto* S=Service())S->CancelRendering();return FReply::Handled();})[Text(TEXT("Cancel"))])]]
  ]]];
 RebuildRows();
}
SCameraLightingQueuePanel::~SCameraLightingQueuePanel(){if(auto* S=Service())S->OnChanged.RemoveAll(this);}
void SCameraLightingQueuePanel::InvalidateRows(){bNeedsRefresh=true;}
void SCameraLightingQueuePanel::Tick(const FGeometry& Geometry,const double Time,const float DeltaTime)
{SCompoundWidget::Tick(Geometry,Time,DeltaTime);if(bNeedsRefresh){bNeedsRefresh=false;RebuildRows();}}
TSharedRef<SWidget> SCameraLightingQueuePanel::MakeSortMenu()
{FMenuBuilder Menu(true,nullptr);Menu.AddMenuEntry(FText::FromString(TEXT("Newest First")),FText(),FSlateIcon(),FUIAction(FExecuteAction::CreateLambda([this]{bNewest=true;bNeedsRefresh=true;})));
 Menu.AddMenuEntry(FText::FromString(TEXT("Oldest First")),FText(),FSlateIcon(),FUIAction(FExecuteAction::CreateLambda([this]{bNewest=false;bNeedsRefresh=true;})));return Menu.MakeWidget();}
TSharedRef<SWidget> SCameraLightingQueuePanel::MakeStateMenu()
{FMenuBuilder Menu(true,nullptr);for(FString Name:{TEXT("All States"),TEXT("Waiting"),TEXT("Rendering"),TEXT("Completed"),TEXT("Failed"),TEXT("Canceled")})
 Menu.AddMenuEntry(FText::FromString(Name),FText(),FSlateIcon(),FUIAction(FExecuteAction::CreateLambda([this,Name]{StateFilter=Name;bNeedsRefresh=true;})));return Menu.MakeWidget();}
void SCameraLightingQueuePanel::RebuildRows()
{
 if(!Rows.IsValid())return;Rows->ClearChildren();auto* S=Service();if(!S)return;
 TArray<FCameraLightingStillJob> Visible;
 for(const auto& Job:S->Jobs)if(IsHistoryState(Job.State)==bHistory && (StateFilter==TEXT("All States") || StateName(Job.State)==StateFilter))Visible.Add(Job);
 Visible.Sort([this](const FCameraLightingStillJob& A,const FCameraLightingStillJob& B){return bNewest?A.CreatedAt>B.CreatedAt:A.CreatedAt<B.CreatedAt;});
 if(Visible.IsEmpty()){Rows->AddSlot().AutoHeight().Padding(8,30)[SNew(STextBlock).Text(FText::FromString(bHistory?TEXT("No render history"):TEXT("No queued images"))).Justification(ETextJustify::Center).ColorAndOpacity(FLinearColor(.35f,.4f,.48f))];return;}
 for(const auto& Job:Visible){
  const FString Id=Job.Id;
  auto Card=SNew(SVerticalBox)
   +SVerticalBox::Slot().AutoHeight()
   [SNew(SHorizontalBox)
    +SHorizontalBox::Slot().AutoWidth().VAlign(VAlign_Center).Padding(0,0,10,0)
    [SNew(SCheckBox).IsEnabled(Job.State==ECameraLightingJobState::Waiting).IsChecked(Job.bSelected?ECheckBoxState::Checked:ECheckBoxState::Unchecked)
     .OnCheckStateChanged_Lambda([Id](ECheckBoxState State){if(auto* ServicePtr=Service())ServicePtr->SetJobSelected(Id,State==ECheckBoxState::Checked);})]
    +SHorizontalBox::Slot().FillWidth(1)[SNew(SVerticalBox)
     +SVerticalBox::Slot().AutoHeight()[Text(Job.Label,11)]
     +SVerticalBox::Slot().AutoHeight().Padding(0,6,0,0)[Text(FString::Printf(TEXT("%d x %d  |  %s%s"),Job.Width,Job.Height,*FormatName(Job.Format),Job.bClip?*FString::Printf(TEXT("  |  %d frames @ %d fps"),Job.FrameCount,Job.FrameRate):TEXT("")),9)]]
    +SHorizontalBox::Slot().AutoWidth().VAlign(VAlign_Center).Padding(12,0)[Text(StateName(Job.State),9)]
    +SHorizontalBox::Slot().AutoWidth().VAlign(VAlign_Center)
    [bHistory?Button(TEXT("New full render"),[Id]{if(auto* ServicePtr=Service())ServicePtr->RetryJob(Id);}):Button(TEXT("Remove"),[Id]{if(auto* ServicePtr=Service())ServicePtr->RemoveQueuedJob(Id);})]];
  Card->AddSlot().AutoHeight().Padding(22,8,0,0)[SNew(SWrapBox).UseAllottedSize(true).InnerSlotPadding(FVector2D(7,6))
   +SWrapBox::Slot()[Button(TEXT("Inspect"),[Id]{GEditor->GetEditorSubsystem<UCameraLightingPipelineTools>()->InspectJob(Id);FCameraLightingEditorModule::OpenTab(FCameraLightingEditorModule::PipelineTabId);})]
   +SWrapBox::Slot()[Button(TEXT("Recover missing"),[Id]{GEditor->GetEditorSubsystem<UCameraLightingPipelineTools>()->RecoverJob(Id);})]
   +SWrapBox::Slot()[SNew(SBox).Visibility(Job.bClip?EVisibility::Visible:EVisibility::Collapsed)[Button(TEXT("Export video"),[Id]{GEditor->GetEditorSubsystem<UCameraLightingPipelineTools>()->ExportVideo(Id);FCameraLightingEditorModule::OpenTab(FCameraLightingEditorModule::PipelineTabId);})]]];
  if(!Job.DeliveryError.IsEmpty())Card->AddSlot().AutoHeight().Padding(22,6,0,0)[SNew(STextBlock).Text(FText::FromString(TEXT("Video: ")+Job.DeliveryError)).AutoWrapText(true).Font(CameraLightingStyle::Font(8)).ColorAndOpacity(FLinearColor(1,.5,.3))];
  for(const auto& Video:Job.VideoFiles)Card->AddSlot().AutoHeight().Padding(22,5,0,0)[Button(TEXT("Open video: ")+FPaths::GetCleanFilename(Video),[Video]{FPlatformProcess::LaunchFileInDefaultExternalApplication(*Video);})];
  if(!Job.Error.IsEmpty())Card->AddSlot().AutoHeight().Padding(22,8,0,0)[SNew(STextBlock).Text(FText::FromString(Job.Error)).AutoWrapText(true).ColorAndOpacity(FLinearColor(1.f,.48f,.4f))];
  if(!Job.OutputFiles.IsEmpty())Card->AddSlot().AutoHeight().Padding(22,8,0,0)[SNew(STextBlock).Text(FText::FromString(Job.OutputFiles[0])).AutoWrapText(true).ColorAndOpacity(FLinearColor(.4f,.6f,.75f))];
  Rows->AddSlot().AutoHeight().Padding(0,0,0,10)[SNew(SBorder).BorderImage(FAppStyle::GetBrush("WhiteBrush")).BorderBackgroundColor(Field()).Padding(14)[Card]];
 }
}
