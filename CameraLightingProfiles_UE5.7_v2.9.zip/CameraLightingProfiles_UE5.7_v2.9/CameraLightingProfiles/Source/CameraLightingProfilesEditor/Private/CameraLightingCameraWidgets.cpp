#include "CameraLightingViewportTools.h"
#include "CameraLightingClips.h"
#include "CameraLightingCameraTools.h"
#include "CameraLightingMinimalWidgets.h"
#include "CameraLightingRenderService.h"
#include "CameraLightingStyle.h"
#include "Editor.h"
#include "EngineUtils.h"
#include "Engine/PostProcessVolume.h"
#include "Camera/CameraComponent.h"
#include "CineCameraComponent.h"
#include "Widgets/Layout/SBorder.h"
#include "Widgets/Layout/SScrollBox.h"
#include "Widgets/Layout/SBox.h"
#include "Widgets/Layout/SExpandableArea.h"
#include "Widgets/Input/SButton.h"
#include "Widgets/Input/SComboButton.h"
#include "Widgets/Input/SCheckBox.h"
#include "Widgets/Text/STextBlock.h"
#include "Framework/MultiBox/MultiBoxBuilder.h"
namespace
{
UCameraLightingCameraTools* Tools(){return GEditor?GEditor->GetEditorSubsystem<UCameraLightingCameraTools>():nullptr;}
FLinearColor ToolColor(int R,int G,int B){return FLinearColor::FromSRGBColor(FColor(R,G,B));}
TSharedRef<STextBlock> ToolText(const FString& T,int Size=9){return SNew(STextBlock).Text(FText::FromString(T)).Font(CameraLightingStyle::Font(Size));}
TSharedRef<SWidget> ToolRow(const FString& Name,TSharedRef<SWidget> W){return SNew(SVerticalBox)+SVerticalBox::Slot().AutoHeight().Padding(0,0,0,5)[ToolText(Name)]+SVerticalBox::Slot().AutoHeight()[W];}
TSharedRef<SWidget> ToolNumber(FName Name,float Min,float Max,float Delta=1){return MakeCameraLightingDragNumber([Name]{return Tools()->GetValue(Name);},[Name](float V){Tools()->SetValue(Name,V);},Min,Max,Delta,2);}
TSharedRef<SWidget> ToolButton(const FString& Name,TFunction<void()> Action){return SNew(SButton).ButtonStyle(&CameraLightingStyle::Button()).ButtonColorAndOpacity(ToolColor(37,39,46)).ContentPadding(FMargin(8,6)).HAlign(HAlign_Center).OnClicked_Lambda([Action]{Action();return FReply::Handled();})[ToolText(Name)];}
TSharedRef<SWidget> ToolChoice(TFunction<FString()> Get,TFunction<TSharedRef<SWidget>()> Menu){return SNew(SComboButton).ButtonStyle(&CameraLightingStyle::Button()).ButtonColorAndOpacity(ToolColor(37,39,46)).ContentPadding(FMargin(8,6)).OnGetMenuContent_Lambda([Menu]{return Menu();}).ButtonContent()[SNew(STextBlock).Text_Lambda([Get]{return FText::FromString(Get());}).Font(CameraLightingStyle::Font(9))];}
TSharedRef<SWidget> ToolExpand(const FString& Name,TSharedRef<SWidget> Body){return SNew(SExpandableArea).InitiallyCollapsed(true).HeaderPadding(FMargin(0,9)).Padding(FMargin(0,0,0,8)).HeaderContent()[ToolText(Name,10)].BodyContent()[Body];}
void MenuAction(FMenuBuilder& M,const FString& Name,TFunction<void()> A){M.AddMenuEntry(FText::FromString(Name),FText(),FSlateIcon(),FUIAction(FExecuteAction::CreateLambda([A]{A();})));}
}
TSharedRef<SWidget> MakeCameraLightingCameraPanel()
{
 auto Body=SNew(SVerticalBox);auto Add=[Body](TSharedRef<SWidget> W){Body->AddSlot().AutoHeight().Padding(0,0,0,10)[W];};
 Add(SNew(SHorizontalBox)+SHorizontalBox::Slot().FillWidth(1)[ToolChoice([]{return Tools()->GetTargetName();},[]{FMenuBuilder M(true,nullptr);if(GEditor)if(auto* W=GEditor->GetEditorWorldContext().World())for(TActorIterator<AActor>I(W);I;++I)if(!I->HasAnyFlags(RF_Transient) && (I->FindComponentByClass<UCameraComponent>() || I->IsA<APostProcessVolume>())){TWeakObjectPtr<AActor>A=*I;MenuAction(M,(I->IsA<APostProcessVolume>()?TEXT("PPV · "):TEXT("Camera · "))+I->GetActorLabel(),[A]{Tools()->SelectTarget(A.Get());});}return M.MakeWidget();})]+SHorizontalBox::Slot().AutoWidth().Padding(5,0)[ToolButton(TEXT("Use selected"),[]{Tools()->UseSelectedTarget();})]);
 auto MainCamera=SNew(SVerticalBox).Visibility_Lambda([]{return Tools()->GetCamera()?EVisibility::Visible:EVisibility::Collapsed;});
 MainCamera->AddSlot().AutoHeight().Padding(0,0,0,10)[ToolRow(TEXT("Aspect / crop"),SNew(SHorizontalBox)
 +SHorizontalBox::Slot().FillWidth(1)[ToolChoice([]{float R=Tools()->GetCrop();return R<=0?TEXT("No crop"):FString::Printf(TEXT("%.3f : 1"),R);},[]{FMenuBuilder M(true,nullptr);const TCHAR* Names[]={TEXT("No crop"),TEXT("16:9"),TEXT("4:3"),TEXT("3:2"),TEXT("1:1"),TEXT("2.39:1"),TEXT("9:16")};const float Ratios[]={0,16.f/9,4.f/3,1.5f,1,2.39f,9.f/16};for(int I=0;I<7;++I){float R=Ratios[I];MenuAction(M,Names[I],[R]{Tools()->SetCrop(R);});}return M.MakeWidget();})]
 +SHorizontalBox::Slot().AutoWidth().Padding(5,0)[ToolButton(TEXT("Match output"),[]{Tools()->MatchOutputToCrop();})])];
 MainCamera->AddSlot().AutoHeight().Padding(0,0,0,10)[ToolRow(TEXT("Projection"),ToolChoice([]{return Tools()->GetValue(TEXT("Projection"))<.5f?TEXT("Perspective"):TEXT("Orthographic");},[]{FMenuBuilder M(true,nullptr);MenuAction(M,TEXT("Perspective"),[]{Tools()->SetValue(TEXT("Projection"),0);});MenuAction(M,TEXT("Orthographic"),[]{Tools()->SetValue(TEXT("Projection"),1);});return M.MakeWidget();}))];
 MainCamera->AddSlot().AutoHeight().Padding(0,0,0,10)[SNew(SBox).Visibility_Lambda([]{return Tools()->GetValue(TEXT("Projection"))>=.5f?EVisibility::Visible:EVisibility::Collapsed;})[ToolRow(TEXT("Ortho width (cm)"),ToolNumber(TEXT("OrthoWidth"),1,1000000,10))]];
 MainCamera->AddSlot().AutoHeight().Padding(0,0,0,10)[SNew(SBox).Visibility_Lambda([]{return Tools()->GetCrop()>0?EVisibility::Visible:EVisibility::Collapsed;})[ToolRow(TEXT("Custom crop ratio"),MakeCameraLightingDragNumber([]{return Tools()->GetCrop();},[](float R){Tools()->SetCrop(R);},.1f,10,.01f,3))]];
 MainCamera->AddSlot().AutoHeight().Padding(0,0,0,10)[SNew(SBox).Visibility_Lambda([]{return Tools()->GetValue(TEXT("Projection"))<.5f?EVisibility::Visible:EVisibility::Collapsed;})[ToolRow(TEXT("FOV (horizontal)"),MakeCameraLightingDragNumber([]{return GEditor->GetEditorSubsystem<UCameraLightingRenderService>()->GetCameraFov();},[](float V){GEditor->GetEditorSubsystem<UCameraLightingRenderService>()->SetCameraFov(V);},5,170 ,.1f,2))]];
 MainCamera->AddSlot().AutoHeight().Padding(0,0,0,10)[SNew(SBox).Visibility_Lambda([]{return Tools()->GetValue(TEXT("Projection"))<.5f?EVisibility::Visible:EVisibility::Collapsed;})[ToolRow(TEXT("Focal length (mm)"),MakeCameraLightingDragNumber([]{return GEditor->GetEditorSubsystem<UCameraLightingRenderService>()->GetFocalLength();},[](float V){GEditor->GetEditorSubsystem<UCameraLightingRenderService>()->SetFocalLength(V);},1,1000 ,.1f,2))]];
 auto Guides=SNew(SVerticalBox);for(auto Guide:{TEXT("Thirds"),TEXT("Center"),TEXT("Safe areas"),TEXT("Crop"),TEXT("Golden ratio"),TEXT("Diagonals"),TEXT("Golden triangle"),TEXT("Golden spiral"),TEXT("Horizon"),TEXT("Square 1:1"),TEXT("Cinema 2.39")}){FString N=Guide;Guides->AddSlot().AutoHeight().Padding(0,3)[SNew(SCheckBox).IsChecked_Lambda([N]{auto* V=GEditor->GetEditorSubsystem<UCameraLightingViewportTools>();bool B=V->IsGuideEnabled(FName(*N));return B?ECheckBoxState::Checked:ECheckBoxState::Unchecked;}).OnCheckStateChanged_Lambda([N](ECheckBoxState State){GEditor->GetEditorSubsystem<UCameraLightingViewportTools>()->SetGuide(FName(*N),State==ECheckBoxState::Checked);})[ToolText(N)]];}Add(ToolExpand(TEXT("Composition guides"),Guides));
 MainCamera->AddSlot().AutoHeight().Padding(0,0,0,10)[ToolRow(TEXT("Aperture (f-stop)"),ToolNumber(TEXT("Aperture"),.7f,64,.1f))];
 MainCamera->AddSlot().AutoHeight().Padding(0,0,0,10)[ToolRow(TEXT("Focus distance (cm)"),MakeCameraLightingDragNumber([]{return Tools()->GetValue(TEXT("Focus"));},[](float V){Tools()->SetFocusMethod(1);Tools()->SetValue(TEXT("Focus"),V);},0,1000000,10,1))];
 Add(MainCamera);Add(ToolRow(TEXT("Exposure compensation"),ToolNumber(TEXT("Exposure"),-15,15,.1f)));
 auto Exposure=SNew(SVerticalBox);auto EAdd=[Exposure](const FString& N,TSharedRef<SWidget> W){Exposure->AddSlot().AutoHeight().Padding(0,0,0,9)[ToolRow(N,W)];};
 EAdd(TEXT("Metering mode"),ToolChoice([]{int M=Tools()->GetMetering();return M==2?TEXT("Manual"):M==1?TEXT("Auto · Basic"):TEXT("Auto · Histogram");},[]{FMenuBuilder M(true,nullptr);MenuAction(M,TEXT("Manual"),[]{Tools()->SetMetering(2);});MenuAction(M,TEXT("Auto · Histogram"),[]{Tools()->SetMetering(0);});MenuAction(M,TEXT("Auto · Basic"),[]{Tools()->SetMetering(1);});return M.MakeWidget();}));
 Exposure->AddSlot().AutoHeight().Padding(0,0,0,10)[SNew(SCheckBox).IsChecked_Lambda([]{return Tools()->IsPhysicalExposure()?ECheckBoxState::Checked:ECheckBoxState::Unchecked;}).OnCheckStateChanged_Lambda([](ECheckBoxState S){Tools()->SetPhysicalExposure(S==ECheckBoxState::Checked);})[ToolText(TEXT("Use physical camera exposure"))]];
 EAdd(TEXT("ISO"),ToolNumber(TEXT("ISO"),1,102400,10));EAdd(TEXT("Shutter speed (1/s)"),ToolNumber(TEXT("Shutter"),.01f,8000,1));EAdd(TEXT("Aperture (f-stop)"),ToolNumber(TEXT("Aperture"),.7f,64,.1f));
 Exposure->AddSlot().AutoHeight()[SNew(SHorizontalBox)+SHorizontalBox::Slot().FillWidth(1)[ToolButton(TEXT("Daylight · ISO100 / 125 / f8"),[]{Tools()->DaylightExposure();})]+SHorizontalBox::Slot().AutoWidth().Padding(6,0)[ToolButton(TEXT("Reset exposure"),[]{Tools()->ResetExposure();})]];
 Add(ToolExpand(TEXT("Exposure · physical camera"),Exposure));
 auto Cine=SNew(SVerticalBox).Visibility_Lambda([]{return Tools()->GetCineCamera()?EVisibility::Visible:EVisibility::Collapsed;});
 auto FAdd=[Cine](const FString& N,TSharedRef<SWidget> W){Cine->AddSlot().AutoHeight().Padding(0,0,0,9)[ToolRow(N,W)];};
 Cine->AddSlot().AutoHeight().Padding(0,0,0,10)[SNew(SCheckBox).IsChecked_Lambda([]{return Tools()->bLockFilmbackAspect?ECheckBoxState::Checked:ECheckBoxState::Unchecked;}).OnCheckStateChanged_Lambda([](ECheckBoxState S){Tools()->bLockFilmbackAspect=S==ECheckBoxState::Checked;Tools()->SaveConfig();})[ToolText(TEXT("Lock sensor aspect ratio"))]];
 FAdd(TEXT("Sensor preset"),ToolChoice([]{auto* C=Tools()->GetCineCamera();FString N=C?C->GetFilmbackPresetName():FString();return N.IsEmpty()?TEXT("Custom"):N;},[]{FMenuBuilder M(true,nullptr);for(const auto& P:UCineCameraComponent::GetFilmbackPresets()){FString N=P.Name;MenuAction(M,N,[N]{Tools()->SetFilmbackPreset(N);});}return M.MakeWidget();}));
 FAdd(TEXT("Sensor width (mm)"),ToolNumber(TEXT("SensorWidth"),.1f,100,.1f));FAdd(TEXT("Sensor height (mm)"),ToolNumber(TEXT("SensorHeight"),.1f,100,.1f));
 Cine->AddSlot().AutoHeight().Padding(0,0,0,10)[SNew(STextBlock).Text_Lambda([]{return FText::FromString(FString::Printf(TEXT("Sensor aspect ratio  %.3f"),Tools()->GetValue(TEXT("SensorAspect"))));}).Font(CameraLightingStyle::Font(9))];
 FAdd(TEXT("Anamorphic squeeze"),ToolNumber(TEXT("Squeeze"),1,2,.01f));
 auto Film=SNew(SVerticalBox)+SVerticalBox::Slot().AutoHeight()[Cine]+SVerticalBox::Slot().AutoHeight()[SNew(SBox).Visibility_Lambda([]{return Tools()->GetCamera() && !Tools()->GetCineCamera()?EVisibility::Visible:EVisibility::Collapsed;})[ToolButton(TEXT("Create Cine Camera copy for filmback controls"),[]{Tools()->CreateCineCameraCopy();})]];
 Add(SNew(SBox).Visibility_Lambda([]{return Tools()->GetCamera()?EVisibility::Visible:EVisibility::Collapsed;})[ToolExpand(TEXT("Filmback & lens"),Film)]);
 auto Focus=SNew(SVerticalBox);Focus->AddSlot().AutoHeight().Padding(0,0,0,9)[ToolRow(TEXT("Focus method"),ToolChoice([]{int M=Tools()->GetFocusMethod();return M==0?TEXT("Do not override"):M==1?TEXT("Manual"):M==2?TEXT("Tracking"):TEXT("Disabled");},[]{FMenuBuilder M(true,nullptr);if(Tools()->GetCineCamera())MenuAction(M,TEXT("Do not override"),[]{Tools()->SetFocusMethod(0);});MenuAction(M,TEXT("Manual"),[]{Tools()->SetFocusMethod(1);});if(Tools()->GetCineCamera())MenuAction(M,TEXT("Tracking"),[]{Tools()->SetFocusMethod(2);});MenuAction(M,TEXT("Disabled"),[]{Tools()->SetFocusMethod(3);});return M.MakeWidget();}))];
 Focus->AddSlot().AutoHeight().Padding(0,0,0,9)[ToolRow(TEXT("Focus distance (cm)"),ToolNumber(TEXT("Focus"),0,1000000,10))];
 Focus->AddSlot().AutoHeight().Padding(0,0,0,9)[ToolButton(TEXT("Pick focus in viewport"),[]{GEditor->GetEditorSubsystem<UCameraLightingViewportTools>()->ArmFocusPick(false);})];
 Focus->AddSlot().AutoHeight().Padding(0,0,0,9)[ToolButton(TEXT("Pick actor to track"),[]{GEditor->GetEditorSubsystem<UCameraLightingViewportTools>()->ArmFocusPick(true);})];
 Focus->AddSlot().AutoHeight().Padding(0,0,0,9)[SNew(SBox).Visibility_Lambda([]{return GEditor->GetEditorSubsystem<UCameraLightingViewportTools>()->bPickingFocus?EVisibility::Visible:EVisibility::Collapsed;})[ToolButton(TEXT("Cancel focus pick"),[]{GEditor->GetEditorSubsystem<UCameraLightingViewportTools>()->CancelFocusPick();})]];
 Focus->AddSlot().AutoHeight().Padding(0,0,0,9)[ToolButton(TEXT("Focus / track selected actor"),[]{Tools()->FocusSelectedActor();})];
 Focus->AddSlot().AutoHeight()[SNew(SBox).Visibility_Lambda([]{return Tools()->GetCineCamera()?EVisibility::Visible:EVisibility::Collapsed;})[SNew(SCheckBox).IsChecked_Lambda([]{return Tools()->HasFocusPlane()?ECheckBoxState::Checked:ECheckBoxState::Unchecked;}).OnCheckStateChanged_Lambda([](ECheckBoxState S){Tools()->SetFocusPlane(S==ECheckBoxState::Checked);})[ToolText(TEXT("Draw debug focus plane"))]]];
 Add(SNew(SBox).Visibility_Lambda([]{return Tools()->GetCamera()?EVisibility::Visible:EVisibility::Collapsed;})[ToolExpand(TEXT("Focus settings"),Focus)]);
 auto Transform=SNew(SVerticalBox);for(bool Rotation:{false,true}){auto Row=SNew(SHorizontalBox);for(int Axis=0;Axis<3;++Axis){const TCHAR* Names[]={TEXT("X"),TEXT("Y"),TEXT("Z")};Row->AddSlot().FillWidth(1).Padding(0,0,4,0)[ToolRow(Names[Axis],MakeCameraLightingDragNumber([Rotation,Axis]{auto* A=Tools()->GetTarget();if(!A)return 0.f;const auto R=A->GetActorRotation();return float(Rotation?(Axis==0?R.Roll:Axis==1?R.Pitch:R.Yaw):A->GetActorLocation()[Axis]);},[Rotation,Axis](float V){if(auto* A=Tools()->GetTarget()){A->Modify();if(Rotation){auto R=A->GetActorRotation();if(Axis==0)R.Roll=V;else if(Axis==1)R.Pitch=V;else R.Yaw=V;A->SetActorRotation(R);}else{auto P=A->GetActorLocation();P[Axis]=V;A->SetActorLocation(P);}A->MarkPackageDirty();GEditor->GetEditorSubsystem<UCameraLightingClipService>()->SyncCameraEdit(A);}},Rotation?-360.f:-1000000.f,Rotation?360.f:1000000.f,1,2))];}Transform->AddSlot().AutoHeight().Padding(0,0,0,10)[ToolRow(Rotation?TEXT("Rotation (degrees)"):TEXT("Location (cm)"),Row)];}
 Add(ToolExpand(TEXT("Transform"),Transform));
 return SNew(SBorder).IsEnabled_Lambda([]{return !GEditor->GetEditorSubsystem<UCameraLightingClipService>()->bRecording;}).BorderImage(FAppStyle::GetBrush("WhiteBrush")).BorderBackgroundColor(ToolColor(26,29,37)).Padding(0)[MakeCameraLightingArtPanel(SNew(SScrollBox)+SScrollBox::Slot()[Body],14)];
}
