#include "CameraLightingViewportTools.h"
#include "Framework/Application/SlateApplication.h"
#include "CameraLightingCameraTools.h"
#include "CameraLightingRenderService.h"
#include "CameraLightingClips.h"
#include "CameraLightingEditorSubsystem.h"
#include "Editor.h"
#include "Engine/World.h"
#include "Camera/CameraComponent.h"
#include "LevelEditor.h"
#include "ILevelEditor.h"
#include "SLevelViewport.h"
#include "LevelEditorViewport.h"
#include "SceneView.h"
#include "Widgets/SLeafWidget.h"
#include "Rendering/DrawElements.h"
#include "CameraLightingStyle.h"
namespace
{
UCameraLightingViewportTools* VTools(){return GEditor?GEditor->GetEditorSubsystem<UCameraLightingViewportTools>():nullptr;}
FLevelEditorViewportClient* VClient(){if(!GEditor)return nullptr;auto* V=GCurrentLevelEditingViewportClient;if(V && V->IsPerspective())return V;for(auto* C:GEditor->GetLevelViewportClients())if(C && C->IsPerspective())return C;return nullptr;}
class SCompositionGuides : public SLeafWidget
{
public:
 SLATE_BEGIN_ARGS(SCompositionGuides){}SLATE_END_ARGS()
 void Construct(const FArguments&){SetVisibility(TAttribute<EVisibility>::CreateLambda([]{auto* S=VTools();return S && S->bPickingFocus?EVisibility::Visible:EVisibility::HitTestInvisible;}));SetCursor(EMouseCursor::Crosshairs);}
 virtual FVector2D ComputeDesiredSize(float)const override{return FVector2D::ZeroVector;}
 virtual bool SupportsKeyboardFocus()const override{return true;}
 virtual int32 OnPaint(const FPaintArgs&,const FGeometry& G,const FSlateRect&,FSlateWindowElementList& Out,int32 L,const FWidgetStyle&,bool)const override
 {
  auto* S=VTools();if(!S)return L;auto A=G.GetLocalSize();float Aspect=16.f/9;if(auto* V=VClient())if(auto* C=V->GetCameraComponentForView()){FMinimalViewInfo View;C->GetCameraView(0,View);Aspect=View.AspectRatio;}if(auto* R=GEditor->GetEditorSubsystem<UCameraLightingRenderService>())if(!VClient() || !VClient()->GetCameraComponentForView())Aspect=float(R->Width)/R->Height;
  FVector2D Size=A;if(Size.X/Size.Y>Aspect)Size.X=Size.Y*Aspect;else Size.Y=Size.X/Aspect;auto Origin=(A-Size)*.5;
  auto Line=[&](FVector2D X,FVector2D Y,float Alpha=.55f){TArray<FVector2D>P{Origin+X*Size,Origin+Y*Size};FSlateDrawElement::MakeLines(Out,L+1,G.ToPaintGeometry(),P,ESlateDrawEffect::None,FLinearColor(1,1,1,Alpha),true,1);};
  if(S->bThirds)for(float F:{1.f/3,2.f/3}){Line({F,0},{F,1});Line({0,F},{1,F});}
  if(S->bCenter){Line({.48,.5},{.52,.5},.8f);Line({.5,.47},{.5,.53},.8f);}
  if(S->bSafeAreas)for(float Pad:{.05f,.1f}){Line({Pad,Pad},{1-Pad,Pad},.3f);Line({1-Pad,Pad},{1-Pad,1-Pad},.3f);Line({1-Pad,1-Pad},{Pad,1-Pad},.3f);Line({Pad,1-Pad},{Pad,Pad},.3f);}
  if(S->bCropGuide){Line({0,0},{1,0},.75f);Line({1,0},{1,1},.75f);Line({1,1},{0,1},.75f);Line({0,1},{0,0},.75f);}
  if(S->bGoldenRatio)for(float F:{.381966f,.618034f}){Line({F,0},{F,1});Line({0,F},{1,F});}
  if(S->bDiagonals){Line({0,0},{1,1});Line({0,1},{1,0});}
  if(S->bTriangle){Line({0,1},{1,0});const float X=Size.Y*Size.Y/(Size.X*Size.X+Size.Y*Size.Y);Line({0,0},{X,1-X});Line({1,1},{1-X,X});}
  if(S->bHorizon)Line({0,.5},{1,.5},.8f);
  if(S->bSquare){float Side=FMath::Min(Size.X,Size.Y);float X=Side/Size.X*.5f,Y=Side/Size.Y*.5f;Line({.5f-X,.5f-Y},{.5f+X,.5f-Y});Line({.5f+X,.5f-Y},{.5f+X,.5f+Y});Line({.5f+X,.5f+Y},{.5f-X,.5f+Y});Line({.5f-X,.5f+Y},{.5f-X,.5f-Y});}
  if(S->bLetterbox){float Half=FMath::Min(.5f,Size.X/(2*2.39f*Size.Y));Line({0,.5f-Half},{1,.5f-Half},.8f);Line({0,.5f+Half},{1,.5f+Half},.8f);}
  if(S->bSpiral){FVector2D Previous=FVector2D::ZeroVector;for(int32 I=0;I<=200;++I){float T=float(I)/200*6*PI,R=FMath::Min(Size.X,Size.Y)*.45f*FMath::Exp(-.306349f*T);FVector2D P(.5f+R*FMath::Cos(T)/Size.X,.5f+R*FMath::Sin(T)/Size.Y);if(I)Line(Previous,P);Previous=P;}}
  if(S->bPickingFocus)FSlateDrawElement::MakeText(Out,L+2,G.ToPaintGeometry(FVector2D(500,30),FSlateLayoutTransform(FVector2D(20,55))),TEXT("Click a subject to focus · Esc cancels"),CameraLightingStyle::Font(11),ESlateDrawEffect::None,FLinearColor::White);return L+2;
 }
 virtual FReply OnMouseButtonDown(const FGeometry& G,const FPointerEvent& E)override{if(E.GetEffectingButton()==EKeys::LeftMouseButton){auto* S=VTools();if(S && S->bPickingFocus){auto* V=VClient();auto P=G.AbsoluteToLocal(E.GetScreenSpacePosition());if(V && V->Viewport){auto Size=V->Viewport->GetSizeXY();S->PickFocusAtPixel(FVector2D(P.X/G.GetLocalSize().X*Size.X,P.Y/G.GetLocalSize().Y*Size.Y));}return FReply::Handled();}}return FReply::Unhandled();}
 virtual FReply OnKeyDown(const FGeometry&,const FKeyEvent& E)override{if(E.GetKey()==EKeys::Escape){if(auto* S=VTools())S->CancelFocusPick();return FReply::Handled();}return FReply::Unhandled();}
};
}
TSharedRef<SWidget> MakeCameraLightingGuidesOverlay(){return SNew(SCompositionGuides);}
void UCameraLightingViewportTools::Initialize(FSubsystemCollectionBase& C){Super::Initialize(C);LoadConfig();TickHandle=FTSTicker::GetCoreTicker().AddTicker(FTickerDelegate::CreateUObject(this,&UCameraLightingViewportTools::Tick),.2f);}
void UCameraLightingViewportTools::Deinitialize(){FTSTicker::GetCoreTicker().RemoveTicker(TickHandle);if(auto V=Attached.Pin())if(Overlay)V->RemoveOverlayWidget(Overlay.ToSharedRef());Overlay.Reset();SaveConfig();Super::Deinitialize();}
bool UCameraLightingViewportTools::Tick(float){if(!GEditor || GEditor->PlayWorld)return true;if(auto Editor=FModuleManager::LoadModuleChecked<FLevelEditorModule>(TEXT("LevelEditor")).GetFirstLevelEditor()){auto V=Editor->GetActiveViewportInterface();if(V && V!=Attached.Pin()){if(auto Old=Attached.Pin())if(Overlay)Old->RemoveOverlayWidget(Overlay.ToSharedRef());Overlay=MakeCameraLightingGuidesOverlay();V->AddOverlayWidget(Overlay.ToSharedRef(),20);Attached=V;}}return true;}
void UCameraLightingViewportTools::SetGuide(FName N,bool B){if(N==TEXT("Thirds"))bThirds=B;else if(N==TEXT("Center"))bCenter=B;else if((N==TEXT("Safe") || N==TEXT("Safe areas")))bSafeAreas=B;else if(N==TEXT("Crop"))bCropGuide=B;else if(N==TEXT("Golden ratio"))bGoldenRatio=B;else if(N==TEXT("Diagonals"))bDiagonals=B;else if(N==TEXT("Golden triangle"))bTriangle=B;else if(N==TEXT("Golden spiral"))bSpiral=B;else if(N==TEXT("Horizon"))bHorizon=B;else if(N==TEXT("Square 1:1"))bSquare=B;else if(N==TEXT("Cinema 2.39"))bLetterbox=B;SaveConfig();if(auto V=VClient())V->Invalidate();}
void UCameraLightingViewportTools::PilotScene(AActor* Camera){if(!Camera || !GEditor || GEditor->PlayWorld)return;GEditor->GetEditorSubsystem<UCameraLightingClipService>()->StopPreview();if(auto V=VClient()){V->SetActorLock(Camera);V->UpdateViewForLockedActor();V->Invalidate();}GEditor->GetEditorSubsystem<UCameraLightingEditorSubsystem>()->PilotCamera(Camera);GEditor->GetEditorSubsystem<UCameraLightingRenderService>()->SetSelectedCamera(Camera);}
void UCameraLightingViewportTools::ExitPilot(){if(!GEditor)return;GEditor->GetEditorSubsystem<UCameraLightingClipService>()->StopPreview();if(auto* V=VClient()){const FVector P=V->GetViewLocation();const FRotator R=V->GetViewRotation();V->SetActorLock(nullptr);V->SetCinematicActorLock(nullptr);V->SetViewLocation(P);V->SetViewRotation(R);V->Invalidate();}bPickingFocus=false;Status=TEXT("Free perspective viewport");}
bool UCameraLightingViewportTools::IsPiloting(){auto* V=VClient();return V && V->GetActiveActorLock().IsValid();}
bool UCameraLightingViewportTools::ArmFocusPick(bool TrackActor){auto* T=GEditor?GEditor->GetEditorSubsystem<UCameraLightingCameraTools>():nullptr;auto* C=T?T->GetCamera():nullptr;if(!C || GEditor->PlayWorld)return false;PilotScene(C->GetOwner());bPickingFocus=true;bTrackPick=TrackActor;Tick(0);if(Overlay)FSlateApplication::Get().SetKeyboardFocus(Overlay,EFocusCause::SetDirectly);Status=TEXT("Click a subject in the perspective viewport; Esc cancels.");return true;}
void UCameraLightingViewportTools::CancelFocusPick(){bPickingFocus=false;Status=TEXT("Focus picking canceled");}
bool UCameraLightingViewportTools::FocusWorldPoint(FVector P,AActor* Track){auto* T=GEditor?GEditor->GetEditorSubsystem<UCameraLightingCameraTools>():nullptr;auto* C=T?T->GetCamera():nullptr;if(!C || GEditor->PlayWorld)return false;const float Distance=FVector::DotProduct(P-C->GetComponentLocation(),C->GetForwardVector());if(Distance<=0){Status=TEXT("Subject is behind the camera.");return false;}if(Track && T->GetCineCamera())T->SetFocusTarget(Track);else{T->SetFocusMethod(1);T->SetValue(TEXT("Focus"),Distance);}bPickingFocus=false;Status=FString::Printf(TEXT("Focus %.1f cm"),Distance);return true;}
bool UCameraLightingViewportTools::PickFocusAtPixel(FVector2D Pixel){auto* V=VClient();if(!V || !V->Viewport || !V->GetWorld())return false;FSceneViewFamilyContext Family(FSceneViewFamily::ConstructionValues(V->Viewport,V->GetWorld()->Scene,V->EngineShowFlags).SetRealtimeUpdate(true));FSceneView* View=V->CalcSceneView(&Family);if(!View)return false;FViewportCursorLocation Cursor(View,V,FMath::RoundToInt(Pixel.X),FMath::RoundToInt(Pixel.Y));FHitResult Hit;FCollisionQueryParams Params(SCENE_QUERY_STAT(CameraFocusPick),true);if(auto* C=GEditor->GetEditorSubsystem<UCameraLightingCameraTools>()->GetCamera())Params.AddIgnoredActor(C->GetOwner());if(V->GetWorld()->LineTraceSingleByChannel(Hit,Cursor.GetOrigin(),Cursor.GetOrigin()+Cursor.GetDirection()*1000000,ECC_Visibility,Params))return FocusWorldPoint(Hit.ImpactPoint,bTrackPick?Hit.GetActor():nullptr);Status=TEXT("No surface hit. Click a visible subject or press Esc.");return false;}
FVector2D UCameraLightingViewportTools::ProjectWorldPoint(FVector P){auto* V=VClient();if(!V || !V->Viewport)return FVector2D(-1,-1);FSceneViewFamilyContext Family(FSceneViewFamily::ConstructionValues(V->Viewport,V->GetWorld()->Scene,V->EngineShowFlags).SetRealtimeUpdate(true));auto* View=V->CalcSceneView(&Family);FVector2D Result(-1,-1);if(View)View->WorldToPixel(P,Result);return Result;}

bool UCameraLightingViewportTools::IsGuideEnabled(FName N)const{if(N==TEXT("Thirds"))return bThirds;if(N==TEXT("Center"))return bCenter;if(N==TEXT("Safe areas"))return bSafeAreas;if(N==TEXT("Crop"))return bCropGuide;if(N==TEXT("Golden ratio"))return bGoldenRatio;if(N==TEXT("Diagonals"))return bDiagonals;if(N==TEXT("Golden triangle"))return bTriangle;if(N==TEXT("Golden spiral"))return bSpiral;if(N==TEXT("Horizon"))return bHorizon;if(N==TEXT("Square 1:1"))return bSquare;if(N==TEXT("Cinema 2.39"))return bLetterbox;return false;}
