#include "CameraLightingPipelineTools.h"
#include "CameraLightingProfile.h"
#include "Framework/Application/SlateApplication.h"
#include "Engine/Texture2D.h"
#include "UObject/StrongObjectPtr.h"
#include "CameraLightingClips.h"
#include "DragAndDrop/ActorDragDropOp.h"
#include "CameraLightingRenderWidgets.h"
#include "CameraLightingTimelineRange.h"
#include "Widgets/Input/SCheckBox.h"
#include "CameraLightingMinimalWidgets.h"
#include "CameraLightingRenderService.h"
#include "CameraLightingEditorModule.h"
#include "CameraLightingStyle.h"
#include "Editor.h"
#include "EngineUtils.h"
#include "Camera/CameraComponent.h"
#include "Widgets/SCompoundWidget.h"
#include "Widgets/SLeafWidget.h"
#include "Widgets/Layout/SBorder.h"
#include "Widgets/Layout/SBox.h"
#include "Widgets/Layout/SScrollBox.h"
#include "Widgets/Layout/SWrapBox.h"
#include "Widgets/SOverlay.h"
#include "Widgets/Input/SButton.h"
#include "Widgets/Input/SComboButton.h"
#include "Widgets/Text/STextBlock.h"
#include "Widgets/Text/SInlineEditableTextBlock.h"
#include "Framework/MultiBox/MultiBoxBuilder.h"
#include "Rendering/DrawElements.h"
namespace
{
UCameraLightingClipService* ClipUI(){return GEditor?GEditor->GetEditorSubsystem<UCameraLightingClipService>():nullptr;}
FLinearColor ClipColor(int32 R,int32 G,int32 B){return FLinearColor::FromSRGBColor(FColor(R,G,B));}
TSharedRef<STextBlock> ClipText(const FString& T,int32 Size=9){return SNew(STextBlock).Text(FText::FromString(T)).Font(CameraLightingStyle::Font(Size));}
int32 ShotIndex(const FString& Id){auto* C=ClipUI()->SelectedClip.Get();return C?C->Shots.IndexOfByPredicate([&](const auto& S){return S.Id==Id;}):INDEX_NONE;}
TSharedRef<SWidget> ClipButton(const FString& T,TFunction<void()> Action,bool Primary=false){return SNew(SButton).ButtonStyle(&CameraLightingStyle::Button()).ButtonColorAndOpacity(Primary?ClipColor(0,120,255):ClipColor(37,39,46)).ContentPadding(FMargin(10,7)).HAlign(HAlign_Center).IsEnabled_Lambda([]{return GEditor && !GEditor->GetEditorSubsystem<UCameraLightingRenderService>()->IsRendering() && !ClipUI()->bRecording;}).OnClicked_Lambda([Action]{Action();return FReply::Handled();})[ClipText(T)];}
TSharedRef<SWidget> ClipIcon(const TCHAR* Kind,const TCHAR* Tip,TFunction<void()> Action,bool Primary=false){return SNew(SButton).ButtonStyle(&CameraLightingStyle::Button()).ButtonColorAndOpacity(Primary?ClipColor(0,120,255):ClipColor(37,39,46)).ToolTipText(FText::FromString(Tip)).ContentPadding(FMargin(9,7)).IsEnabled_Lambda([]{return !GEditor->GetEditorSubsystem<UCameraLightingRenderService>()->IsRendering() && !GEditor->GetEditorSubsystem<UCameraLightingPipelineTools>()->IsBusy() && !ClipUI()->bRecording;}).OnClicked_Lambda([Action]{Action();return FReply::Handled();})[SNew(SBox).WidthOverride(20).HeightOverride(20)[MakeCameraLightingGlyph(Kind,20)]];}
class SClipRuler : public SLeafWidget
{
public:
 SLATE_BEGIN_ARGS(SClipRuler){}SLATE_END_ARGS()
 void Construct(const FArguments&){SetCursor(EMouseCursor::ResizeLeftRight);SetToolTipText(FText::FromString(TEXT("Ctrl + wheel: zoom at pointer. Wheel / middle drag: pan. Left drag: scrub. F: fit clip. Frame snap can be toggled above.")));}
 virtual bool SupportsKeyboardFocus()const override{return true;}
 void Ensure()const{auto* S=ClipUI();auto* C=S?S->SelectedClip.Get():nullptr;if(!C)return;if(Clip!=C){Clip=C;Range.Fit(C->Duration);LastDuration=C->Duration;}else if(!FMath::IsNearlyEqual(LastDuration,double(C->Duration))){if(FMath::IsNearlyZero(Range.Start) && FMath::IsNearlyEqual(Range.Span,LastDuration))Range.Fit(C->Duration);LastDuration=C->Duration;}}
 void Fit(){Ensure();if(Clip.IsValid())Range.Fit(Clip->Duration);Invalidate(EInvalidateWidgetReason::Paint);}
 void Zoom(float Steps,float Anchor=.5f){Ensure();Range.Zoom(Steps,Anchor,Clip.IsValid()?Clip->FrameRate:24);Invalidate(EInvalidateWidgetReason::Paint);}
 void SetSnap(bool Enabled){bSnap=Enabled;}
 FCameraLightingTimelineRange GetRange()const{Ensure();return Range;}
 virtual FVector2D ComputeDesiredSize(float)const override{return FVector2D(400,50);}
 virtual int32 OnPaint(const FPaintArgs&,const FGeometry& G,const FSlateRect&,FSlateWindowElementList& Out,int32 L,const FWidgetStyle&,bool)const override
 {
  Ensure();auto* S=ClipUI();if(!S || !Clip.IsValid())return L;const float W=G.GetLocalSize().X,H=G.GetLocalSize().Y;const double Step=Range.TickStep(W,Clip->FrameRate);const double First=FMath::CeilToDouble(Range.Start/Step)*Step;
  for(double T=First;T<=Range.Start+Range.Span+Step*.001;T+=Step){const float X=(T-Range.Start)/Range.Span*W;TArray<FVector2D>P{{X,H-12},{X,H}};FSlateDrawElement::MakeLines(Out,L+1,G.ToPaintGeometry(),P,ESlateDrawEffect::None,ClipColor(100,108,122),true,1);const FString Label=Step<1?FString::Printf(TEXT("%.3fs"),T):FString::Printf(TEXT("%.0fs"),T);if(X<W-55)FSlateDrawElement::MakeText(Out,L+1,G.ToPaintGeometry(FVector2D(90,20),FSlateLayoutTransform(FVector2D(FMath::Min(X,W-65),4))),Label,CameraLightingStyle::Font(8),ESlateDrawEffect::None,ClipColor(153,161,174));}
  if(Range.Span*Clip->FrameRate<180){const double Frame=1./Clip->FrameRate;for(double T=FMath::CeilToDouble(Range.Start/Frame)*Frame;T<Range.Start+Range.Span;T+=Frame){const float X=(T-Range.Start)/Range.Span*W;TArray<FVector2D>P{{X,H-5},{X,H}};FSlateDrawElement::MakeLines(Out,L+1,G.ToPaintGeometry(),P,ESlateDrawEffect::None,ClipColor(75,82,94),true,1);}}
  for(int I=0;I<Clip->Shots.Num();++I){const double Time=Clip->Shots[I].Start;const float X=(Time-Range.Start)/Range.Span*W;if(X>=0 && X<=W){TArray<FVector2D>P{{X,25},{X+4,29},{X,33},{X-4,29},{X,25}};FSlateDrawElement::MakeLines(Out,L+2,G.ToPaintGeometry(),P,ESlateDrawEffect::None,ClipColor(120,172,244),true,1.3f);}}
  const float End=(Clip->Duration-Range.Start)/Range.Span*W;if(End>=0 && End<=W){TArray<FVector2D>P{{FMath::Min(End,W-1),24},{FMath::Min(End,W-1),H}};FSlateDrawElement::MakeLines(Out,L+1,G.ToPaintGeometry(),P,ESlateDrawEffect::None,ClipColor(208,147,73),true,2);}
  const float X=(S->GetPlayhead()-Range.Start)/Range.Span*W;if(X>=0 && X<=W){TArray<FVector2D>P{{X,0},{X,H}};FSlateDrawElement::MakeLines(Out,L+2,G.ToPaintGeometry(),P,ESlateDrawEffect::None,ClipColor(0,120,255),true,2);}return L+2;
 }
 void Scrub(const FGeometry& G,const FPointerEvent& E){Ensure();if(auto* S=ClipUI())if(Clip.IsValid()){double Time=Range.At(G.AbsoluteToLocal(E.GetScreenSpacePosition()).X/FMath::Max(G.GetLocalSize().X,1.));if(bSnap)Time=FMath::RoundToDouble(Time*Clip->FrameRate)/Clip->FrameRate;S->Scrub(FMath::Clamp(float(Time),0.f,Clip->Duration));}}
 virtual FReply OnMouseWheel(const FGeometry& G,const FPointerEvent& E)override{Ensure();if(E.IsControlDown())Zoom(E.GetWheelDelta(),FMath::Clamp(float(G.AbsoluteToLocal(E.GetScreenSpacePosition()).X/FMath::Max(G.GetLocalSize().X,1.)),0.f,1.f));else Range.Pan(-E.GetWheelDelta()*Range.Span*.12);Invalidate(EInvalidateWidgetReason::Paint);return FReply::Handled();}
 virtual FReply OnMouseButtonDown(const FGeometry& G,const FPointerEvent& E)override{if(E.GetEffectingButton()==EKeys::MiddleMouseButton || E.GetEffectingButton()==EKeys::RightMouseButton){bPanning=true;return FReply::Handled().CaptureMouse(SharedThis(this)).SetUserFocus(SharedThis(this),EFocusCause::Mouse);}if(E.GetEffectingButton()==EKeys::LeftMouseButton){bPanning=false;Scrub(G,E);return FReply::Handled().CaptureMouse(SharedThis(this)).SetUserFocus(SharedThis(this),EFocusCause::Mouse);}return FReply::Unhandled();}
 virtual FReply OnMouseMove(const FGeometry& G,const FPointerEvent& E)override{if(HasMouseCapture()){if(bPanning)Range.Pan(-E.GetCursorDelta().X/FMath::Max(G.GetLocalSize().X,1.)*Range.Span);else Scrub(G,E);Invalidate(EInvalidateWidgetReason::Paint);return FReply::Handled();}return FReply::Unhandled();}
 virtual FReply OnMouseButtonUp(const FGeometry&,const FPointerEvent&)override{bPanning=false;return FReply::Handled().ReleaseMouseCapture();}
 virtual FReply OnKeyDown(const FGeometry&,const FKeyEvent& E)override{if(E.GetKey()==EKeys::F){Fit();return FReply::Handled();}return FReply::Unhandled();}
private:mutable FCameraLightingTimelineRange Range;mutable TWeakObjectPtr<UCameraLightingClip> Clip;mutable double LastDuration=3;bool bPanning=false,bSnap=true;
};
class STimedShots : public SLeafWidget
{
public:
 SLATE_BEGIN_ARGS(STimedShots){} SLATE_ARGUMENT(TSharedPtr<SClipRuler>,Ruler) SLATE_END_ARGS()
 void Construct(const FArguments& A){Ruler=A._Ruler;SetToolTipText(FText::FromString(TEXT("Drag a shot to move it. Drag either edge to trim. Right-click to edit exact timing or add a motion view. Ctrl + wheel zooms the timeline.")));}
 virtual FVector2D ComputeDesiredSize(float)const override{return {500,130};}
 virtual FCursorReply OnCursorQuery(const FGeometry& G,const FPointerEvent& E)const override{int32 I,HitMode;Hit(G,E,I,HitMode);return FCursorReply::Cursor(I<0?EMouseCursor::Default:HitMode==0?EMouseCursor::GrabHand:EMouseCursor::ResizeLeftRight);}
 void Hit(const FGeometry& G,const FPointerEvent& E,int32& I,int32& HitMode)const{I=-1;HitMode=0;auto* C=ClipUI()->SelectedClip.Get();if(!C || !Ruler)return;const auto R=Ruler->GetRange();const float X=G.AbsoluteToLocal(E.GetScreenSpacePosition()).X,W=G.GetLocalSize().X;for(int32 N=0;N<C->Shots.Num();++N){const auto& S=C->Shots[N];const float A=(S.Start-R.Start)/R.Span*W,B=(S.Start+S.Length-R.Start)/R.Span*W;if(X>=A && X<=B){I=N;HitMode=X-A<8?1:B-X<8?2:0;return;}}}
 virtual int32 OnPaint(const FPaintArgs&,const FGeometry& G,const FSlateRect&,FSlateWindowElementList& Out,int32 L,const FWidgetStyle&,bool)const override
 {
  auto* C=ClipUI()->SelectedClip.Get();if(!C || !Ruler)return L;auto R=Ruler->GetRange();const float W=G.GetLocalSize().X;
  Out.PushClip(FSlateClippingZone(G));for(int32 I=0;I<C->Shots.Num();++I){const auto& S=C->Shots[I];const float Start=I==Drag?PendingStart:S.Start,Length=I==Drag?PendingLength:S.Length;const float A=(Start-R.Start)/R.Span*W,B=(Start+Length-R.Start)/R.Span*W;const float Width=FMath::Max(B-A,2.f);const auto AbsMin=G.LocalToAbsolute(FVector2D(A+1,0)),AbsMax=G.LocalToAbsolute(FVector2D(B-1,130));Out.PushClip(FSlateClippingZone(FSlateRect(AbsMin.X,AbsMin.Y,AbsMax.X,AbsMax.Y)));auto P=G.ToPaintGeometry(FVector2D(Width,120),FSlateLayoutTransform(FVector2D(A,4)));FSlateDrawElement::MakeBox(Out,L+1,P,FAppStyle::GetBrush("WhiteBrush"),ESlateDrawEffect::None,ClipColor(S.Id==ClipUI()->SelectedShotId?32:36,S.Id==ClipUI()->SelectedShotId?78:56,S.Id==ClipUI()->SelectedShotId?123:81));
   if(Width>55){const FString Text=FString::Printf(TEXT("%s · %.2fs"),*S.Label,Length);FSlateDrawElement::MakeText(Out,L+3,G.ToPaintGeometry(FVector2D(Width-16,20),FSlateLayoutTransform(FVector2D(A+8,10))),Text,CameraLightingStyle::Font(9),ESlateDrawEffect::None,FLinearColor::White);if(!S.Views.IsEmpty() && S.Views[0].Lighting){auto* Source=S.Views[0].Lighting->PreviewImage.LoadSynchronous();if(Source){auto& Cache=Textures.FindOrAdd(Source);if(!Cache.IsValid()){TArray64<uint8> Data;if(Source->Source.GetMipData(Data,0)){auto* T=UTexture2D::CreateTransient(Source->Source.GetSizeX(),Source->Source.GetSizeY(),PF_B8G8R8A8);auto& M=T->GetPlatformData()->Mips[0];void* Dest=M.BulkData.Lock(LOCK_READ_WRITE);FMemory::Memcpy(Dest,Data.GetData(),FMath::Min<int64>(Data.Num(),M.BulkData.GetBulkDataSize()));M.BulkData.Unlock();T->SRGB=true;T->UpdateResource();Cache.Reset(T);}}if(Cache.IsValid()){FSlateBrush Brush;Brush.SetResourceObject(Cache.Get());Brush.DrawAs=ESlateBrushDrawType::Image;const float H=74,VW=FMath::Min(Width-16,H*Cache->GetSizeX()/Cache->GetSizeY());FSlateDrawElement::MakeBox(Out,L+2,G.ToPaintGeometry(FVector2D(VW,H),FSlateLayoutTransform(FVector2D(A+8,35))),&Brush,ESlateDrawEffect::None,FLinearColor::White);}}}}
   for(float X:{A+3,B-3}){TArray<FVector2D>Pnts{{X,36},{X,90}};FSlateDrawElement::MakeLines(Out,L+4,G.ToPaintGeometry(),Pnts,ESlateDrawEffect::None,ClipColor(129,155,188),true,2);}
   Out.PopClip();
  }Out.PopClip();return L+4;
 }
 virtual FReply OnDragOver(const FGeometry&,const FDragDropEvent& E)override{auto Op=E.GetOperationAs<FActorDragDropOp>();if(Op)for(auto A:Op->Actors)if(A.IsValid() && A->FindComponentByClass<UCameraComponent>())return FReply::Handled();return FReply::Unhandled();}
 virtual FReply OnDrop(const FGeometry& G,const FDragDropEvent& E)override{auto Op=E.GetOperationAs<FActorDragDropOp>();if(!Op)return FReply::Unhandled();double Time=Ruler->GetRange().At(G.AbsoluteToLocal(E.GetScreenSpacePosition()).X/FMath::Max(G.GetLocalSize().X,1.));bool Added=false;for(auto A:Op->Actors)if(A.IsValid() && A->FindComponentByClass<UCameraComponent>()){if(ClipUI()->DropCamera(A.Get(),FMath::Max(0.f,float(Time)))){Added=true;Time+=3;}}if(Added){FCameraLightingEditorModule::OpenTab(FCameraLightingEditorModule::CameraTabId);return FReply::Handled();}return FReply::Unhandled();}
 virtual FReply OnMouseWheel(const FGeometry& G,const FPointerEvent& E)override{return Ruler->OnMouseWheel(G,E);}
 virtual FReply OnMouseButtonDown(const FGeometry& G,const FPointerEvent& E)override
 {
  int32 I,M;Hit(G,E,I,M);if(I<0)return FReply::Unhandled();auto* C=ClipUI()->SelectedClip.Get();if(E.GetEffectingButton()==EKeys::RightMouseButton || (E.GetEffectingButton()==EKeys::LeftMouseButton && M==0 && G.AbsoluteToLocal(E.GetScreenSpacePosition()).Y<31)){const FString ShotId=C->Shots[I].Id;FMenuBuilder Menu(true,nullptr);Menu.AddMenuEntry(FText::FromString(TEXT("Camera settings")),FText(),FSlateIcon(),FUIAction(FExecuteAction::CreateLambda([ShotId]{ClipUI()->SelectShot(ShotIndex(ShotId),true);})));Menu.AddWidget(SNew(SVerticalBox)+SVerticalBox::Slot().AutoHeight()[ClipText(TEXT("Start (seconds)"))]+SVerticalBox::Slot().AutoHeight()[MakeCameraLightingDragNumber([ShotId]{const int32 N=ShotIndex(ShotId);return N>=0?ClipUI()->SelectedClip->Shots[N].Start:0.f;},[ShotId](float V){const int32 N=ShotIndex(ShotId);if(N>=0){auto S=ClipUI()->SelectedClip->Shots[N];ClipUI()->SetShotRange(N,V,S.Length);}},0,86400,.1f,3)]+SVerticalBox::Slot().AutoHeight()[ClipText(TEXT("Length (seconds)"))]+SVerticalBox::Slot().AutoHeight()[MakeCameraLightingDragNumber([ShotId]{const int32 N=ShotIndex(ShotId);return N>=0?ClipUI()->SelectedClip->Shots[N].Length:0.f;},[ShotId](float V){const int32 N=ShotIndex(ShotId);if(N>=0){auto S=ClipUI()->SelectedClip->Shots[N];ClipUI()->SetShotRange(N,S.Start,V);}},.00834,86400,.1f,3)],FText());Menu.AddMenuEntry(FText::FromString(TEXT("Add motion view from viewport")),FText(),FSlateIcon(),FUIAction(FExecuteAction::CreateLambda([ShotId]{ClipUI()->AddMotionView(ShotIndex(ShotId));})));Menu.AddMenuEntry(FText::FromString(TEXT("Update first view")),FText(),FSlateIcon(),FUIAction(FExecuteAction::CreateLambda([ShotId]{ClipUI()->UpdateView(ShotIndex(ShotId));})));Menu.AddMenuEntry(FText::FromString(TEXT("Remove shot")),FText(),FSlateIcon(),FUIAction(FExecuteAction::CreateLambda([ShotId]{ClipUI()->RemoveView(ShotIndex(ShotId));})));FSlateApplication::Get().PushMenu(AsShared(),FWidgetPath(),Menu.MakeWidget(),E.GetScreenSpacePosition(),FPopupTransitionEffect::ContextMenu);return FReply::Handled();}
  if(E.GetEffectingButton()!=EKeys::LeftMouseButton)return FReply::Unhandled();Drag=I;Mode=M;OriginalStart=PendingStart=C->Shots[I].Start;OriginalLength=PendingLength=C->Shots[I].Length;Anchor=G.AbsoluteToLocal(E.GetScreenSpacePosition()).X;return FReply::Handled().CaptureMouse(SharedThis(this));
 }
 virtual FReply OnMouseMove(const FGeometry& G,const FPointerEvent& E)override{if(Drag<0)return FReply::Unhandled();const float Delta=(G.AbsoluteToLocal(E.GetScreenSpacePosition()).X-Anchor)/G.GetLocalSize().X*Ruler->GetRange().Span;auto* C=ClipUI()->SelectedClip.Get();const float Frame=1.f/C->FrameRate;auto Snap=[C](float V){return FMath::RoundToFloat(V*C->FrameRate)/C->FrameRate;};if(Mode==0)PendingStart=FMath::Max(0.f,Snap(OriginalStart+Delta));else if(Mode==1){const float Min=Drag>0?C->Shots[Drag-1].Start+C->Shots[Drag-1].Length:0;PendingStart=FMath::Clamp(Snap(OriginalStart+Delta),Min,OriginalStart+OriginalLength-Frame);PendingLength=OriginalStart+OriginalLength-PendingStart;}else PendingLength=FMath::Max(Frame,Snap(OriginalLength+Delta));Invalidate(EInvalidateWidgetReason::Paint);return FReply::Handled();}
 virtual FReply OnMouseButtonUp(const FGeometry&,const FPointerEvent&)override{if(Drag<0)return FReply::Unhandled();const int32 I=Drag;Drag=-1;auto* C=ClipUI()->SelectedClip.Get();const FString Id=C->Shots[I].Id;if(Mode==0 && FMath::IsNearlyEqual(OriginalStart,PendingStart))ClipUI()->SelectShot(I,true);else{ClipUI()->SetShotRange(I,PendingStart,PendingLength);ClipUI()->SelectShot(ShotIndex(Id),false);}return FReply::Handled().ReleaseMouseCapture();}

 virtual void OnMouseCaptureLost(const FCaptureLostEvent&)override{Drag=-1;Invalidate(EInvalidateWidgetReason::Paint);}
private:TSharedPtr<SClipRuler> Ruler;int32 Drag=-1,Mode=0;float Anchor=0,OriginalStart=0,OriginalLength=0,PendingStart=0,PendingLength=0;mutable TMap<UTexture2D*,TStrongObjectPtr<UTexture2D>> Textures;
};
class SMinimalClipsPanel : public SCompoundWidget
{
public:
 SLATE_BEGIN_ARGS(SMinimalClipsPanel){}SLATE_END_ARGS()
 void Construct(const FArguments&)
 {
  ClipUI()->OnChanged.AddSP(this,&SMinimalClipsPanel::Refresh);ClipUI()->GetClips();if(!ClipUI()->SelectedClip && !ClipUI()->Clips.IsEmpty())ClipUI()->SelectClip(ClipUI()->Clips[0]);
  ChildSlot[SNew(SBorder).BorderImage(FAppStyle::GetBrush("WhiteBrush")).BorderBackgroundColor(ClipColor(26,29,37)).Padding(0)[SNew(SOverlay)+SOverlay::Slot()[MakeCameraLightingCornerArt()]+SOverlay::Slot()[SNew(SHorizontalBox)
  +SHorizontalBox::Slot().AutoWidth()[SNew(SBox).WidthOverride(170)[SNew(SBorder).BorderImage(FAppStyle::GetBrush("WhiteBrush")).BorderBackgroundColor(ClipColor(23,26,33)).Padding(12)[SNew(SVerticalBox)
  +SVerticalBox::Slot().AutoHeight().Padding(0,0,0,12)[SNew(SHorizontalBox)+SHorizontalBox::Slot().FillWidth(1)[ClipText(TEXT("Clips"),10)]+SHorizontalBox::Slot().AutoWidth()[ClipButton(TEXT("+"),[]{ClipUI()->CreateClip();})]]
  +SVerticalBox::Slot().FillHeight(1)[SNew(SScrollBox)+SScrollBox::Slot()[SAssignNew(ClipList,SVerticalBox)]]]]]
  +SHorizontalBox::Slot().FillWidth(1)[SNew(SVerticalBox)
  +SVerticalBox::Slot().AutoHeight().Padding(14,10)[SNew(SWrapBox).UseAllottedSize(true).InnerSlotPadding(FVector2D(8,8))
   +SWrapBox::Slot()[ClipButton(TEXT("|<"),[]{if(auto* S=ClipUI())S->Scrub(0);})]
   +SWrapBox::Slot()[SNew(SButton).ButtonStyle(&CameraLightingStyle::Button()).ButtonColorAndOpacity(ClipColor(37,39,46)).ContentPadding(FMargin(12,7)).OnClicked_Lambda([]{ClipUI()->TogglePlay();return FReply::Handled();})[SNew(STextBlock).Text_Lambda([]{return FText::FromString(ClipUI()->IsPlaying()?TEXT("Pause"):TEXT("Play"));})]]
   +SWrapBox::Slot()[ClipButton(TEXT(">|"),[]{auto* S=ClipUI();if(S->SelectedClip)S->Scrub(S->SelectedClip->Duration);})]
   +SWrapBox::Slot()[ClipButton(TEXT("Stop"),[]{ClipUI()->StopPreview();})]
   +SWrapBox::Slot()[SNew(SBox).WidthOverride(78)[MakeCameraLightingDragNumber([]{return ClipUI()->SelectedClip?ClipUI()->SelectedClip->Duration:3.f;},[](float V){ClipUI()->SetDuration(V);},.1f,86400,.1f,2)]]
   +SWrapBox::Slot()[ClipText(TEXT("end (s)"))]
   +SWrapBox::Slot()[SNew(SBox).WidthOverride(58)[MakeCameraLightingDragNumber([]{return ClipUI()->SelectedClip?float(ClipUI()->SelectedClip->FrameRate):24.f;},[](float V){ClipUI()->SetFrameRate(FMath::RoundToInt(V));},1,120,1,0)]]
   +SWrapBox::Slot()[ClipText(TEXT("fps"))]
   +SWrapBox::Slot()[ClipButton(TEXT("-"),[this]{if(Ruler)Ruler->Zoom(-1);})]
   +SWrapBox::Slot()[ClipButton(TEXT("+"),[this]{if(Ruler)Ruler->Zoom(1);})]
   +SWrapBox::Slot()[ClipButton(TEXT("Fit"),[this]{if(Ruler)Ruler->Fit();})]
   +SWrapBox::Slot()[SNew(SCheckBox).IsChecked(ECheckBoxState::Checked).OnCheckStateChanged_Lambda([this](ECheckBoxState S){if(Ruler)Ruler->SetSnap(S==ECheckBoxState::Checked);})[ClipText(TEXT("Frame snap"),8)]]
   +SWrapBox::Slot()[SNew(STextBlock).Text_Lambda([]{auto* S=ClipUI();return FText::FromString(FString::Printf(TEXT("%.3fs · f%d / %.2fs"),S->GetPlayhead(),FMath::RoundToInt(S->GetPlayhead()*(S->SelectedClip?S->SelectedClip->FrameRate:24)),S->SelectedClip?S->SelectedClip->Duration:0));}).Font(CameraLightingStyle::Font(9))]]
  +SVerticalBox::Slot().AutoHeight().Padding(14,4)[SNew(SWrapBox).UseAllottedSize(true).InnerSlotPadding(FVector2D(10,6))
   +SWrapBox::Slot()[SNew(SButton).ButtonStyle(&CameraLightingStyle::Button()).ButtonColorAndOpacity_Lambda([]{return ClipUI()->bRecording?ClipColor(170,35,45):ClipColor(70,30,38);}).ContentPadding(FMargin(12,7)).IsEnabled_Lambda([]{return !GEditor->GetEditorSubsystem<UCameraLightingRenderService>()->IsRendering();}).OnClicked_Lambda([]{if(ClipUI()->bRecording)ClipUI()->StopRecording(true);else ClipUI()->StartRecording();return FReply::Handled();})[SNew(STextBlock).Font(CameraLightingStyle::Font(9)).Text_Lambda([]{return FText::FromString(ClipUI()->bRecording?TEXT("Stop recording"):TEXT("Record viewport"));})]]
   +SWrapBox::Slot()[SNew(SButton).Visibility_Lambda([]{return ClipUI()->bRecording?EVisibility::Visible:EVisibility::Collapsed;}).ButtonStyle(&CameraLightingStyle::Button()).ButtonColorAndOpacity(ClipColor(37,39,46)).ContentPadding(8).OnClicked_Lambda([]{ClipUI()->StopRecording(false);return FReply::Handled();})[ClipText(TEXT("Discard"))]]
   +SWrapBox::Slot().VAlign(VAlign_Center)[ClipText(TEXT("Record FPS"))]
   +SWrapBox::Slot()[SNew(SBox).WidthOverride(64).IsEnabled_Lambda([]{return !ClipUI()->bRecording;})[MakeCameraLightingDragNumber([]{return float(ClipUI()->RecordFPS);},[](float V){ClipUI()->RecordFPS=FMath::RoundToInt(V);ClipUI()->SaveConfig();},1,120,1,0)]]
   +SWrapBox::Slot()[SNew(SComboButton).ButtonStyle(&CameraLightingStyle::Button()).ButtonColorAndOpacity(ClipColor(37,39,46)).ContentPadding(8).IsEnabled_Lambda([]{return !ClipUI()->bRecording;}).OnGetMenuContent_Lambda([]{FMenuBuilder M(true,nullptr);for(auto V:{ECameraLightingInterpolation::Linear,ECameraLightingInterpolation::Smooth,ECameraLightingInterpolation::Constant})M.AddMenuEntry(FText::FromString(V==ECameraLightingInterpolation::Linear?TEXT("Linear"):V==ECameraLightingInterpolation::Smooth?TEXT("Smooth (ease between keys)"):TEXT("Constant (hold)")),FText(),FSlateIcon(),FUIAction(FExecuteAction::CreateLambda([V]{ClipUI()->SetInterpolation(V);})));return M.MakeWidget();}).ButtonContent()[SNew(STextBlock).Font(CameraLightingStyle::Font(9)).Text_Lambda([]{auto V=ClipUI()->GetInterpolation();return FText::FromString(V==ECameraLightingInterpolation::Linear?TEXT("Linear"):V==ECameraLightingInterpolation::Smooth?TEXT("Smooth"):TEXT("Constant"));})]]
   +SWrapBox::Slot().VAlign(VAlign_Center)[SNew(STextBlock).Font(CameraLightingStyle::Font(9)).Text_Lambda([]{return ClipUI()->bRecording?FText::FromString(FString::Printf(TEXT("REC %.2fs · %d frames"),ClipUI()->GetRecordingSeconds(),ClipUI()->GetRecordedFrameCount())):FText::GetEmpty();})]]
  +SVerticalBox::Slot().AutoHeight().Padding(14,0)[SAssignNew(Ruler,SClipRuler)]
  +SVerticalBox::Slot().AutoHeight().Padding(14,8)[SNew(STimedShots).Ruler(Ruler)]
  +SVerticalBox::Slot().AutoHeight().Padding(14,0,14,4)[ClipText(TEXT("Drop cameras here · Click thumbnail: camera settings · Drag: move / trim · Click time: timing"),8)]
  +SVerticalBox::Slot().AutoHeight().Padding(14,8)[SNew(SWrapBox).UseAllottedSize(true).InnerSlotPadding(FVector2D(8,8))
   +SWrapBox::Slot()[ClipButton(TEXT("+ Shot from viewport"),[]{ClipUI()->AddView();})]
   +SWrapBox::Slot()[SNew(SComboButton).ButtonStyle(&CameraLightingStyle::Button()).ButtonColorAndOpacity(ClipColor(37,39,46)).ContentPadding(FMargin(10,7)).OnGetMenuContent_Lambda([]{FMenuBuilder M(true,nullptr);if(GEditor)if(auto* W=GEditor->GetEditorWorldContext().World())for(TActorIterator<AActor>I(W);I;++I)if(!I->HasAnyFlags(RF_Transient) && I->FindComponentByClass<UCameraComponent>()){TWeakObjectPtr<AActor>A=*I;M.AddMenuEntry(FText::FromString(I->GetActorLabel()),FText(),FSlateIcon(),FUIAction(FExecuteAction::CreateLambda([A]{ClipUI()->AddCameraView(A.Get());})));}return M.MakeWidget();}).ButtonContent()[ClipText(TEXT("+ Camera shot"))]]]
  +SVerticalBox::Slot().AutoHeight().Padding(14,10)[SNew(SWrapBox).UseAllottedSize(true).InnerSlotPadding(FVector2D(8,8))
   +SWrapBox::Slot()[MakeCameraLightingTemplateSelector()]
   +SWrapBox::Slot()[MakeCameraLightingClipVideoControls()]
   +SWrapBox::Slot()[ClipIcon(TEXT("Guides"),TEXT("Preflight and advanced video settings"),[]{FCameraLightingEditorModule::OpenTab(FCameraLightingEditorModule::PipelineTabId);})]
   +SWrapBox::Slot()[ClipIcon(TEXT("Settings"),TEXT("Render settings"),[]{FCameraLightingEditorModule::OpenTab(FCameraLightingEditorModule::ImageTabId);})]
   +SWrapBox::Slot()[ClipIcon(TEXT("Render"),TEXT("Render clip to the selected image/video output"),[]{auto* T=GEditor->GetEditorSubsystem<UCameraLightingPipelineTools>();if(T->bClipVideoDelivery)T->RenderCurrentClipVideo();else ClipUI()->RenderClip();},true)]
   +SWrapBox::Slot()[ClipIcon(TEXT("Draft"),TEXT("Draft preview"),[]{ClipUI()->RenderDraft();})]
   +SWrapBox::Slot()[ClipIcon(TEXT("AddQueue"),TEXT("Add clip to render queue"),[]{ClipUI()->QueueClip();})]
   +SWrapBox::Slot()[SNew(SComboButton).ButtonStyle(&CameraLightingStyle::Button()).ButtonColorAndOpacity(ClipColor(37,39,46)).HasDownArrow(false).OnGetMenuContent_Lambda([]{FMenuBuilder M(true,nullptr);M.AddMenuEntry(FText::FromString(TEXT("Duplicate clip")),FText(),FSlateIcon(),FUIAction(FExecuteAction::CreateLambda([]{ClipUI()->DuplicateClip();})));M.AddMenuEntry(FText::FromString(TEXT("Export copy to Sequencer...")),FText::FromString(TEXT("Independent native sequence; later view-card edits cannot overwrite it.")),FSlateIcon(),FUIAction(FExecuteAction::CreateLambda([]{ClipUI()->ExportToSequencer();})));M.AddMenuEntry(FText::FromString(TEXT("Image / template settings")),FText(),FSlateIcon(),FUIAction(FExecuteAction::CreateLambda([]{FCameraLightingEditorModule::OpenTab(FCameraLightingEditorModule::ImageTabId);})));M.AddMenuEntry(FText::FromString(TEXT("Render Queue")),FText(),FSlateIcon(),FUIAction(FExecuteAction::CreateLambda([]{FCameraLightingEditorModule::OpenTab(FCameraLightingEditorModule::QueueTabId);})));return M.MakeWidget(); }).ButtonContent()[ClipText(TEXT("..."),12)]]
   +SWrapBox::Slot().VAlign(VAlign_Center)[SNew(STextBlock).Text_Lambda([]{auto* R=GEditor->GetEditorSubsystem<UCameraLightingRenderService>();const TCHAR* F=R->Format==ECameraLightingImageFormat::EXR?TEXT("EXR"):R->Format==ECameraLightingImageFormat::PNG?TEXT("PNG"):TEXT("JPEG");return FText::FromString(FString(F)+TEXT(" frame sequence"));}).Font(CameraLightingStyle::Font(9)).ColorAndOpacity(ClipColor(160,168,181))]
   +SWrapBox::Slot().VAlign(VAlign_Center)[SNew(SBox).WidthOverride(230)[SNew(STextBlock).Text_Lambda([]{auto* R=GEditor->GetEditorSubsystem<UCameraLightingRenderService>();auto* T=GEditor->GetEditorSubsystem<UCameraLightingPipelineTools>();if(T->bClipVideoDelivery && !T->Status.IsEmpty())return FText::FromString(T->Status);return FText::FromString((R->IsRendering() || ClipUI()->GetStatus().StartsWith(TEXT("Rendering")))?R->GetProgressText():ClipUI()->GetStatus());}).WrapTextAt(230).Font(CameraLightingStyle::Font(8)).ColorAndOpacity(ClipColor(145,153,166))]]]

  +SVerticalBox::Slot().FillHeight(1)[SNullWidget::NullWidget]]]]];
  Rebuild();
 }
 virtual ~SMinimalClipsPanel(){if(auto* S=ClipUI())S->OnChanged.RemoveAll(this);}
 void Refresh(){bRefresh=true;}
 virtual void Tick(const FGeometry& G,double T,float D)override{SCompoundWidget::Tick(G,T,D);if(bRefresh){bRefresh=false;Rebuild();}}
 void Rebuild()
 {
  ClipList->ClearChildren();auto* S=ClipUI();
  for(auto* C:S->GetClips())ClipList->AddSlot().AutoHeight().Padding(0,0,0,6)[SNew(SBorder).BorderImage(FAppStyle::GetBrush("WhiteBrush")).BorderBackgroundColor(S->SelectedClip==C?ClipColor(0,120,255):ClipColor(37,39,46)).Padding(8)[SNew(SHorizontalBox)+SHorizontalBox::Slot().FillWidth(1)[SNew(SInlineEditableTextBlock).Text(FText::FromString(C->DisplayName)).Font(CameraLightingStyle::Font(9)).OnTextCommitted_Lambda([C](const FText& T,ETextCommit::Type){ClipUI()->SelectClip(C);ClipUI()->RenameClip(T.ToString());})]+SHorizontalBox::Slot().AutoWidth()[ClipButton(TEXT(">"),[C]{ClipUI()->SelectClip(C);})]]];

 }
private:TSharedPtr<SClipRuler> Ruler;TSharedPtr<SVerticalBox> ClipList;TSharedPtr<SHorizontalBox> ViewList;bool bRefresh=false;
};
}
TSharedRef<SWidget> MakeCameraLightingClipsPanel(){return SNew(SMinimalClipsPanel);}

FString CameraLightingVerifyTimelineWheel()
{
 auto* S=ClipUI();if(!S || !S->SelectedClip)return TEXT("{}");auto W=SNew(SClipRuler);W->Fit();const auto Before=W->GetRange();const FGeometry G=FGeometry::MakeRoot(FVector2D(1000,50),FSlateLayoutTransform());const TSet<FKey> Keys;
 FModifierKeysState Ctrl(false,false,true,false,false,false,false,false,false);FPointerEvent E(0,FVector2D(500,10),FVector2D(500,10),Keys,EKeys::Invalid,18,Ctrl);W->OnMouseWheel(G,E);const auto After=W->GetRange();FPointerEvent Pan(0,FVector2D(500,10),FVector2D(500,10),Keys,EKeys::Invalid,-2,FModifierKeysState());W->OnMouseWheel(G,Pan);const auto Panned=W->GetRange();
 return FString::Printf(TEXT("{\"before\":%.6f,\"after\":%.6f,\"anchorBefore\":%.6f,\"anchorAfter\":%.6f,\"panned\":%.6f,\"step\":%.6f}"),Before.Span,After.Span,Before.At(.5),After.At(.5),Panned.Start,After.TickStep(1000,S->SelectedClip->FrameRate));
}

TSharedRef<SWidget> MakeCameraLightingZoomedRulerPreview(){auto W=SNew(SClipRuler);W->Fit();W->Zoom(18,.5f);return W;}

FString CameraLightingVerifyShotDrag()
{
 auto* S=ClipUI();auto* C=S?S->SelectedClip.Get():nullptr;if(!C || C->Shots.Num()<2)return TEXT("{}");auto R=SNew(SClipRuler);R->Fit();auto W=SNew(STimedShots).Ruler(R);const FGeometry G=FGeometry::MakeRoot(FVector2D(1000,130),FSlateLayoutTransform());float Span=R->GetRange().Span;TSet<FKey> Keys;Keys.Add(EKeys::LeftMouseButton);auto Event=[&](float X){return FPointerEvent(0,FVector2D(X,60),FVector2D(X,60),Keys,EKeys::LeftMouseButton,0,FModifierKeysState());};const FString Id=C->Shots[1].Id;auto Find=[&](){return C->Shots.IndexOfByPredicate([&](const auto& Shot){return Shot.Id==Id;});};const float Start=C->Shots[1].Start,Length=C->Shots[1].Length;const float X=(Start+Length*.5f)/Span*1000;W->OnMouseButtonDown(G,Event(X));W->OnMouseMove(G,Event(X+1000/Span));W->OnMouseButtonUp(G,Event(X+1000/Span));const float Moved=C->Shots[Find()].Start;R->Fit();Span=R->GetRange().Span;const float Edge=(Moved+Length)/Span*1000-2;W->OnMouseButtonDown(G,Event(Edge));W->OnMouseMove(G,Event(Edge+500/Span));W->OnMouseButtonUp(G,Event(Edge+500/Span));const float Trimmed=C->Shots[Find()].Length;R->Fit();Span=R->GetRange().Span;const float Left=Moved/Span*1000+2;W->OnMouseButtonDown(G,Event(Left));W->OnMouseMove(G,Event(Left+250/Span));W->OnMouseButtonUp(G,Event(Left+250/Span));return FString::Printf(TEXT("{\"start\":%.6f,\"moved\":%.6f,\"length\":%.6f,\"trimmed\":%.6f,\"leftStart\":%.6f,\"leftLength\":%.6f}"),Start,Moved,Length,Trimmed,C->Shots[Find()].Start,C->Shots[Find()].Length);
}

bool CameraLightingVerifyCameraDrop(AActor* Camera)
{
 if(!Camera)return false;auto R=SNew(SClipRuler);R->Fit();auto W=SNew(STimedShots).Ruler(R);auto Op=MakeShared<FActorDragDropOp>();Op->Init({Camera});Op->Construct();FPointerEvent P(0,FVector2D(500,60),FVector2D(500,60),TSet<FKey>(),EKeys::LeftMouseButton,0,FModifierKeysState());FDragDropEvent E(P,Op);return W->OnDrop(FGeometry::MakeRoot(FVector2D(1000,130),FSlateLayoutTransform()),E).IsEventHandled();
}
