#include "CameraLightingEditorModule.h"
#include "Widgets/Layout/SBorder.h"
#include "Widgets/SBoxPanel.h"
#include "CameraLightingPipelineTools.h"
#include "CameraLightingReview.h"
#include "CameraLightingStyle.h"
#include "CameraLightingViewportPanel.h"
#include "CameraLightingRenderWidgets.h"
#include "CameraLightingMinimalWidgets.h"
#include "CameraLightingClips.h"
#include "Interfaces/IPluginManager.h"
#include "Styling/SlateStyle.h"
#include "Styling/SlateStyleRegistry.h"
#include "Widgets/Input/SButton.h"
#include "Widgets/Layout/SBox.h"
#include "Widgets/Text/STextBlock.h"
#include "LevelEditor.h"
#include "ToolMenus.h"
#include "HAL/IConsoleManager.h"
#include "Styling/AppStyle.h"
#include "Widgets/Docking/SDockTab.h"
#include "Framework/Docking/TabManager.h"
#include "WorkspaceMenuStructure.h"
#include "WorkspaceMenuStructureModule.h"

const FName FCameraLightingEditorModule::PanelTabId(TEXT("CameraLightingPanel"));
const FName FCameraLightingEditorModule::ImageTabId(TEXT("CameraLightingImage"));
const FName FCameraLightingEditorModule::QueueTabId(TEXT("CameraLightingQueue"));
const FName FCameraLightingEditorModule::ClipsTabId(TEXT("CameraLightingClips"));
const FName FCameraLightingEditorModule::PipelineTabId(TEXT("CameraLightingPipeline"));
const FName FCameraLightingEditorModule::CompareTabId(TEXT("CameraLightingCompare"));
const FName FCameraLightingEditorModule::CameraTabId(TEXT("CameraLightingCamera"));

void FCameraLightingEditorModule::StartupModule()
{
 auto& LevelEditor=FModuleManager::LoadModuleChecked<FLevelEditorModule>(TEXT("LevelEditor"));
 LevelEditorCreatedHandle=LevelEditor.OnLevelEditorCreated().AddRaw(this,&FCameraLightingEditorModule::OnLevelEditorCreated);
 RegisterTabs();
 UToolMenus::RegisterStartupCallback(FSimpleMulticastDelegate::FDelegate::CreateRaw(this,&FCameraLightingEditorModule::RegisterMenus));
 ConsoleCommands.Add(MakeUnique<FAutoConsoleCommand>(TEXT("CameraLighting.OpenScenes"),TEXT("Open the Scene List panel."),FConsoleCommandDelegate::CreateLambda([]{OpenTab(PanelTabId);}))); 
 ConsoleCommands.Add(MakeUnique<FAutoConsoleCommand>(TEXT("CameraLighting.OpenImage"),TEXT("Open still-image rendering controls."),FConsoleCommandDelegate::CreateLambda([]{OpenTab(ImageTabId);}))); 
 ConsoleCommands.Add(MakeUnique<FAutoConsoleCommand>(TEXT("CameraLighting.OpenQueue"),TEXT("Open the render queue and history."),FConsoleCommandDelegate::CreateLambda([]{OpenTab(QueueTabId);}))); 
}
void FCameraLightingEditorModule::OnLevelEditorCreated(TSharedPtr<ILevelEditor> Editor){RegisterTabs();}
void FCameraLightingEditorModule::RegisterTabs()
{
 auto Manager=FGlobalTabmanager::Get();
 if(!Manager->HasTabSpawner(PanelTabId))Manager->RegisterNomadTabSpawner(PanelTabId,FOnSpawnTab::CreateRaw(this,&FCameraLightingEditorModule::SpawnScenes))
  .SetDisplayName(FText::FromString(TEXT("Scene List"))).SetTooltipText(FText::FromString(TEXT("Save cameras and lighting looks from the current view")))
  .SetGroup(WorkspaceMenu::GetMenuStructure().GetLevelEditorViewportsCategory());
 if(!Manager->HasTabSpawner(ImageTabId))Manager->RegisterNomadTabSpawner(ImageTabId,FOnSpawnTab::CreateRaw(this,&FCameraLightingEditorModule::SpawnImage))
  .SetDisplayName(FText::FromString(TEXT("Image Render"))).SetTooltipText(FText::FromString(TEXT("Lens, aspect, resolution, and still-image output")))
  .SetGroup(WorkspaceMenu::GetMenuStructure().GetLevelEditorViewportsCategory());
 if(!Manager->HasTabSpawner(QueueTabId))Manager->RegisterNomadTabSpawner(QueueTabId,FOnSpawnTab::CreateRaw(this,&FCameraLightingEditorModule::SpawnQueue))
  .SetDisplayName(FText::FromString(TEXT("Render Queue"))).SetTooltipText(FText::FromString(TEXT("Batch image rendering and saved history")))
  .SetGroup(WorkspaceMenu::GetMenuStructure().GetLevelEditorViewportsCategory());
 if(!Manager->HasTabSpawner(CameraTabId))Manager->RegisterNomadTabSpawner(CameraTabId,FOnSpawnTab::CreateRaw(this,&FCameraLightingEditorModule::SpawnCamera)).SetDisplayName(FText::FromString(TEXT("Camera"))).SetGroup(WorkspaceMenu::GetMenuStructure().GetLevelEditorViewportsCategory());
 if(!Manager->HasTabSpawner(ClipsTabId))Manager->RegisterNomadTabSpawner(ClipsTabId,FOnSpawnTab::CreateRaw(this,&FCameraLightingEditorModule::SpawnClips)).SetDisplayName(FText::FromString(TEXT("Clips"))).SetGroup(WorkspaceMenu::GetMenuStructure().GetLevelEditorViewportsCategory());
 if(!Manager->HasTabSpawner(PipelineTabId))Manager->RegisterNomadTabSpawner(PipelineTabId,FOnSpawnTab::CreateRaw(this,&FCameraLightingEditorModule::SpawnPipeline)).SetDisplayName(FText::FromString(TEXT("Preflight & Video Delivery"))).SetGroup(WorkspaceMenu::GetMenuStructure().GetLevelEditorViewportsCategory());
 if(!Manager->HasTabSpawner(CompareTabId))Manager->RegisterNomadTabSpawner(CompareTabId,FOnSpawnTab::CreateRaw(this,&FCameraLightingEditorModule::SpawnCompare)).SetDisplayName(FText::FromString(TEXT("Render Compare"))).SetGroup(WorkspaceMenu::GetMenuStructure().GetLevelEditorViewportsCategory());

}
void FCameraLightingEditorModule::OpenTab(FName Id)
{
 auto& Module=FModuleManager::LoadModuleChecked<FCameraLightingEditorModule>(TEXT("CameraLightingProfilesEditor"));Module.RegisterTabs();
 auto Tab=FGlobalTabmanager::Get()->TryInvokeTab(Id);if(!Tab)UE_LOG(LogTemp,Error,TEXT("Camera Lighting: could not open panel %s"),*Id.ToString());

}
TSharedRef<SDockTab> FCameraLightingEditorModule::SpawnScenes(const FSpawnTabArgs& Args)
{CameraLightingBeginWindowArtwork();return SNew(SDockTab).TabRole(ETabRole::NomadTab)[SNew(SCameraLightingViewportPanel)];}
TSharedRef<SDockTab> FCameraLightingEditorModule::SpawnImage(const FSpawnTabArgs& Args)
{CameraLightingBeginWindowArtwork();return SNew(SDockTab).TabRole(ETabRole::NomadTab)[MakeCameraLightingImagePanel()];}
TSharedRef<SDockTab> FCameraLightingEditorModule::SpawnQueue(const FSpawnTabArgs& Args)
{CameraLightingBeginWindowArtwork();return SNew(SDockTab).TabRole(ETabRole::NomadTab)[MakeCameraLightingQueuePanel()];}
TSharedRef<SDockTab> FCameraLightingEditorModule::SpawnCamera(const FSpawnTabArgs& Args)
{CameraLightingBeginWindowArtwork();return SNew(SDockTab).TabRole(ETabRole::NomadTab)[MakeCameraLightingCameraPanel()];}
TSharedRef<SDockTab> FCameraLightingEditorModule::SpawnClips(const FSpawnTabArgs& Args)
{CameraLightingBeginWindowArtwork();return SNew(SDockTab).TabRole(ETabRole::NomadTab)[MakeCameraLightingClipsPanel()];}
TSharedRef<SDockTab> FCameraLightingEditorModule::SpawnCompare(const FSpawnTabArgs& Args){CameraLightingBeginWindowArtwork();return SNew(SDockTab).TabRole(ETabRole::NomadTab)[MakeCameraLightingComparePanel()];}
TSharedRef<SDockTab> FCameraLightingEditorModule::SpawnPipeline(const FSpawnTabArgs& Args){CameraLightingBeginWindowArtwork();return SNew(SDockTab).TabRole(ETabRole::NomadTab)[MakeCameraLightingPipelinePanel()];}
TSharedRef<SWidget> MakeCameraLightingRibbonGroup()
{
 auto Group=SNew(SHorizontalBox)
 +SHorizontalBox::Slot().AutoWidth()[MakeCameraLightingRibbonAction(TEXT("Scenes"),TEXT("Scenes"),FCameraLightingEditorModule::PanelTabId)]
 +SHorizontalBox::Slot().AutoWidth()[MakeCameraLightingRibbonAction(TEXT("Clips"),TEXT("Clips"),FCameraLightingEditorModule::ClipsTabId)]
 +SHorizontalBox::Slot().AutoWidth()[MakeCameraLightingRibbonAction(TEXT("QueueList"),TEXT("Queue"),FCameraLightingEditorModule::QueueTabId)];
 auto Frame=SNew(SBorder).BorderImage(FAppStyle::GetBrush("WhiteBrush")).BorderBackgroundColor(FLinearColor(.008f,.012f,.02f)).Padding(FMargin(0,0,2,3))[
 SNew(SBorder).BorderImage(FAppStyle::GetBrush("WhiteBrush")).BorderBackgroundColor(FLinearColor(.16f,.24f,.32f)).Padding(1)[
 SNew(SBorder).BorderImage(FAppStyle::GetBrush("WhiteBrush")).BorderBackgroundColor(FLinearColor(.07f,.09f,.12f)).Padding(FMargin(1,2,0,0))[
 SNew(SBorder).BorderImage(FAppStyle::GetBrush("WhiteBrush")).BorderBackgroundColor(FLinearColor(.025f,.032f,.042f)).Padding(FMargin(3,0))[Group]]]];
 return Frame;
}
void FCameraLightingEditorModule::RegisterMenus()
{
 FToolMenuOwnerScoped Owner(this);
 auto* Window=UToolMenus::Get()->ExtendMenu(TEXT("LevelEditor.MainMenu.Window"));
 auto& Section=Window->AddSection(TEXT("CameraLightingSection"),FText::FromString(TEXT("Camera Lighting")));
 auto AddMenu=[&Section](FName Name,const TCHAR* Label,FName Id){
  Section.AddMenuEntry(Name,FText::FromString(Label),FText(),FSlateIcon(),FUIAction(FExecuteAction::CreateLambda([Id]{OpenTab(Id);})));
 };
 AddMenu(TEXT("OpenCameraLightingPanel"),TEXT("Scene List"),PanelTabId);
 AddMenu(TEXT("OpenCameraLightingImage"),TEXT("Image Render"),ImageTabId);
 AddMenu(TEXT("OpenCameraLightingQueue"),TEXT("Render Queue"),QueueTabId);
 AddMenu(TEXT("OpenCameraLightingCamera"),TEXT("Camera"),CameraTabId);
 AddMenu(TEXT("OpenCameraLightingClips"),TEXT("Clips"),ClipsTabId);
 AddMenu(TEXT("OpenCameraLightingCompare"),TEXT("Render Compare"),CompareTabId);
 Section.AddMenuEntry(TEXT("CameraLightingManagePlugins"),FText::FromString(TEXT("Manage Plugins...")),FText(),FSlateIcon(),FUIAction(FExecuteAction::CreateLambda([]{FModuleManager::Get().LoadModulePtr<IModuleInterface>(TEXT("PluginBrowser"));FGlobalTabmanager::Get()->TryInvokeTab(FName(TEXT("PluginsEditor")));})));
 AddMenu(TEXT("OpenCameraLightingPipeline"),TEXT("Preflight & Video Delivery"),PipelineTabId);
 auto* Toolbar=UToolMenus::Get()->ExtendMenu(TEXT("LevelEditor.LevelEditorToolBar.ModesToolBar"));
 auto& ToolbarSection=Toolbar->AddSection(TEXT("CameraLightingToolbar"));
 auto Frame=MakeCameraLightingRibbonGroup();
 ToolbarSection.AddEntry(FToolMenuEntry::InitWidget(TEXT("CameraLightingRibbonGroup"),Frame,FText::FromString(TEXT("Camera Lighting Profiles"))));


}
void FCameraLightingEditorModule::ShutdownModule()
{
 ConsoleCommands.Reset();
 if(FModuleManager::Get().IsModuleLoaded(TEXT("LevelEditor"))) {
  auto& LevelEditor=FModuleManager::GetModuleChecked<FLevelEditorModule>(TEXT("LevelEditor"));
  LevelEditor.OnLevelEditorCreated().Remove(LevelEditorCreatedHandle);
 }
 auto Manager=FGlobalTabmanager::Get();for(FName Id:{PanelTabId,ImageTabId,QueueTabId,CameraTabId,ClipsTabId,CompareTabId,PipelineTabId})Manager->UnregisterNomadTabSpawner(Id);

 UToolMenus::UnRegisterStartupCallback(this);
 if(UToolMenus::IsToolMenuUIEnabled())UToolMenus::UnregisterOwner(this);
}
IMPLEMENT_MODULE(FCameraLightingEditorModule,CameraLightingProfilesEditor)

TSharedRef<SWidget> MakeCameraLightingRibbonAction(FName Kind,const FString& Label,FName Tab)
{
 return SNew(SButton).ButtonStyle(FAppStyle::Get(),"SimpleButton").ContentPadding(FMargin(7,4)).ToolTipText(FText::FromString(TEXT("Open ")+Label)).OnClicked_Lambda([Tab]{FCameraLightingEditorModule::OpenTab(Tab);return FReply::Handled();})[SNew(SHorizontalBox)
 +SHorizontalBox::Slot().AutoWidth().VAlign(VAlign_Center)[SNew(SBox).WidthOverride(24).HeightOverride(24)[MakeCameraLightingGlyph(Kind,24)]]
 +SHorizontalBox::Slot().AutoWidth().VAlign(VAlign_Center).Padding(5,0)[SNew(STextBlock).Text(FText::FromString(Label)).Font(CameraLightingStyle::Font(9))]];
}

bool CameraLightingVerifyPanelRecovery()
{
 auto M=FGlobalTabmanager::Get();M->UnregisterNomadTabSpawner(FCameraLightingEditorModule::ClipsTabId);
 // A layout can discard a manager/spawner; repairing registration never needs OS input.
 auto& Module=FModuleManager::LoadModuleChecked<FCameraLightingEditorModule>(TEXT("CameraLightingProfilesEditor"));Module.EnsurePanels();
 for(FName Id:{FCameraLightingEditorModule::PanelTabId,FCameraLightingEditorModule::ImageTabId,FCameraLightingEditorModule::QueueTabId,FCameraLightingEditorModule::CameraTabId,FCameraLightingEditorModule::ClipsTabId,FCameraLightingEditorModule::CompareTabId,FCameraLightingEditorModule::PipelineTabId})if(!M->HasTabSpawner(Id))return false;return FModuleManager::Get().IsModuleLoaded(TEXT("PluginBrowser")) && M->HasTabSpawner(FName(TEXT("PluginsEditor")));
}
