#include "CameraLightingClips.h"
#include "CameraLightingViewportTools.h"
#include "CameraLightingCameraTools.h"
#include "CameraLightingEditorModule.h"
#include "CineCameraActor.h"
#include "CameraLightingCapture.h"
#include "CameraLightingProfile.h"
#include "CameraLightingRenderTemplate.h"
#include "CameraLightingRenderService.h"
#include "CameraLightingComponent.h"
#include "Camera/CameraActor.h"
#include "Camera/CameraComponent.h"
#include "CineCameraComponent.h"
#include "Editor.h"
#include "LevelEditorViewport.h"
#include "Engine/World.h"
#include "AssetRegistry/AssetRegistryModule.h"
#include "Subsystems/AssetEditorSubsystem.h"
#include "LevelSequence.h"
#include "MovieScene.h"
#include "MovieSceneSpawnable.h"
#include "MovieScenePossessable.h"
#include "Channels/MovieSceneChannelProxy.h"
#include "Misc/PackageName.h"
#include "Tracks/MovieScene3DTransformTrack.h"
#include "Sections/MovieScene3DTransformSection.h"
#include "Tracks/MovieSceneFloatTrack.h"
#include "Sections/MovieSceneFloatSection.h"
#include "Tracks/MovieSceneCameraCutTrack.h"
#include "Sections/MovieSceneCameraCutSection.h"
#include "Tracks/MovieSceneSpawnTrack.h"
#include "Sections/MovieSceneSpawnSection.h"
#include "Channels/MovieSceneDoubleChannel.h"
#include "MoviePipelinePrimaryConfig.h"
#include "ScopedTransaction.h"
namespace
{
FLevelEditorViewportClient* ClipViewport(){if(!GEditor)return nullptr;auto* V=GCurrentLevelEditingViewportClient;if(V && V->IsPerspective())return V;for(auto* C:GEditor->GetLevelViewportClients())if(C && C->IsPerspective())return C;return nullptr;}
UWorld* ClipWorld(){return GEditor?GEditor->GetEditorWorldContext().World():nullptr;}
FString ClipMap(){return ClipWorld()?FSoftObjectPath(ClipWorld()).ToString():FString();}
}
void UCameraLightingClipService::Initialize(FSubsystemCollectionBase& Collection){Super::Initialize(Collection);LoadConfig();TickHandle=FTSTicker::GetCoreTicker().AddTicker(FTickerDelegate::CreateUObject(this,&UCameraLightingClipService::Tick));}
void UCameraLightingClipService::Deinitialize(){FTSTicker::GetCoreTicker().RemoveTicker(TickHandle);if(bRecording)StopRecording(true);SaveConfig();StopPreview();OnChanged.Clear();Super::Deinitialize();}
void UCameraLightingClipService::Error(const FString& Message){Status=Message;OnChanged.Broadcast();}
bool UCameraLightingClipService::CanEdit(){if(bRecording){Error(TEXT("Stop recording before editing clips."));return false;}if(!GEditor || GEditor->PlayWorld || GEditor->GetEditorSubsystem<UCameraLightingRenderService>()->IsRendering()){Error(TEXT("Stop playback/rendering before editing clips."));return false;}return true;}
TArray<UCameraLightingClip*> UCameraLightingClipService::GetClips()
{
 if(!bLoaded){bLoaded=true;FARFilter F;F.ClassPaths.Add(UCameraLightingClip::StaticClass()->GetClassPathName());TArray<FAssetData>A;auto& Registry=FModuleManager::LoadModuleChecked<FAssetRegistryModule>(TEXT("AssetRegistry")).Get();Registry.ScanPathsSynchronous({TEXT("/Game/CameraLightingClips")});Registry.GetAssets(F,A);for(auto& D:A)if(auto* C=Cast<UCameraLightingClip>(D.GetAsset())){Clips.Add(C);Migrate(C);}}
 TArray<UCameraLightingClip*> Result;for(auto& C:Clips)if(C)Result.Add(C.Get());return Result;
}
UCameraLightingClip* UCameraLightingClipService::CreateClip()
{
 if(!CanEdit())return nullptr;StopPreview();const FString Name=TEXT("Clip_")+FGuid::NewGuid().ToString(EGuidFormats::Digits).Left(12);auto* P=CreatePackage(*(TEXT("/Game/CameraLightingClips/")+Name));
 auto* C=NewObject<UCameraLightingClip>(P,*Name,RF_Public|RF_Standalone|RF_Transactional);C->DisplayName=FString::Printf(TEXT("Clip %d"),GetClips().Num()+1);C->MapPath=ClipMap();FAssetRegistryModule::AssetCreated(C);Clips.Add(C);SelectedClip=C;CameraLightingTemplates::Save(C);Status=TEXT("Add a view from the viewport or a saved scene.");OnChanged.Broadcast();return C;
}
void UCameraLightingClipService::SelectClip(UCameraLightingClip* C){StopPreview();SelectedClip=C;SelectedShotId.Reset();Migrate(C);Playhead=0;OnChanged.Broadcast();}
void UCameraLightingClipService::RenameClip(const FString& Name){if(!SelectedClip || !CanEdit() || Name.TrimStartAndEnd().IsEmpty())return;FScopedTransaction T(NSLOCTEXT("CameraLighting","RenameClip","Rename clip"));SelectedClip->Modify();SelectedClip->DisplayName=Name.TrimStartAndEnd();CameraLightingTemplates::Save(SelectedClip);OnChanged.Broadcast();}
void UCameraLightingClipService::DuplicateClip()
{
 if(!SelectedClip || !CanEdit())return;auto* Original=SelectedClip.Get();auto Views=Original->Views;auto* Copy=CreateClip();if(!Copy)return;Copy->DisplayName=Original->DisplayName+TEXT(" Copy");Copy->Duration=Original->Duration;Copy->FrameRate=Original->FrameRate;Copy->MapPath=Original->MapPath;Copy->Views=Views;Copy->Shots=Original->Shots;for(auto& Shot:Copy->Shots){Shot.Id=FGuid::NewGuid().ToString();for(auto& V:Shot.Views)if(V.Lighting)V.Lighting=DuplicateObject<UCameraLightingProfile>(V.Lighting,Copy,MakeUniqueObjectName(Copy,UCameraLightingProfile::StaticClass(),TEXT("ShotLighting")));}
 for(auto& V:Copy->Views)if(V.Lighting)V.Lighting=DuplicateObject<UCameraLightingProfile>(V.Lighting,Copy,*MakeUniqueObjectName(Copy,UCameraLightingProfile::StaticClass(),TEXT("ViewLighting")).ToString());SaveClip();
}
bool UCameraLightingClipService::CaptureView(FCameraLightingClipView& Out,AActor* Source)
{
 if(!SelectedClip || !ClipWorld())return false;auto* V=ClipViewport();auto* C=Source?Source->FindComponentByClass<UCameraComponent>():nullptr;
 if(!Source && !V){Error(TEXT("Open a perspective viewport or select a camera."));return false;}
 Out.Transform=Source?Source->GetActorTransform():FTransform(V->GetViewRotation(),V->GetViewLocation());Out.Transform.SetScale3D(FVector::OneVector);
 if(C)Out.Transform=C->GetComponentTransform();if(!C && V)C=V->GetCameraComponentForView();Out.Fov=C?(Cast<UCineCameraComponent>(C)?CastChecked<UCineCameraComponent>(C)->GetHorizontalFieldOfView():C->FieldOfView):(V?V->ViewFOV:90);
 if(C && C->ProjectionMode!=ECameraProjectionMode::Perspective){Error(TEXT("Clips currently use perspective cameras. Switch this camera to Perspective first."));return false;}
 FActorSpawnParameters P;P.ObjectFlags=RF_Transient;P.SpawnCollisionHandlingOverride=ESpawnActorCollisionHandlingMethod::AlwaysSpawn;auto* Temp=ClipWorld()->SpawnActor<ACameraActor>(ACameraActor::StaticClass(),Out.Transform,P);if(!Temp)return false;
 auto* Cam=Temp->GetCameraComponent();Cam->SetFieldOfView(Out.Fov);if(C){FMinimalViewInfo SourceView;C->GetCameraView(0.f,SourceView);Cam->PostProcessSettings=SourceView.PostProcessSettings;Cam->PostProcessBlendWeight=SourceView.PostProcessBlendWeight;}
 auto* Profile=NewObject<UCameraLightingProfile>(SelectedClip,MakeUniqueObjectName(SelectedClip,UCameraLightingProfile::StaticClass(),TEXT("ViewLighting")),RF_Transactional);
 const bool bOK=FCameraLightingCapture::CaptureClipView(Temp,Profile);ClipWorld()->DestroyActor(Temp);if(!bOK){Error(FCameraLightingCapture::GetLastError());return false;}Out.Lighting=Profile;return true;
}
bool UCameraLightingClipService::AddView(){return AddCameraView(nullptr);}
bool UCameraLightingClipService::AddCameraView(AActor* Camera)
{
 if(bRecording){Error(TEXT("Stop recording before adding shots."));return false;}if(!CanEdit())return false;if(!SelectedClip && !CreateClip())return false;if(SelectedClip->MapPath!=ClipMap()){Error(TEXT("Open the clip's saved level before adding views."));return false;}
 FScopedTransaction T(NSLOCTEXT("CameraLighting","AddClipView","Add clip view"));SelectedClip->Modify();FCameraLightingClipView V;if(!CaptureView(V,Camera))return false;FCameraLightingShot Shot;Shot.Id=FGuid::NewGuid().ToString();Shot.Label=Camera?Camera->GetActorLabel():FString::Printf(TEXT("Shot %d"),SelectedClip->Shots.Num()+1);for(auto& Existing:SelectedClip->Shots)Shot.Start=FMath::Max(Shot.Start,Existing.Start+Existing.Length);Shot.Views.Add(V);Shot.CameraActor=Camera;SelectedClip->Shots.Add(Shot);SelectedClip->Duration=FMath::Max(SelectedClip->Duration,Shot.Start+Shot.Length);return SaveClip();
}
void UCameraLightingClipService::Migrate(UCameraLightingClip* C)
{
 if(!C || !C->Shots.IsEmpty() || C->Views.IsEmpty())return;
 C->Modify();FCameraLightingShot Shot;Shot.Id=FGuid::NewGuid().ToString();Shot.Label=C->Views.Num()>1?TEXT("Camera move"):TEXT("Shot 1");Shot.Length=C->Duration;Shot.Views=C->Views;C->Shots.Add(Shot);
 if(auto* Original=C->Sequence.LoadSynchronous()){const FString Path=C->GetOutermost()->GetName()+TEXT("_PreTimeline");auto* P=CreatePackage(*Path);auto* Copy=DuplicateObject<ULevelSequence>(Original,P,*FPackageName::GetLongPackageAssetName(Path));Copy->SetFlags(RF_Public|RF_Standalone);FAssetRegistryModule::AssetCreated(Copy);C->LegacySequenceBackup=Copy;CameraLightingTemplates::Save(Copy);}CameraLightingTemplates::Save(C);
}
bool UCameraLightingClipService::UpdateView(int32 I){if(!CanEdit() || !SelectedClip || !SelectedClip->Shots.IsValidIndex(I))return false;if(SelectedClip->MapPath!=ClipMap())return false;FCameraLightingClipView V;if(!CaptureView(V,nullptr))return false;SelectedClip->Modify();SelectedClip->Shots[I].Views[0]=V;return SaveClip();}
void UCameraLightingClipService::RemoveView(int32 I){if(!CanEdit() || !SelectedClip || !SelectedClip->Shots.IsValidIndex(I))return;SelectedClip->Modify();SelectedClip->Shots.RemoveAt(I);SaveClip();}
void UCameraLightingClipService::MoveView(int32 I,int32 D){if(!SelectedClip || !SelectedClip->Shots.IsValidIndex(I+D))return;SetShotRange(I,SelectedClip->Shots[I+D].Start,SelectedClip->Shots[I].Length);}
void UCameraLightingClipService::SetShotRange(int32 I,float Start,float Length)
{
 if(!CanEdit() || !SelectedClip || !SelectedClip->Shots.IsValidIndex(I))return;FScopedTransaction T(NSLOCTEXT("CameraLighting","ShotTiming","Edit shot timing"));SelectedClip->Modify();const float FPS=SelectedClip->FrameRate;auto& Shot=SelectedClip->Shots[I];Shot.Start=FMath::Max(0.f,FMath::RoundToFloat(Start*FPS)/FPS);Shot.Length=FMath::Max(1.f/FPS,FMath::RoundToFloat(Length*FPS)/FPS);const FString Id=Shot.Id;
 SelectedClip->Shots.StableSort([Id](const auto& A,const auto& B){return FMath::IsNearlyEqual(A.Start,B.Start)?A.Id==Id && B.Id!=Id:A.Start<B.Start;});float End=0;for(auto& S:SelectedClip->Shots){S.Start=FMath::Max(S.Start,End);End=S.Start+S.Length;}SelectedClip->Duration=FMath::Max(SelectedClip->Duration,End);SaveClip();
}
bool UCameraLightingClipService::AddMotionView(int32 I){if(!CanEdit() || !SelectedClip || !SelectedClip->Shots.IsValidIndex(I) || SelectedClip->MapPath!=ClipMap())return false;FCameraLightingClipView V;if(!CaptureView(V,nullptr))return false;SelectedClip->Modify();SelectedClip->Shots[I].Views.Add(V);return SaveClip();}
void UCameraLightingClipService::SetDuration(float S){if(!CanEdit() || !SelectedClip)return;SelectedClip->Modify();SelectedClip->Duration=FMath::Clamp(S,.1f,86400.f);Playhead=FMath::Min(Playhead,SelectedClip->Duration);SaveClip();}
void UCameraLightingClipService::SetFrameRate(int32 F){if(!CanEdit() || !SelectedClip)return;SelectedClip->Modify();SelectedClip->FrameRate=FMath::Clamp(F,1,120);SaveClip();}
bool UCameraLightingClipService::SaveClip(){if(bRecording)return false;if(!SelectedClip)return false;StopPreview();if(!RebuildSequence())return false;const bool OK=CameraLightingTemplates::Save(SelectedClip);Status=OK?TEXT("Clip saved. Add views, preview, or render an image sequence."):TEXT("Could not save clip. Check write permissions.");OnChanged.Broadcast();return OK;}
bool UCameraLightingClipService::RebuildSequence()
{
 auto* C=SelectedClip.Get();if(!C)return false;const FString Path=C->GetOutermost()->GetName()+TEXT("_Sequence");auto* P=CreatePackage(*Path);auto* Seq=C->Sequence.LoadSynchronous();if(!Seq){Seq=NewObject<ULevelSequence>(P,*FPackageName::GetLongPackageAssetName(Path),RF_Public|RF_Standalone|RF_Transactional);Seq->Initialize();FAssetRegistryModule::AssetCreated(Seq);C->Sequence=Seq;}
 // This generated sequence is owned by view cards; advanced editing always uses a separate exported copy.
 auto* M=Seq->GetMovieScene();Seq->Modify();M->Modify();while(M->GetPossessableCount()){const FGuid G=M->GetPossessable(0).GetGuid();Seq->UnbindPossessableObjects(G);M->RemovePossessable(G);}
 while(M->GetSpawnableCount())M->RemoveSpawnable(M->GetSpawnable(0).GetGuid());if(M->GetCameraCutTrack())M->RemoveCameraCutTrack();
 M->SetDisplayRate(FFrameRate(C->FrameRate,1));M->SetTickResolutionDirectly(FFrameRate(24000,1));const int32 End=FMath::Max(1,FMath::RoundToInt(C->Duration*24000));M->SetPlaybackRange(0,End);
 auto* CT=M->AddCameraCutTrack(UMovieSceneCameraCutTrack::StaticClass());
 for(int32 ShotIndex=0;ShotIndex<C->Shots.Num();++ShotIndex)
 {
  const auto& Shot=C->Shots[ShotIndex];const auto& Views=Shot.Views;if(Views.IsEmpty())continue;const int32 ShotStart=FMath::RoundToInt(Shot.Start*24000),ShotEnd=FMath::RoundToInt((Shot.Start+Shot.Length)*24000);
  if(!ClipWorld())return false;
  FActorSpawnParameters Params;Params.ObjectFlags=RF_Transient;Params.SpawnCollisionHandlingOverride=ESpawnActorCollisionHandlingMethod::AlwaysSpawn;
  auto* Seed=ClipWorld()->SpawnActor<ACameraActor>(ACameraActor::StaticClass(),Views[0].Transform,Params);if(!Seed)return false;
  auto* SeedCamera=Seed->GetCameraComponent();SeedCamera->SetFieldOfView(Views[0].Fov);SeedCamera->PostProcessBlendWeight=1;
  if(Views[0].Lighting){SeedCamera->PostProcessSettings=Views[0].Lighting->PostProcessSettings;auto* Lighting=NewObject<UCameraLightingComponent>(Seed,NAME_None,RF_Transactional);Seed->AddInstanceComponent(Lighting);Lighting->OnComponentCreated();Lighting->RegisterComponent();Lighting->Profile=Views[0].Lighting;}
  auto* Actor=Cast<ACameraActor>(Seq->MakeSpawnableTemplateFromInstance(*Seed,*FString::Printf(TEXT("ClipCamera_%d"),ShotIndex)));ClipWorld()->DestroyActor(Seed);if(!Actor)return false;Actor->SetActorTransform(Views[0].Transform);
  const FGuid Id=M->AddSpawnable(FString::Printf(TEXT("Shot %d"),ShotIndex+1),*Actor);auto* SpawnTrack=M->AddTrack<UMovieSceneSpawnTrack>(Id);auto* Spawn=CastChecked<UMovieSceneSpawnSection>(SpawnTrack->CreateNewSection());Spawn->GetChannel().SetDefault(true);Spawn->SetRange(TRange<FFrameNumber>::All());SpawnTrack->AddSection(*Spawn);
  auto* T=M->AddTrack<UMovieScene3DTransformTrack>(Id);T->SetPropertyNameAndPath(TEXT("Transform"),TEXT("Transform"));auto* S=CastChecked<UMovieScene3DTransformSection>(T->CreateNewSection());S->SetRange(TRange<FFrameNumber>::All());T->AddSection(*S);auto Channels=S->GetChannelProxy().GetChannels<FMovieSceneDoubleChannel>();
  // This is a lens-property binding, not another render camera. Generic component metadata
  // avoids MRQ5.7 treating a legacy-spawnable child as a sidecar camera (its sidecar walk only follows possessables).
  auto* CameraComponent=Actor->GetCameraComponent();const FGuid ComponentId=M->AddPossessable(CameraComponent->GetName(),UActorComponent::StaticClass());M->FindPossessable(ComponentId)->SetParent(Id,M);M->FindSpawnable(Id)->AddChildPossessable(ComponentId);Seq->BindPossessableObject(ComponentId,*CameraComponent,Actor);
  auto* FT=M->AddTrack<UMovieSceneFloatTrack>(ComponentId);FT->SetPropertyNameAndPath(TEXT("FieldOfView"),TEXT("FieldOfView"));auto* FS=CastChecked<UMovieSceneFloatSection>(FT->CreateNewSection());FS->SetRange(TRange<FFrameNumber>::All());FT->AddSection(*FS);
  FRotator Previous=Views[0].Transform.Rotator();
  for(int32 I=0;I<Views.Num();++I){const auto& V=Views[I];const FFrameNumber Time(ShotStart+(Views.Num()==1?0:FMath::RoundToInt((Views.Last().Time>0 && V.Time>=0?V.Time/Views.Last().Time:float(I)/(Views.Num()-1))*(ShotEnd-ShotStart))));const FVector L=V.Transform.GetLocation();FRotator R=V.Transform.Rotator();R.Roll=Previous.Roll+FMath::FindDeltaAngleDegrees(Previous.Roll,R.Roll);R.Pitch=Previous.Pitch+FMath::FindDeltaAngleDegrees(Previous.Pitch,R.Pitch);R.Yaw=Previous.Yaw+FMath::FindDeltaAngleDegrees(Previous.Yaw,R.Yaw);Previous=R;const double Values[]={L.X,L.Y,L.Z,R.Roll,R.Pitch,R.Yaw,1,1,1};for(int32 A=0;A<9;++A){if(Shot.Interpolation==ECameraLightingInterpolation::Constant)Channels[A]->AddConstantKey(Time,Values[A]);else if(Shot.Interpolation==ECameraLightingInterpolation::Smooth)Channels[A]->AddCubicKey(Time,Values[A],RCTM_User);else Channels[A]->AddLinearKey(Time,Values[A]);}if(Shot.Interpolation==ECameraLightingInterpolation::Constant)FS->GetChannel().AddConstantKey(Time,V.Fov);else if(Shot.Interpolation==ECameraLightingInterpolation::Smooth)FS->GetChannel().AddCubicKey(Time,V.Fov,RCTM_User);else FS->GetChannel().AddLinearKey(Time,V.Fov);}
  auto* Cut=CastChecked<UMovieSceneCameraCutSection>(CT->CreateNewSection());Cut->SetCameraGuid(Id);const int32 CutStart=ShotIndex==0?0:ShotStart;const int32 CutEnd=ShotIndex+1<C->Shots.Num()?FMath::Min(End,FMath::RoundToInt(C->Shots[ShotIndex+1].Start*24000)):End;if(CutStart<CutEnd){Cut->SetRange(TRange<FFrameNumber>(CutStart,CutEnd));CT->AddSection(*Cut);}
 }
 M->MarkAsChanged();Seq->MarkAsChanged();return CameraLightingTemplates::Save(Seq);
}
FCameraLightingClipView UCameraLightingClipService::EvaluateView(float Seconds) const
{
 FCameraLightingClipView Result;const auto* C=SelectedClip.Get();if(!C || C->Shots.IsEmpty())return Result;const FCameraLightingShot* Shot=&C->Shots[0];for(const auto& S:C->Shots)if(S.Start<=Seconds)Shot=&S;const auto& Views=Shot->Views;if(Views.IsEmpty())return Result;if(Views.Num()==1)return Views[0];const float Position=FMath::Clamp((Seconds-Shot->Start)/FMath::Max(Shot->Length,.001f),0.f,1.f)*(Views.Num()-1);int32 I=FMath::Min(FMath::FloorToInt(Position),Views.Num()-2);float A=Position-I;if(Views.Last().Time>0){const float T=FMath::Clamp((Seconds-Shot->Start)/FMath::Max(Shot->Length,.001f),0.f,1.f)*Views.Last().Time;I=0;while(I+1<Views.Num()-1 && Views[I+1].Time<T)++I;A=FMath::Clamp((T-Views[I].Time)/FMath::Max(Views[I+1].Time-Views[I].Time,.00001f),0.f,1.f);}if(Shot->Interpolation==ECameraLightingInterpolation::Smooth)A=A*A*(3-2*A);else if(Shot->Interpolation==ECameraLightingInterpolation::Constant)A=A>=1?1:0;const auto& X=Views[I];const auto& Y=Views[I+1];Result=X;Result.Transform.SetLocation(FMath::Lerp(X.Transform.GetLocation(),Y.Transform.GetLocation(),A));const FRotator RX=X.Transform.Rotator(),RY=Y.Transform.Rotator();Result.Transform.SetRotation(FRotator(RX.Pitch+FMath::FindDeltaAngleDegrees(RX.Pitch,RY.Pitch)*A,RX.Yaw+FMath::FindDeltaAngleDegrees(RX.Yaw,RY.Yaw)*A,RX.Roll+FMath::FindDeltaAngleDegrees(RX.Roll,RY.Roll)*A).Quaternion());Result.Fov=FMath::Lerp(X.Fov,Y.Fov,A);return Result;
}
void UCameraLightingClipService::Scrub(float Seconds)
{
 if(!SelectedClip || SelectedClip->Shots.IsEmpty() || !CanEdit())return;if(SelectedClip->MapPath!=ClipMap()){Error(TEXT("Open this clip's level to preview it."));return;}auto* V=ClipViewport();if(!V)return;
 if(!PreviewCamera){PreviousLock=V->GetActiveActorLock();PreviousLocation=V->GetViewLocation();PreviousRotation=V->GetViewRotation();PreviousFov=V->ViewFOV;bSavedViewport=true;FActorSpawnParameters P;P.ObjectFlags=RF_Transient;PreviewCamera=ClipWorld()->SpawnActor<ACameraActor>(P);}
 Playhead=FMath::Clamp(Seconds,0.f,SelectedClip->Duration);const auto State=EvaluateView(Playhead);PreviewCamera->SetActorTransform(State.Transform);auto* Cam=PreviewCamera->GetCameraComponent();auto* Render=GEditor->GetEditorSubsystem<UCameraLightingRenderService>();Cam->SetAspectRatio(float(Render->Width)/Render->Height);Cam->bConstrainAspectRatio=true;Cam->SetFieldOfView(State.Fov);Cam->PostProcessBlendWeight=1;if(State.Lighting)Cam->PostProcessSettings=State.Lighting->PostProcessSettings;V->SetActorLock(PreviewCamera);V->UpdateViewForLockedActor();V->Invalidate();
}
void UCameraLightingClipService::TogglePlay(){if(!SelectedClip || SelectedClip->Shots.IsEmpty())return;if(bPlaying){bPlaying=false;return;}if(Playhead>=SelectedClip->Duration)Playhead=0;Scrub(Playhead);bPlaying=PreviewCamera!=nullptr;}
void UCameraLightingClipService::StopPreview(){bPlaying=false;if(PreviewCamera){if(auto* V=ClipViewport())if(bSavedViewport){V->SetActorLock(PreviousLock.Get());if(PreviousLock.IsValid())V->UpdateViewForLockedActor();else{V->SetViewLocation(PreviousLocation);V->SetViewRotation(PreviousRotation);V->ViewFOV=PreviousFov;}V->Invalidate();}if(auto* W=PreviewCamera->GetWorld())W->DestroyActor(PreviewCamera);PreviewCamera=nullptr;}bSavedViewport=false;}
bool UCameraLightingClipService::Tick(float Delta){if(bRecording)TickRecording();if(PreviewCamera && PreviewCamera->GetWorld()!=ClipWorld())StopPreview();if(bPlaying && SelectedClip){if(GEditor->PlayWorld || GEditor->GetEditorSubsystem<UCameraLightingRenderService>()->IsRendering()){StopPreview();return true;}const float Next=FMath::Min(Playhead+Delta,SelectedClip->Duration);Scrub(Next);if(Next>=SelectedClip->Duration)bPlaying=false;}return true;}
FString UCameraLightingClipService::QueueClip(){if(!SelectedClip || SelectedClip->Shots.IsEmpty()){Error(TEXT("Add at least one camera view to the clip."));return {};}if(SelectedClip->MapPath!=ClipMap()){Error(TEXT("Open this clip's level before rendering."));return {};}StopPreview();if(!SaveClip())return {};auto* S=GEditor->GetEditorSubsystem<UCameraLightingRenderService>();const FString Id=S->QueueClip(SelectedClip->Sequence.LoadSynchronous(),SelectedClip->DisplayName,SelectedClip->FrameRate,FMath::Max(1,FMath::CeilToInt(SelectedClip->Duration*SelectedClip->FrameRate)));Status=S->GetStatusText();OnChanged.Broadcast();return Id;}
bool UCameraLightingClipService::RenderClip(){const FString Id=QueueClip();if(Id.IsEmpty())return false;auto* S=GEditor->GetEditorSubsystem<UCameraLightingRenderService>();const bool OK=S->RenderJob(Id);Status=S->GetStatusText();OnChanged.Broadcast();return OK;}
ULevelSequence* UCameraLightingClipService::ExportToSequencer(){if(!SelectedClip || !SaveClip())return nullptr;auto* Source=SelectedClip->Sequence.LoadSynchronous();const FString Name=TEXT("Editable_")+FGuid::NewGuid().ToString(EGuidFormats::Digits).Left(12);auto* P=CreatePackage(*(TEXT("/Game/CameraLightingClips/")+Name));auto* Copy=DuplicateObject<ULevelSequence>(Source,P,*Name);Copy->SetFlags(RF_Public|RF_Standalone);FAssetRegistryModule::AssetCreated(Copy);CameraLightingTemplates::Save(Copy);GEditor->GetEditorSubsystem<UAssetEditorSubsystem>()->OpenEditorForAsset(Copy);Status=TEXT("Independent Sequencer copy exported. Render advanced edits with native MRQ.");OnChanged.Broadcast();return Copy;}

bool UCameraLightingClipService::RenderDraft(){if(!SelectedClip || SelectedClip->Shots.IsEmpty() || !SaveClip())return false;return GEditor->GetEditorSubsystem<UCameraLightingRenderService>()->RenderDraftClip(SelectedClip->Sequence.LoadSynchronous(),SelectedClip->DisplayName,SelectedClip->FrameRate,FMath::CeilToInt(SelectedClip->Duration*SelectedClip->FrameRate));}

bool UCameraLightingClipService::SelectShot(int32 I,bool OpenSettings)
{
 if(!CanEdit() || bRecording || !SelectedClip || !SelectedClip->Shots.IsValidIndex(I) || SelectedClip->MapPath!=ClipMap())return false;StopPreview();auto& Shot=SelectedClip->Shots[I];if(Shot.Views.IsEmpty())return false;auto* A=Shot.CameraActor.LoadSynchronous();if(!A){FActorSpawnParameters P;P.ObjectFlags=RF_Transactional;auto* Cine=ClipWorld()->SpawnActor<ACineCameraActor>(ACineCameraActor::StaticClass(),Shot.Views[0].Transform,P);if(!Cine)return false;Cine->SetActorLabel(Shot.Label+TEXT(" Camera"));auto* Cam=Cine->GetCineCameraComponent();auto Film=Cam->Filmback;Film.SensorWidth=36;auto* R=GEditor->GetEditorSubsystem<UCameraLightingRenderService>();Film.SensorHeight=36.f*R->Height/R->Width;Cam->SetFilmback(Film);Cam->SetFieldOfView(Shot.Views[0].Fov);if(auto* Lighting=Shot.Views[0].Lighting.Get()){Cam->PostProcessSettings=Lighting->PostProcessSettings;Cam->PostProcessBlendWeight=1;Cam->SetCurrentAperture(Lighting->PostProcessSettings.DepthOfFieldFstop);auto F=Cam->FocusSettings;F.FocusMethod=Lighting->PostProcessSettings.DepthOfFieldFocalDistance>0?ECameraFocusMethod::Manual:ECameraFocusMethod::Disable;F.ManualFocusDistance=Lighting->PostProcessSettings.DepthOfFieldFocalDistance;Cam->SetFocusSettings(F);}FCameraLightingCapture::CaptureActor(Cine);A=Cine;SelectedClip->Modify();Shot.CameraActor=A;CameraLightingTemplates::Save(SelectedClip);}
 SelectedShotId=Shot.Id;GEditor->GetEditorSubsystem<UCameraLightingCameraTools>()->SelectTarget(A);if(OpenSettings)FCameraLightingEditorModule::OpenTab(FCameraLightingEditorModule::CameraTabId);OnChanged.Broadcast();return true;
}
void UCameraLightingClipService::SyncCameraEdit(AActor* A)
{
 if(bSyncing || bRecording || !SelectedClip || SelectedClip->MapPath!=ClipMap() || !A)return;const int32 I=SelectedClip->Shots.IndexOfByPredicate([&](const auto& S){return S.Id==SelectedShotId && S.CameraActor.Get()==A;});if(I<0 || SelectedClip->Shots[I].Views.IsEmpty())return;TGuardValue<bool> Guard(bSyncing,true);auto& Shot=SelectedClip->Shots[I];FCameraLightingClipView New;if(!CaptureView(New,A))return;SelectedClip->Modify();const auto First=Shot.Views[0];for(auto& V:Shot.Views){V.Transform=V.Transform.GetRelativeTransform(First.Transform)*New.Transform;V.Fov=FMath::Clamp(V.Fov+New.Fov-First.Fov,1.f,170.f);V.Lighting=New.Lighting;}SaveClip();
}
void UCameraLightingClipService::SetInterpolation(ECameraLightingInterpolation V){if(bRecording)return;RecordInterpolation=V;SaveConfig();if(SelectedClip)for(auto& Shot:SelectedClip->Shots)if(Shot.Id==SelectedShotId){SelectedClip->Modify();Shot.Interpolation=V;SaveClip();break;}}
ECameraLightingInterpolation UCameraLightingClipService::GetInterpolation()const{if(SelectedClip)for(const auto& Shot:SelectedClip->Shots)if(Shot.Id==SelectedShotId)return Shot.Interpolation;return RecordInterpolation;}
bool UCameraLightingClipService::SampleViewport(FCameraLightingClipView& Out)const{auto* V=ClipViewport();if(!V)return false;Out.Transform=FTransform(V->GetViewRotation(),V->GetViewLocation());Out.Fov=V->ViewFOV;return true;}
float UCameraLightingClipService::GetRecordingSeconds()const{return bRecording?FPlatformTime::Seconds()-RecordStart:0;}
bool UCameraLightingClipService::StartRecording()
{
 if(bRecording || !CanEdit())return false;if(!ClipWorld() || !FPackageName::DoesPackageExist(ClipWorld()->GetOutermost()->GetName())){Error(TEXT("Save the level before recording a camera take."));return false;}StopPreview();GEditor->GetEditorSubsystem<UCameraLightingViewportTools>()->CancelFocusPick();auto* V=ClipViewport();if(!V)return false;const FVector Position=V->GetViewLocation();const FRotator Rotation=V->GetViewRotation();V->SetActorLock(nullptr);V->SetCinematicActorLock(nullptr);V->SetViewLocation(Position);V->SetViewRotation(Rotation);RecordedFrames.Reset();if(!SampleViewport(PreviousSample))return false;PreviousSample.Time=0;RecordedFrames.Add(PreviousSample);RecordFPS=FMath::Clamp(RecordFPS,1,120);SaveConfig();RecordStart=FPlatformTime::Seconds();PreviousSampleTime=0;NextRecordFrame=1;bRecording=true;Status=TEXT("Recording viewport movement. Stop to create a new take and camera.");OnChanged.Broadcast();return true;
}
void UCameraLightingClipService::TickRecording()
{
 if(!GEditor || GEditor->PlayWorld || !ClipViewport()){StopRecording(true);return;}FCameraLightingClipView Current;if(!SampleViewport(Current))return;const double Now=GetRecordingSeconds();while(double(NextRecordFrame)/RecordFPS<=Now){const double Time=double(NextRecordFrame)/RecordFPS;const float A=FMath::Clamp(float((Time-PreviousSampleTime)/FMath::Max(Now-PreviousSampleTime,.000001)),0.f,1.f);FCameraLightingClipView V;V.Time=Time;V.Transform.Blend(PreviousSample.Transform,Current.Transform,A);V.Fov=FMath::Lerp(PreviousSample.Fov,Current.Fov,A);RecordedFrames.Add(V);++NextRecordFrame;}PreviousSample=Current;PreviousSampleTime=Now;if(Now>=600)StopRecording(true);
}
bool UCameraLightingClipService::StopRecording(bool Keep)
{
 if(!bRecording)return false;bRecording=false;if(!Keep){RecordedFrames.Reset();Status=TEXT("Recording discarded.");OnChanged.Broadcast();return true;}if(RecordedFrames.IsEmpty() || !ClipWorld())return false;
 FCameraLightingClipView Last;if(SampleViewport(Last)){Last.Time=float(NextRecordFrame)/RecordFPS;RecordedFrames.Add(Last);}auto Frames=RecordedFrames;auto* C=CreateClip();if(!C)return false;C->DisplayName=FString::Printf(TEXT("Recorded take %d"),Clips.Num());C->FrameRate=RecordFPS;C->Duration=FMath::Max(1.f/RecordFPS,Frames.Last().Time);
 FActorSpawnParameters P;P.ObjectFlags=RF_Transactional;auto* A=ClipWorld()->SpawnActor<ACineCameraActor>(ACineCameraActor::StaticClass(),Frames[0].Transform,P);if(!A)return false;A->SetActorLabel(C->DisplayName+TEXT(" Camera"));auto* Cam=A->GetCineCameraComponent();auto Film=Cam->Filmback;Film.SensorWidth=36;auto* Render=GEditor->GetEditorSubsystem<UCameraLightingRenderService>();Film.SensorHeight=36.f*Render->Height/Render->Width;Cam->SetFilmback(Film);Cam->SetFieldOfView(Frames[0].Fov);auto Focus=Cam->FocusSettings;Focus.FocusMethod=ECameraFocusMethod::Disable;Cam->SetFocusSettings(Focus);FCameraLightingCapture::CaptureActor(A);FCameraLightingClipView Captured;if(!CaptureView(Captured,A))return false;for(auto& Frame:Frames)Frame.Lighting=Captured.Lighting;
 FCameraLightingShot Shot;Shot.Id=FGuid::NewGuid().ToString();Shot.Label=A->GetActorLabel();Shot.Length=C->Duration;Shot.Views=MoveTemp(Frames);Shot.CameraActor=A;Shot.bRecorded=true;Shot.Interpolation=RecordInterpolation;C->Shots.Add(Shot);SelectedShotId=Shot.Id;RecordedFrames.Reset();A->MarkPackageDirty();const bool OK=SaveClip();GEditor->GetEditorSubsystem<UCameraLightingCameraTools>()->SelectTarget(A);Status=FString::Printf(TEXT("Recorded %d frames at %d fps. Save the level to keep the camera."),Shot.Views.Num(),RecordFPS);OnChanged.Broadcast();return OK;
}
bool UCameraLightingClipService::DropCamera(AActor* A,float Start){if(!A || !A->FindComponentByClass<UCameraComponent>() || !AddCameraView(A))return false;const FString Id=SelectedClip->Shots.Last().Id;SetShotRange(SelectedClip->Shots.Num()-1,Start,3);const int32 I=SelectedClip->Shots.IndexOfByPredicate([&](const auto& S){return S.Id==Id;});return SelectShot(I,false);}
