#include "CameraLightingRenderService.h"
#include "CameraLightingFrames.h"
#include "CameraLightingPipelineTools.h"
#include "CameraLightingClips.h"
#include "CameraLightingCapture.h"
#include "CameraLightingCameraTools.h"
#include "CameraLightingComponent.h"
#include "CameraLightingProfile.h"
#include "Camera/CameraComponent.h"
#include "CineCameraComponent.h"
#include "Editor.h"
#include "Engine/Selection.h"
#include "EngineUtils.h"
#include "LevelEditorViewport.h"
#include "FileHelpers.h"
#include "LevelSequence.h"
#include "MovieScene.h"
#include "MovieSceneSpawnable.h"
#include "Tracks/MovieSceneCameraCutTrack.h"
#include "Sections/MovieSceneCameraCutSection.h"
#include "Tracks/MovieSceneSpawnTrack.h"
#include "Sections/MovieSceneSpawnSection.h"
#include "MoviePipelineQueueSubsystem.h"
#include "MoviePipelinePIEExecutor.h"
#include "MoviePipelinePrimaryConfig.h"
#include "MoviePipelineOutputSetting.h"
#include "MoviePipelineImageSequenceOutput.h"
#include "MoviePipelineDeferredPasses.h"
#include "MoviePipelineAntiAliasingSetting.h"
#include "MoviePipelineColorSetting.h"
#include "MoviePipelineBlueprintLibrary.h"
#include "MoviePipeline.h"
#include "UObject/UObjectIterator.h"
#include "MovieRenderPipelineDataTypes.h"
#include "AssetRegistry/AssetRegistryModule.h"
#include "JsonObjectConverter.h"
#include "Serialization/JsonSerializer.h"
#include "Misc/FileHelper.h"
#include "Misc/PackageName.h"
#include "Misc/Paths.h"
#include "UObject/SavePackage.h"
#include "HAL/FileManager.h"
#include "HAL/IConsoleManager.h"
#include "HAL/PlatformProcess.h"
#include "Framework/Notifications/NotificationManager.h"
#include "Widgets/Notifications/SNotificationList.h"
#include "ScopedTransaction.h"

DEFINE_LOG_CATEGORY_STATIC(LogCameraStill,Log,All);
namespace
{
FString JournalPath() { return FPaths::ProjectSavedDir()/TEXT("CameraLightingRenders/queue-history.json"); }
UCameraComponent* CameraComponent(AActor* Actor) { return IsValid(Actor)?Actor->FindComponentByClass<UCameraComponent>():nullptr; }
float AspectValue(const FString& Name,float Original)
{
 if(Name==TEXT("16:9")) return 16.f/9.f;
 if(Name==TEXT("4:3")) return 4.f/3.f;
 if(Name==TEXT("3:2")) return 1.5f;
 if(Name==TEXT("1:1")) return 1.f;
 return Original;
}
float StillCropRatio(UCameraComponent* C)
{
 if(auto* Cine=Cast<UCineCameraComponent>(C))return Cine->CropSettings.AspectRatio;
 if(C)if(auto* D=Cast<UCameraLightingCropData>(C->GetAssetUserDataOfClass(UCameraLightingCropData::StaticClass())))return D->Ratio;
 return 0;
}
FString SafeFilename(const FString& Value)
{
 FString Result=FPaths::MakeValidFileName(Value,TEXT('_'));
 Result.ReplaceInline(TEXT("{"),TEXT("_")); Result.ReplaceInline(TEXT("}"),TEXT("_"));
 return Result.IsEmpty()?TEXT("Image"):Result;
}
}
void UCameraLightingRenderService::Initialize(FSubsystemCollectionBase& Collection)
{
 Super::Initialize(Collection); LoadConfig();
 ProgressTickHandle=FTSTicker::GetCoreTicker().AddTicker(FTickerDelegate::CreateUObject(this,&UCameraLightingRenderService::TickProgress),.25f);
 if(OutputDirectory.IsEmpty()) OutputDirectory=FPaths::ConvertRelativePathToFull(FPaths::ProjectSavedDir()/TEXT("CameraLightingRenders/Images"));
 Width=FMath::Clamp(Width,64,16384); Height=FMath::Clamp(Height,64,16384); SpatialSamples=FMath::Clamp(SpatialSamples,1,64);
 LoadQueue(); StatusText=TEXT("Ready. Create a scene or select a camera.");
}
void UCameraLightingRenderService::Deinitialize()
{
 FTSTicker::GetCoreTicker().RemoveTicker(ProgressTickHandle);
 if(Executor)
 {
  Executor->OnIndividualJobStarted().RemoveAll(this); Executor->OnIndividualJobWorkFinished().RemoveAll(this);
  Executor->OnExecutorFinished().RemoveAll(this); Executor->OnExecutorErrored().RemoveAll(this);
 }
 PersistSettings(); SaveQueue(); OnChanged.Clear(); Super::Deinitialize();
}
void UCameraLightingRenderService::PersistSettings() { SaveConfig(); }
void UCameraLightingRenderService::SetResolution(int32 W,int32 H)
{
 Width=FMath::Clamp(W,64,16384); Height=FMath::Clamp(H,64,16384);
 const float Actual=float(Width)/Height;
 if(AspectPreset!=TEXT("Original") && FMath::Abs(AspectValue(AspectPreset,Actual)-Actual)>0.005f) AspectPreset=TEXT("Custom");
 PersistSettings(); OnChanged.Broadcast();
}
void UCameraLightingRenderService::SetImageWidth(int32 W)
{
 const float Ratio=AspectValue(AspectPreset,float(Width)/FMath::Max(Height,1));
 SetResolution(W,bLockAspect?FMath::RoundToInt(FMath::Clamp(W,64,16384)/Ratio):Height);
}
void UCameraLightingRenderService::SetImageHeight(int32 H)
{
 const float Ratio=AspectValue(AspectPreset,float(Width)/FMath::Max(Height,1));
 SetResolution(bLockAspect?FMath::RoundToInt(FMath::Clamp(H,64,16384)*Ratio):Width,H);
}
void UCameraLightingRenderService::SetAspectPreset(const FString& Preset)
{
 if(Preset!=TEXT("Original") && Preset!=TEXT("16:9") && Preset!=TEXT("4:3") && Preset!=TEXT("3:2") && Preset!=TEXT("1:1")) return;
 AspectPreset=Preset;
 const UCameraComponent* Camera=CameraComponent(ResolveCamera(false));
 const float Ratio=AspectValue(Preset,Camera?Camera->AspectRatio:float(Width)/FMath::Max(Height,1));
 bLockAspect=true; SetResolution(Width,FMath::RoundToInt(Width/FMath::Max(Ratio,0.1f)));
}
void UCameraLightingRenderService::SetPresetSize(int32 LongEdge)
{
 const float Ratio=AspectValue(AspectPreset,float(Width)/FMath::Max(Height,1));
 if(Ratio>=1.f) SetResolution(LongEdge,FMath::RoundToInt(LongEdge/Ratio));
 else SetResolution(FMath::RoundToInt(LongEdge*Ratio),LongEdge);
}
void UCameraLightingRenderService::SetSelectedCamera(AActor* Camera)
{ SelectedCamera=CameraComponent(Camera)?Camera:nullptr; OnChanged.Broadcast(); }
AActor* UCameraLightingRenderService::ResolveCamera(bool bCreate)
{
 if(CameraComponent(SelectedCamera.Get()) && GEditor && SelectedCamera->GetWorld()==GEditor->GetEditorWorldContext().World()) return SelectedCamera.Get();
 if(AActor* Actor=FCameraLightingCapture::FindCaptureCamera()) return Actor;
 if(bCreate) { AActor* Created=FCameraLightingCapture::CreateSceneFromView(); SelectedCamera=Created; return Created; }
 return nullptr;
}
float UCameraLightingRenderService::GetCameraFov()
{
 if(UCameraComponent* Camera=CameraComponent(ResolveCamera(false)))
 {if(UCineCameraComponent* Cine=Cast<UCineCameraComponent>(Camera)) return Cine->GetHorizontalFieldOfView(); return Camera->FieldOfView;}
 if(GEditor) for(auto* VC:GEditor->GetLevelViewportClients()) if(VC && VC->IsPerspective()) return VC->ViewFOV;
 return 90.f;
}
float UCameraLightingRenderService::GetFocalLength()
{
 if(UCineCameraComponent* Cine=Cast<UCineCameraComponent>(CameraComponent(ResolveCamera(false)))) return Cine->CurrentFocalLength;
 return 18.f/FMath::Tan(FMath::DegreesToRadians(GetCameraFov()*0.5f));
}
void UCameraLightingRenderService::SetCameraFov(float Degrees)
{
 Degrees=FMath::Clamp(Degrees,5.f,170.f);
 if(UCameraComponent* Camera=CameraComponent(ResolveCamera(false)))
 {
  const FScopedTransaction Transaction(NSLOCTEXT("CameraLighting","LensChange","Change image camera lens"));
  Camera->Modify();
  if(UCineCameraComponent* Cine=Cast<UCineCameraComponent>(Camera))
   Cine->SetFieldOfView(Degrees);
  else Camera->SetFieldOfView(Degrees);
  Camera->GetOwner()->MarkPackageDirty();GEditor->GetEditorSubsystem<UCameraLightingClipService>()->SyncCameraEdit(Camera->GetOwner());
 }
 else if(GEditor) for(auto* VC:GEditor->GetLevelViewportClients()) if(VC && VC->IsPerspective()) {VC->ViewFOV=Degrees; VC->Invalidate(); break;}
 OnChanged.Broadcast();
}
void UCameraLightingRenderService::SetFocalLength(float Millimeters)
{
 if(auto* Cine=Cast<UCineCameraComponent>(CameraComponent(ResolveCamera(false)))){FScopedTransaction T(NSLOCTEXT("CameraLighting","SetFocalLength","Change camera focal length"));Cine->Modify();Cine->SetCurrentFocalLength(Millimeters);Cine->GetOwner()->MarkPackageDirty();GEditor->GetEditorSubsystem<UCameraLightingClipService>()->SyncCameraEdit(Cine->GetOwner());OnChanged.Broadcast();return;}
 SetCameraFov(FMath::RadiansToDegrees(2.f*FMath::Atan(36.f/(2.f*FMath::Clamp(Millimeters,1.f,1000.f)))));
}
void UCameraLightingRenderService::Fail(const FString& Message)
{
 StatusText=Message; UE_LOG(LogCameraStill,Error,TEXT("%s"),*Message);
 if(!bBackgroundRendering && !IsRunningCommandlet()) {FNotificationInfo Info(FText::FromString(Message));Info.ExpireDuration=6.f;FSlateNotificationManager::Get().AddNotification(Info);}
 OnChanged.Broadcast();
}
FCameraLightingStillJob* UCameraLightingRenderService::FindJob(const FString& Id)
{ return Jobs.FindByPredicate([&Id](const FCameraLightingStillJob& Job){return Job.Id==Id;}); }
bool UCameraLightingRenderService::BuildJobSequence(FCameraLightingStillJob& Job,AActor* Camera)
{
 auto* RenderTemplate=GetCurrentTemplate();
 Job.TemplateName=RenderTemplate?RenderTemplate->DisplayName:TEXT("Lumen Preview");Job.bPathTracing=RenderTemplate && RenderTemplate->Renderer==ECameraLightingRenderer::PathTracer;
 const FString PackageName=TEXT("/Game/CameraLightingRenders/Still_")+Job.Id;
 UPackage* Package=CreatePackage(*PackageName);
 auto* Sequence=NewObject<ULevelSequence>(Package,*FPackageName::GetLongPackageAssetName(PackageName),RF_Public|RF_Standalone);
 Sequence->Initialize();
 UMovieScene* Scene=Sequence->GetMovieScene(); Scene->SetDisplayRate(FFrameRate(24,1)); Scene->SetTickResolutionDirectly(FFrameRate(24000,1)); Scene->SetPlaybackRange(0,1000);
 // Snapshot the camera and its lighting component into the sequence. Later edits to the scene camera cannot change queued images.
 auto* Template=Cast<AActor>(Sequence->MakeSpawnableTemplateFromInstance(*Camera,TEXT("StillCamera")));
 if(!Template) {Fail(TEXT("Could not snapshot the image camera."));return false;}
 Template->SetActorTransform(Camera->GetActorTransform());
 if(UCameraComponent* Component=CameraComponent(Template))
 { Component->SetAspectRatio(float(Job.Width)/Job.Height); Component->bConstrainAspectRatio=false; Component->AspectRatioAxisConstraint=EAspectRatioAxisConstraint::AspectRatio_MaintainXFOV;Component->PostProcessBlendWeight=1; }
 if(UCameraLightingComponent* Component=Template->FindComponentByClass<UCameraLightingComponent>())
 {
  if(const UCameraLightingProfile* Original=Component->GetResolvedProfile())
  {
   auto* Snapshot=DuplicateObject<UCameraLightingProfile>(Original,Package,TEXT("LightingSnapshot"));
   Snapshot->SetFlags(RF_Public|RF_Standalone);Snapshot->PreviewImage.Reset();Snapshot->StoredPreview=nullptr;
   CameraLightingTemplates::ApplyLook(Snapshot->PostProcessSettings,RenderTemplate);
   Component->Profile=Snapshot;
  }
 }
 const FGuid Binding=Scene->AddSpawnable(Job.Label,*Template);
 auto* SpawnTrack=Scene->AddTrack<UMovieSceneSpawnTrack>(Binding);
 auto* Spawn=CastChecked<UMovieSceneSpawnSection>(SpawnTrack->CreateNewSection());
 Spawn->GetChannel().SetDefault(true); Spawn->SetRange(TRange<FFrameNumber>::All()); SpawnTrack->AddSection(*Spawn);
 auto* Track=Scene->AddCameraCutTrack(UMovieSceneCameraCutTrack::StaticClass());
 auto* Cut=CastChecked<UMovieSceneCameraCutSection>(Track->CreateNewSection());
 Cut->SetCameraGuid(Binding); Cut->SetRange(TRange<FFrameNumber>(0,1000)); Track->AddSection(*Cut);
 if(auto* CameraSettings=CameraComponent(Template))CameraLightingTemplates::ApplyLook(CameraSettings->PostProcessSettings,RenderTemplate);
 auto* RenderConfig=CameraLightingTemplates::Build(RenderTemplate,Package);RenderConfig->Rename(TEXT("RenderSettings"),Package);RenderConfig->SetFlags(RF_Public|RF_Standalone);
 Job.RenderConfigPath=FSoftObjectPath(RenderConfig).ToString();
 FAssetRegistryModule::AssetCreated(Sequence);
 FSavePackageArgs Args;Args.TopLevelFlags=RF_Public|RF_Standalone;
 if(!UPackage::SavePackage(Package,Sequence,*FPackageName::LongPackageNameToFilename(PackageName,FPackageName::GetAssetPackageExtension()),Args))
 {Fail(TEXT("Cannot save the queued camera snapshot. Check project write permissions."));return false;}
 Job.SequencePath=FSoftObjectPath(Sequence).ToString();return true;
}
FString UCameraLightingRenderService::QueueCamera(AActor* Camera)
{
 if(GEditor && GEditor->GetEditorSubsystem<UCameraLightingClipService>()->bRecording){Fail(TEXT("Stop viewport recording before queueing scenes."));return {};}
 if(IsRendering()) {Fail(TEXT("Wait for the active render to finish before adding scenes."));return {};}
 if(!Camera) Camera=ResolveCamera(true);
 if(!CameraComponent(Camera)) {Fail(TEXT("No camera or perspective viewport is available. Select a Camera Actor and try again."));return {};}
 UWorld* World=GEditor?GEditor->GetEditorWorldContext().World():nullptr;
 if(!World || Camera->GetWorld()!=World || !World->GetOutermost()->GetName().StartsWith(TEXT("/Game/")))
 {Fail(TEXT("Save the level once before adding an image to the render queue."));return {};}
 FCameraLightingStillJob Job;Job.Id=FGuid::NewGuid().ToString(EGuidFormats::Digits);Job.Label=Camera->GetActorLabel();
 Job.CameraPath=FSoftObjectPath(Camera).ToString();Job.MapPath=FSoftObjectPath(World).ToString();
 Job.Width=FMath::Clamp(Width,64,16384);Job.Height=FMath::Clamp(Height,64,16384);Job.Format=Format;
 // A camera crop is a framing choice, not a stretch. Freeze its actual aspect per still job.
 const float Crop=StillCropRatio(CameraComponent(Camera));if(Crop>0){Job.Height=FMath::RoundToInt(Job.Width/Crop);if(Job.Height>16384){Job.Height=16384;Job.Width=FMath::RoundToInt(Job.Height*Crop);}if(Job.Height<64){Job.Height=64;Job.Width=FMath::RoundToInt(Job.Height*Crop);}}
 Job.OutputDirectory=FPaths::ConvertRelativePathToFull(OutputDirectory);Job.Prefix=SafeFilename(FilePrefix);Job.CreatedAt=FDateTime::UtcNow().ToIso8601();
 if(!BuildJobSequence(Job,Camera)) return {};
 Jobs.Add(Job);PersistSettings();SaveQueue();StatusText=Job.Label+TEXT(" added to queue.");OnChanged.Broadcast();return Job.Id;
}
int32 UCameraLightingRenderService::QueueAllCameras()
{
 TArray<AActor*> Cameras;
 if(GEditor) if(UWorld* World=GEditor->GetEditorWorldContext().World()) for(TActorIterator<AActor> It(World);It;++It) if(CameraComponent(*It) && !It->HasAnyFlags(RF_Transient)) Cameras.Add(*It);
 Cameras.Sort([](const AActor& A,const AActor& B){return A.GetActorLabel()<B.GetActorLabel();});
 int32 Count=0;for(AActor* Camera:Cameras) if(!QueueCamera(Camera).IsEmpty()) ++Count;return Count;
}
bool UCameraLightingRenderService::RenderCamera(AActor* Camera)
{ const FString Id=QueueCamera(Camera);return !Id.IsEmpty() && PrepareAndRender({Id}); }
bool UCameraLightingRenderService::RenderQueued()
{
 TArray<FString> Ids;for(const auto& Job:Jobs) if(Job.State==ECameraLightingJobState::Waiting && Job.bSelected) Ids.Add(Job.Id);
 return PrepareAndRender(Ids);
}
bool UCameraLightingRenderService::PrepareAndRender(const TArray<FString>& Ids)
{
 if(GEditor && GEditor->GetEditorSubsystem<UCameraLightingClipService>()->bRecording){Fail(TEXT("Stop viewport recording before rendering."));return false;}
 if(bPreparingRender) return false;
 auto* Tools=GEditor?GEditor->GetEditorSubsystem<UCameraLightingPipelineTools>():nullptr;if(Tools){auto Issues=Tools->Inspect(Ids,true);Tools->LastPreflight.Reset();for(const auto& I:Issues)Tools->LastPreflight+=I.Severity+TEXT(" · ")+I.Message+TEXT("\n");FString Errors;for(const auto& I:Issues)if(I.Severity==TEXT("ERROR"))Errors+=I.Message+TEXT("\n");if(!Errors.IsEmpty()){Tools->LastPreflight=Errors;Fail(Errors);return false;}}

 TGuardValue<bool> PreparingGuard(bPreparingRender,true);
 auto* Sub=GEditor?GEditor->GetEditorSubsystem<UMoviePipelineQueueSubsystem>():nullptr;
 if(!Sub || GEditor->PlayWorld || Sub->IsRendering()) {Fail(TEXT("Stop Play/Simulate or the current render before starting images."));return false;}
 if(Ids.IsEmpty()) {Fail(TEXT("Select at least one waiting image in the queue."));return false;}
 UWorld* World=GEditor->GetEditorWorldContext().World();
 if(!World || !World->GetOutermost()->GetName().StartsWith(TEXT("/Game/"))) {Fail(TEXT("Save your level before rendering."));return false;}
 for(const FString& Id:Ids)
 {
  auto* Job=FindJob(Id);
  if(!Job || Job->MapPath!=FSoftObjectPath(World).ToString()) {Fail(TEXT("Open the level associated with these queued images before rendering."));return false;}
  if(Job->bPathTracing)
  {
   auto* Ray=IConsoleManager::Get().FindConsoleVariable(TEXT("r.RayTracing"));auto* Path=IConsoleManager::Get().FindConsoleVariable(TEXT("r.PathTracing"));
   if(!Ray || !Ray->GetInt() || !Path || !Path->GetInt()){Fail(TEXT("This queued Path Tracer image requires hardware ray tracing and Path Tracing enabled. The renderer was not changed to Lumen."));return false;}
  }
  if(!Job->RenderConfigPath.IsEmpty() && !Cast<UMoviePipelinePrimaryConfig>(FSoftObjectPath(Job->RenderConfigPath).TryLoad())) {Fail(TEXT("The queued render settings are missing. Remove that row and add the scene again."));return false;}
  if(!FSoftObjectPath(Job->SequencePath).TryLoad()) {Fail(TEXT("A queued camera snapshot is missing. Remove that row and add the scene again."));return false;}
 }
 // The button is explicitly Save & Render. Save this level (including external actors) before PIE starts.
 if(!UEditorLoadingAndSavingUtils::SaveMap(World,World->GetOutermost()->GetName())) {Fail(TEXT("The level could not be saved. Rendering has not started."));return false;}
 ActiveQueue=NewObject<UMoviePipelineQueue>(this);ActiveJobs.Reset();ActiveRanges.Reset();RemainingRanges.Reset();FailedRangeJobs.Reset();bCancelRequested=false;BatchFrames=0;BatchCompleted=0;BatchStart=FPlatformTime::Seconds();SecondsPerFrame=0;
 for(const auto& Id:Ids)if(auto* Item=FindJob(Id)){if(Item->bRecovering){for(auto R:Item->RecoveryRanges)BatchFrames+=R.Y-R.X;Item->CompletedFrames=CameraLightingFindFrames(*Item).Num();}else{BatchFrames+=Item->FrameCount;Item->CompletedFrames=0;}Item->ElapsedSeconds=0;}
 for(const FString& Id:Ids)
 {
  auto* Item=FindJob(Id);const TArray<FIntPoint> Ranges=Item->bRecovering?Item->RecoveryRanges:TArray<FIntPoint>{FIntPoint(0,Item->FrameCount)};RemainingRanges.Add(Id,Ranges.Num());
  for(auto Range:Ranges){auto* Job=ActiveQueue->AllocateNewJob(UMoviePipelineExecutorJob::StaticClass());
  Job->JobName=Item->Label;Job->Map=FSoftObjectPath(Item->MapPath);Job->Sequence=FSoftObjectPath(Item->SequencePath);ActiveJobs.Add(Job,Id);ActiveRanges.Add(Job,Range);
  auto* Config=Job->GetConfiguration();
  if(auto* Snapshot=Cast<UMoviePipelinePrimaryConfig>(FSoftObjectPath(Item->RenderConfigPath).TryLoad()))Config->CopyFrom(Snapshot);
  // Output controls are job-level overrides; keep exactly one requested image writer.
  for(auto* Setting:Config->GetUserSettings())if(Setting->IsA<UMoviePipelineImageSequenceOutputBase>())Config->RemoveSetting(Setting);
  auto* Output=CastChecked<UMoviePipelineOutputSetting>(Config->FindOrAddSettingByClass(UMoviePipelineOutputSetting::StaticClass()));
  Output->OutputResolution=FIntPoint(Item->Width,Item->Height);
  Output->bUseCustomPlaybackRange=true;Output->CustomStartFrame=Range.X;Output->CustomEndFrame=Range.Y;Output->ZeroPadFrameNumbers=8;Output->FrameNumberOffset=0;
  Output->bUseCustomFrameRate=true;Output->OutputFrameRate=FFrameRate(Item->FrameRate,1);
  // Footer destination/prefix apply to the selected batch. Each image keeps its own camera, dimensions and format.
  if(!Item->bRecovering){Item->OutputDirectory=FPaths::ConvertRelativePathToFull(OutputDirectory);Item->Prefix=SafeFilename(FilePrefix);}
  if(!IFileManager::Get().MakeDirectory(*Item->OutputDirectory,true)) {Fail(TEXT("Cannot create the output folder. Choose a writable location."));ActiveQueue=nullptr;return false;}
  Output->OutputDirectory.Path=Item->OutputDirectory;
  Output->FileNameFormat=Item->Prefix+TEXT("_")+SafeFilename(Item->Label)+TEXT("_")+Item->Id.Left(8)+TEXT("_{frame_number}");
  Output->bOverrideExistingOutput=false;
  if(Item->Format==ECameraLightingImageFormat::EXR)
  {
   UClass* ExrClass=LoadClass<UMoviePipelineSetting>(nullptr,TEXT("/Script/MovieRenderPipelineRenderPasses.MoviePipelineImageSequenceOutput_EXR"));
   if(!ExrClass) {Fail(TEXT("EXR output is unavailable. Enable Movie Render Queue render passes."));return false;}
   Config->FindOrAddSettingByClass(ExrClass);
  }
  else if(Item->Format==ECameraLightingImageFormat::JPEG) Config->FindOrAddSettingByClass(UMoviePipelineImageSequenceOutput_JPG::StaticClass());
  else Config->FindOrAddSettingByClass(UMoviePipelineImageSequenceOutput_PNG::StaticClass());
  if(Item->RenderConfigPath.IsEmpty())
  {
   Config->FindOrAddSettingByClass(UMoviePipelineDeferredPassBase::StaticClass());
   auto* AA=CastChecked<UMoviePipelineAntiAliasingSetting>(Config->FindOrAddSettingByClass(UMoviePipelineAntiAliasingSetting::StaticClass()));
   AA->SpatialSampleCount=FMath::Clamp(SpatialSamples,1,64);AA->TemporalSampleCount=1;
   AA->bUseCameraCutForWarmUp=false;AA->EngineWarmUpCount=32;AA->RenderWarmUpCount=8;
  }
  if(!Item->bRecovering)Item->OutputFiles.Reset();Item->Error.Reset();
  }
 }
 Executor=NewObject<UMoviePipelinePIEExecutor>(this);Executor->SetIsRenderingOffscreen(bBackgroundRendering);
 Executor->OnIndividualJobStarted().AddUObject(this,&UCameraLightingRenderService::HandleJobStarted);
 Executor->OnIndividualJobWorkFinished().AddUObject(this,&UCameraLightingRenderService::HandleJobFinished);
 Executor->OnExecutorFinished().AddUObject(this,&UCameraLightingRenderService::HandleFinished);
 Executor->OnExecutorErrored().AddUObject(this,&UCameraLightingRenderService::HandleError);
 StatusText=FString::Printf(TEXT("Rendering %d image(s)..."),Ids.Num());SaveQueue();OnChanged.Broadcast();
 Sub->RenderQueueInstanceWithExecutorInstance(ActiveQueue,Executor);return true;
}
void UCameraLightingRenderService::HandleJobStarted(UMoviePipelineExecutorJob* PipelineJob)
{
 if(const FString* Id=ActiveJobs.Find(PipelineJob)) if(auto* Job=FindJob(*Id)) {Job->State=ECameraLightingJobState::Rendering;Job->CompletedFrames=0;ExecutingJob=PipelineJob;JobStart=FPlatformTime::Seconds();RateSampleTime=0;RateSampleFrames=0;StatusText=TEXT("Rendering ")+Job->Label;}
 SaveQueue();OnChanged.Broadcast();
}
void UCameraLightingRenderService::HandleJobFinished(FMoviePipelineOutputData Data)
{
 if(const FString* Id=ActiveJobs.Find(Data.Job)) if(auto* Job=FindJob(*Id))
 {
  for(const auto& Shot:Data.ShotData)for(const auto& Pass:Shot.RenderPassData)for(const auto& File:Pass.Value.FilePaths)if(IFileManager::Get().FileSize(*File)>0)Job->OutputFiles.AddUnique(File);
  const auto Range=ActiveRanges.FindRef(Data.Job);const bool OK=Data.bSuccess && !Data.ShotData.IsEmpty();if(!OK)FailedRangeJobs.Add(*Id);int32& Remaining=RemainingRanges.FindChecked(*Id);--Remaining;Job->ElapsedSeconds=FPlatformTime::Seconds()-JobStart;
  if(OK){BatchCompleted+=Range.Y-Range.X;if(SecondsPerFrame<=0)SecondsPerFrame=Job->ElapsedSeconds/FMath::Max(Range.Y-Range.X,1);}
  if(bCancelRequested)Job->State=ECameraLightingJobState::Canceled;else if(Remaining>0)Job->State=ECameraLightingJobState::Rendering;else{auto Files=CameraLightingFindFrames(*Job);Job->CompletedFrames=Files.Num();Job->OutputFiles.Reset();for(int32 I=0;I<Job->FrameCount;++I)if(auto* File=Files.Find(I))Job->OutputFiles.Add(*File);Job->State=!FailedRangeJobs.Contains(*Id) && Files.Num()==Job->FrameCount?ECameraLightingJobState::Completed:ECameraLightingJobState::Failed;}

  ExecutingJob.Reset();Job->CompletedAt=FDateTime::UtcNow().ToIso8601();
  if(Job->State==ECameraLightingJobState::Failed && Job->Error.IsEmpty()) Job->Error=FString::Printf(TEXT("Only %d of %d expected frames were found in %s. Check output permissions, disk space, encoder/render errors, or use Recover missing frames."),Job->CompletedFrames,Job->FrameCount,*Job->OutputDirectory);
 }
 SaveQueue();OnChanged.Broadcast();
}
void UCameraLightingRenderService::HandleFinished(UMoviePipelineExecutorBase*,bool bSuccess)
{
 for(const auto& Pair:ActiveJobs) if(auto* Job=FindJob(Pair.Value))
  if(Job->State==ECameraLightingJobState::Rendering || Job->State==ECameraLightingJobState::Waiting)
  {Job->State=bCancelRequested?ECameraLightingJobState::Canceled:ECameraLightingJobState::Failed;Job->CompletedAt=FDateTime::UtcNow().ToIso8601();}
 for(const auto& Pair:ActiveJobs) if(auto* Job=FindJob(Pair.Value)) if(Job->State==ECameraLightingJobState::Failed) bSuccess=false;
 StatusText=bCancelRequested?TEXT("Render canceled. Finished images are available in History."):(bSuccess?TEXT("Rendering finished. Open History to view the images."):TEXT("Rendering finished with errors. See the failed rows in History."));
 for(auto& Item:Jobs)if(RemainingRanges.Contains(Item.Id) && Item.State==ECameraLightingJobState::Completed){Item.bRecovering=false;Item.RecoveryRanges.Reset();}SaveQueue();OnChanged.Broadcast();ActiveJobs.Reset();ActiveRanges.Reset();
}
void UCameraLightingRenderService::HandleError(UMoviePipelineExecutorBase*,UMoviePipeline*,bool bFatal,FText Text)
{
 StatusText=Text.ToString();if(bFatal) for(const auto& Pair:ActiveJobs) if(auto* Job=FindJob(Pair.Value)) if(Job->State==ECameraLightingJobState::Rendering) Job->Error=StatusText;
 UE_LOG(LogCameraStill,Warning,TEXT("%s"),*StatusText);OnChanged.Broadcast();
}
void UCameraLightingRenderService::CancelRendering()
{if(Executor && Executor->IsRendering()) {bCancelRequested=true;StatusText=TEXT("Canceling after the current frame...");Executor->CancelAllJobs();OnChanged.Broadcast();}}
bool UCameraLightingRenderService::IsRendering() const {return bPreparingRender || (Executor && Executor->IsRendering());}
FString UCameraLightingRenderService::GetStatusText() const {return StatusText;}
void UCameraLightingRenderService::SetJobSelected(const FString& Id,bool bSelected)
{if(auto* Job=FindJob(Id)) {Job->bSelected=bSelected;SaveQueue();OnChanged.Broadcast();}}
void UCameraLightingRenderService::RemoveQueuedJob(const FString& Id)
{if(IsRendering()) return;Jobs.RemoveAll([&Id](const auto& Job){return Job.Id==Id && Job.State==ECameraLightingJobState::Waiting;});SaveQueue();OnChanged.Broadcast();}
void UCameraLightingRenderService::RetryJob(const FString& Id){NewAttempt(Id);}

void UCameraLightingRenderService::OpenOutputDirectory() {if(!OutputDirectory.IsEmpty()) FPlatformProcess::ExploreFolder(*FPaths::ConvertRelativePathToFull(OutputDirectory));}
void UCameraLightingRenderService::SetBackgroundRendering(bool bEnabled) {bBackgroundRendering=bEnabled;}
void UCameraLightingRenderService::SaveQueue()
{
 TArray<TSharedPtr<FJsonValue>> Items;for(const auto& Job:Jobs)
 {auto Json=MakeShared<FJsonObject>();FJsonObjectConverter::UStructToJsonObject(FCameraLightingStillJob::StaticStruct(),&Job,Json,0,0);Items.Add(MakeShared<FJsonValueObject>(Json));}
 auto Root=MakeShared<FJsonObject>();Root->SetNumberField(TEXT("version"),1);Root->SetArrayField(TEXT("jobs"),Items);
 FString Text;auto Writer=TJsonWriterFactory<>::Create(&Text);FJsonSerializer::Serialize(Root,Writer);
 const FString Path=JournalPath();IFileManager::Get().MakeDirectory(*FPaths::GetPath(Path),true);
 // Write then rename, so an interrupted save cannot replace the last complete journal with a partial file.
 if(FFileHelper::SaveStringToFile(Text,*(Path+TEXT(".tmp")))) IFileManager::Get().Move(*Path,*(Path+TEXT(".tmp")),true,true);
}
void UCameraLightingRenderService::LoadQueue()
{
 FString Text;if(!FFileHelper::LoadFileToString(Text,*JournalPath())) return;
 TSharedPtr<FJsonObject> Root;if(!FJsonSerializer::Deserialize(TJsonReaderFactory<>::Create(Text),Root)||!Root) return;
 const TArray<TSharedPtr<FJsonValue>>* Items=nullptr;if(!Root->TryGetArrayField(TEXT("jobs"),Items))return;
 for(const auto& Value:*Items)
 {
  if(Jobs.Num()>=1000) break;FCameraLightingStillJob Job;
  if(Value->Type!=EJson::Object || !FJsonObjectConverter::JsonObjectToUStruct(Value->AsObject().ToSharedRef(),FCameraLightingStillJob::StaticStruct(),&Job,0,0) || Job.Id.IsEmpty()) continue;
  if(Job.State==ECameraLightingJobState::Rendering) {Job.State=ECameraLightingJobState::Failed;Job.Error=TEXT("The previous editor session ended while this image was rendering.");}
  Jobs.Add(Job);
 }
}

FString UCameraLightingRenderService::QueueClip(ULevelSequence* Sequence,const FString& Label,int32 Fps,int32 Frames)
{
 if(IsRendering() || !Sequence){Fail(TEXT("Wait for the current render and choose a valid clip."));return {};}
 UWorld* World=GEditor?GEditor->GetEditorWorldContext().World():nullptr;if(!World || GEditor->PlayWorld || !World->GetOutermost()->GetName().StartsWith(TEXT("/Game/"))){Fail(TEXT("Save this level before queueing a clip, and stop Play/Simulate."));return {};}
 FCameraLightingStillJob Job;Job.Id=FGuid::NewGuid().ToString(EGuidFormats::Digits);Job.Label=Label;Job.MapPath=FSoftObjectPath(World).ToString();Job.Width=Width;Job.Height=Height;Job.Format=Format;Job.bClip=true;Job.FrameRate=FMath::Clamp(Fps,1,120);Job.FrameCount=FMath::Clamp(Frames,1,432000);Job.CreatedAt=FDateTime::UtcNow().ToIso8601();
 Job.OutputDirectory=FPaths::ConvertRelativePathToFull(OutputDirectory);Job.Prefix=SafeFilename(FilePrefix);
 auto* RenderTemplate=GetCurrentTemplate();Job.TemplateName=RenderTemplate?RenderTemplate->DisplayName:TEXT("Will's Lumen");Job.bPathTracing=RenderTemplate && RenderTemplate->Renderer==ECameraLightingRenderer::PathTracer;
 const FString PackageName=TEXT("/Game/CameraLightingRenders/Clip_")+Job.Id;auto* Package=CreatePackage(*PackageName);auto* Copy=DuplicateObject<ULevelSequence>(Sequence,Package,*FPackageName::GetLongPackageAssetName(PackageName));Copy->SetFlags(RF_Public|RF_Standalone);
 auto* MovieScene=Copy->GetMovieScene();
 for(int32 I=0;I<MovieScene->GetSpawnableCount();++I)if(auto* Actor=Cast<AActor>(MovieScene->GetSpawnable(I).GetObjectTemplate()))
 {
  if(auto* Camera=CameraComponent(Actor)){Camera->SetAspectRatio(float(Job.Width)/Job.Height);Camera->bConstrainAspectRatio=false;Camera->AspectRatioAxisConstraint=EAspectRatioAxisConstraint::AspectRatio_MaintainXFOV;Camera->PostProcessBlendWeight=1;CameraLightingTemplates::ApplyLook(Camera->PostProcessSettings,RenderTemplate);}
  if(auto* Component=Actor->FindComponentByClass<UCameraLightingComponent>())if(auto* Original=Component->GetResolvedProfile()){auto* Lighting=DuplicateObject<UCameraLightingProfile>(Original,Package,*FString::Printf(TEXT("ClipLighting_%d"),I));Lighting->SetFlags(RF_Public|RF_Standalone);Lighting->PreviewImage.Reset();Lighting->StoredPreview=nullptr;CameraLightingTemplates::ApplyLook(Lighting->PostProcessSettings,RenderTemplate);Component->Profile=Lighting;}
 }
 auto* Config=CameraLightingTemplates::Build(RenderTemplate,Package);Config->Rename(TEXT("RenderSettings"),Package);Config->SetFlags(RF_Public|RF_Standalone);Job.RenderConfigPath=FSoftObjectPath(Config).ToString();Job.SequencePath=FSoftObjectPath(Copy).ToString();
 FAssetRegistryModule::AssetCreated(Copy);if(!CameraLightingTemplates::Save(Copy)){Fail(TEXT("Could not save the queued clip snapshot."));return {};}
 Jobs.Add(Job);SaveQueue();PersistSettings();StatusText=Label+TEXT(" added to queue (image sequence).");OnChanged.Broadcast();return Job.Id;
}
bool UCameraLightingRenderService::RenderClip(ULevelSequence* Sequence,const FString& Label,int32 Fps,int32 Frames)
{const FString Id=QueueClip(Sequence,Label,Fps,Frames);return !Id.IsEmpty() && PrepareAndRender({Id});}

bool UCameraLightingRenderService::RenderJob(const FString& Id){return FindJob(Id)?PrepareAndRender({Id}):false;}

float UCameraLightingRenderService::GetCameraCropRatio(){return StillCropRatio(CameraComponent(ResolveCamera(false)));}

bool UCameraLightingRenderService::MakeDraft(const FString& Id)
{
 auto* J=FindJob(Id);if(!J)return false;J->bDraft=true;if(!J->Label.EndsWith(TEXT(" · Draft")))J->Label+=TEXT(" · Draft");const float Scale=FMath::Min(1.f,960.f/FMath::Max(J->Width,J->Height));J->Width=FMath::Max(64,FMath::RoundToInt(J->Width*Scale));J->Height=FMath::Max(64,FMath::RoundToInt(J->Height*Scale));J->Format=ECameraLightingImageFormat::PNG;
 auto* Config=Cast<UMoviePipelinePrimaryConfig>(FSoftObjectPath(J->RenderConfigPath).TryLoad());if(!Config)return false;auto* AA=CastChecked<UMoviePipelineAntiAliasingSetting>(Config->FindOrAddSettingByClass(UMoviePipelineAntiAliasingSetting::StaticClass()));AA->SpatialSampleCount=J->bPathTracing?32:1;AA->TemporalSampleCount=1;AA->bOverrideAntiAliasing=true;AA->AntiAliasingMethod=AAM_None;AA->EngineWarmUpCount=16;AA->RenderWarmUpCount=J->bPathTracing?0:16;
 auto* Color=CastChecked<UMoviePipelineColorSetting>(Config->FindOrAddSettingByClass(UMoviePipelineColorSetting::StaticClass()));Color->bDisableToneCurve=false;
 if(!CameraLightingTemplates::Save(Config)){Fail(TEXT("Could not save draft configuration."));return false;}SaveQueue();return true;
}
FString UCameraLightingRenderService::QueueDraftCamera(AActor* Camera){const FString Id=QueueCamera(Camera);return MakeDraft(Id)?Id:FString();}
bool UCameraLightingRenderService::RenderDraftCamera(AActor* Camera){const FString Id=QueueDraftCamera(Camera);return !Id.IsEmpty() && PrepareAndRender({Id});}
bool UCameraLightingRenderService::RenderDraftClip(ULevelSequence* Sequence,const FString& Label,int32 Fps,int32 Frames){const FString Id=QueueClip(Sequence,Label,Fps,Frames);return MakeDraft(Id) && PrepareAndRender({Id});}
bool UCameraLightingRenderService::TickProgress(float)
{
 if(!IsRendering())return true;UMoviePipeline* Pipeline=nullptr;for(TObjectIterator<UMoviePipeline>I;I;++I)if(ActiveJobs.Contains(I->GetCurrentJob())){Pipeline=*I;break;}if(!Pipeline)return true;
 auto* PJob=Pipeline->GetCurrentJob();const auto* Id=ActiveJobs.Find(PJob);auto* J=Id?FindJob(*Id):nullptr;if(!J)return true;J->ElapsedSeconds=FPlatformTime::Seconds()-JobStart;const int32 Done=FMath::Clamp(FMath::FloorToInt(UMoviePipelineBlueprintLibrary::GetCompletionPercentage(Pipeline)*(ActiveRanges.FindRef(PJob).Y-ActiveRanges.FindRef(PJob).X)),0,ActiveRanges.FindRef(PJob).Y-ActiveRanges.FindRef(PJob).X);J->CompletedFrames=Done;
 const double Now=FPlatformTime::Seconds();if(Done>0 && RateSampleTime<=0){RateSampleTime=Now;RateSampleFrames=Done;}else if(Done>RateSampleFrames){const double Sample=(Now-RateSampleTime)/(Done-RateSampleFrames);SecondsPerFrame=SecondsPerFrame>0?FMath::Lerp(SecondsPerFrame,Sample,.35):Sample;RateSampleTime=Now;RateSampleFrames=Done;}return true;
}
float UCameraLightingRenderService::GetBatchProgress()const{if(BatchFrames<=0)return 0;int32 Done=BatchCompleted;if(auto* Id=ActiveJobs.Find(ExecutingJob))for(const auto& J:Jobs)if(J.Id==*Id)Done+=J.CompletedFrames;return FMath::Clamp(float(Done)/BatchFrames,0.f,1.f);}

float UCameraLightingRenderService::GetEstimatedSecondsRemaining()const{if(!IsRendering() || SecondsPerFrame<=0)return -1;return (1-GetBatchProgress())*BatchFrames*SecondsPerFrame;}
FString UCameraLightingRenderService::GetProgressText()const{if(!IsRendering())return StatusText;const float Remaining=GetEstimatedSecondsRemaining();const int32 Done=FMath::RoundToInt(GetBatchProgress()*BatchFrames);return Remaining<0?FString::Printf(TEXT("%d / %d frames · warming up / estimating"),Done,BatchFrames):FString::Printf(TEXT("%d / %d frames · approx. %dm %ds left"),Done,BatchFrames,FMath::FloorToInt(Remaining/60),FMath::RoundToInt(FMath::Fmod(Remaining,60.f)));}

int32 UCameraLightingRenderService::ApplySettingsToSelectedJobs()
{
 if(IsRendering())return 0;auto* T=GetCurrentTemplate();if(!T)return 0;int32 Count=0;
 for(auto& J:Jobs)if(J.State==ECameraLightingJobState::Waiting && J.bSelected && !J.bRecovering){auto* Seq=LoadObject<ULevelSequence>(nullptr,*J.SequencePath);if(!Seq)continue;auto* Package=Seq->GetOutermost();auto* Config=CameraLightingTemplates::Build(T,Package);Config->Rename(*MakeUniqueObjectName(Package,Config->GetClass(),TEXT("BatchSettings")).ToString(),Package);Config->SetFlags(RF_Public|RF_Standalone);J.RenderConfigPath=FSoftObjectPath(Config).ToString();J.TemplateName=T->DisplayName;J.bPathTracing=T->Renderer==ECameraLightingRenderer::PathTracer;J.Format=Format;J.Width=Width;J.Height=Height;
 auto* M=Seq->GetMovieScene();for(int32 I=0;I<M->GetSpawnableCount();++I)if(auto* Actor=Cast<AActor>(M->GetSpawnable(I).GetObjectTemplate())){if(auto* C=CameraComponent(Actor)){float Crop=StillCropRatio(C);if(!J.bClip && Crop>0)J.Height=FMath::Clamp(FMath::RoundToInt(J.Width/Crop),64,16384);C->SetAspectRatio(float(J.Width)/J.Height);CameraLightingTemplates::ApplyLook(C->PostProcessSettings,T);}if(auto* L=Actor->FindComponentByClass<UCameraLightingComponent>())if(auto* P=const_cast<UCameraLightingProfile*>(L->GetResolvedProfile()))CameraLightingTemplates::ApplyLook(P->PostProcessSettings,T);}
 if(J.bDraft)MakeDraft(J.Id);if(CameraLightingTemplates::Save(Seq))++Count;}
 SaveQueue();StatusText=FString::Printf(TEXT("Updated settings on %d selected waiting jobs."),Count);OnChanged.Broadcast();return Count;
}

bool UCameraLightingRenderService::StartRecovery(const FString& Id,const TArray<FIntPoint>& Ranges){if(IsRendering() || Ranges.IsEmpty())return false;auto* J=FindJob(Id);if(!J)return false;J->bRecovering=true;J->RecoveryRanges=Ranges;J->State=ECameraLightingJobState::Waiting;J->Error.Reset();SaveQueue();return PrepareAndRender({Id});}
FString UCameraLightingRenderService::NewAttempt(const FString& Id){if(IsRendering())return {};auto* Old=FindJob(Id);if(!Old)return {};auto New=*Old;auto* Source=LoadObject<ULevelSequence>(nullptr,*Old->SequencePath);auto* Settings=LoadObject<UMoviePipelinePrimaryConfig>(nullptr,*Old->RenderConfigPath);if(!Source || !Settings)return {};New.Id=FGuid::NewGuid().ToString(EGuidFormats::Digits);auto* P=CreatePackage(*(TEXT("/Game/CameraLightingRenders/Retry_")+New.Id));auto* Seq=DuplicateObject<ULevelSequence>(Source,P,*(FString(TEXT("Retry_"))+New.Id));Seq->SetFlags(RF_Public|RF_Standalone);auto* Config=DuplicateObject<UMoviePipelinePrimaryConfig>(Settings,P,TEXT("RenderSettings"));Config->SetFlags(RF_Public|RF_Standalone);auto* M=Seq->GetMovieScene();for(int32 I=0;I<M->GetSpawnableCount();++I)if(auto* A=Cast<AActor>(M->GetSpawnable(I).GetObjectTemplate()))if(auto* C=A->FindComponentByClass<UCameraLightingComponent>())if(auto* L=C->GetResolvedProfile())C->Profile=DuplicateObject<UCameraLightingProfile>(L,P,*FString::Printf(TEXT("RetryLighting_%d"),I));New.SequencePath=FSoftObjectPath(Seq).ToString();New.RenderConfigPath=FSoftObjectPath(Config).ToString();New.State=ECameraLightingJobState::Waiting;New.bRecovering=false;New.RecoveryRanges.Reset();New.OutputFiles.Reset();New.VideoFiles.Reset();New.Error.Reset();New.CompletedFrames=0;New.CreatedAt=FDateTime::UtcNow().ToIso8601();New.CompletedAt.Reset();FAssetRegistryModule::AssetCreated(Seq);if(!CameraLightingTemplates::Save(Seq))return {};Jobs.Add(New);SaveQueue();OnChanged.Broadcast();return New.Id;}
