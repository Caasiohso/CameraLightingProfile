#include "CameraLightingViewportPanel.h"
#include "CameraLightingRenderWidgets.h"
#include "Widgets/Input/SEditableTextBox.h"
#include "CameraLightingViewportTools.h"
#include "CameraLightingStyle.h"
#include "Widgets/Text/SInlineEditableTextBlock.h"
#include "CameraLightingMinimalWidgets.h"
#include "CameraLightingCameraTools.h"
#include "Framework/MultiBox/MultiBoxBuilder.h"
#include "Widgets/Input/SComboButton.h"
#include "CameraLightingCapture.h"
#include "CameraLightingComponent.h"
#include "CameraLightingProfile.h"
#include "CameraLightingRenderService.h"
#include "CameraLightingEditorSubsystem.h"
#include "CameraLightingEditorModule.h"
#include "Camera/CameraComponent.h"
#include "Engine/Texture2D.h"
#include "TextureCompiler.h"
#include "TextureResource.h"
#include "RenderingThread.h"
#include "Widgets/SLeafWidget.h"
#include "Rendering/DrawElements.h"
#include "EngineUtils.h"
#include "Editor.h"
#include "LevelEditorViewport.h"
#include "ScopedTransaction.h"
#include "UObject/StrongObjectPtr.h"
#include "Widgets/Input/SButton.h"
#include "Widgets/Input/SEditableTextBox.h"
#include "Widgets/Layout/SBorder.h"
#include "Widgets/Layout/SBox.h"
#include "Widgets/SOverlay.h"
#include "Widgets/Layout/SScaleBox.h"
#include "Widgets/Layout/SScrollBox.h"
#include "Widgets/Images/SImage.h"
#include "Widgets/Text/STextBlock.h"
#include "Styling/AppStyle.h"

namespace
{
 FLinearColor SceneBackground() { return FLinearColor::FromSRGBColor(FColor(26,29,37)); }
 FLinearColor SceneButton() { return FLinearColor::FromSRGBColor(FColor(43,46,55)); }
 FLinearColor SceneBlue() { return FLinearColor::FromSRGBColor(FColor(0,120,255)); }
 UCameraLightingRenderService* SceneService() { return GEditor ? GEditor->GetEditorSubsystem<UCameraLightingRenderService>() : nullptr; }
 TSharedRef<STextBlock> SceneText(const FString& Text,int32 Size=10)
 {
  return SNew(STextBlock).Text(FText::FromString(Text)).Font(CameraLightingStyle::Font(Size)).ColorAndOpacity(FLinearColor(.86f,.88f,.92f));
 }
}

void SCameraLightingViewportPanel::Construct(const FArguments& Args)
{
 if(auto* S=SceneService())S->OnChanged.AddSP(this,&SCameraLightingViewportPanel::InvalidateList);
 auto Create=[this]{if(AActor* A=FCameraLightingCapture::CreateSceneFromView()){Pilot(A);CaptureStatus=TEXT("Scene created. Save the level to keep it.");}else CaptureStatus=FCameraLightingCapture::GetLastError();bNeedsRefresh=true;return FReply::Handled();};
 ChildSlot[SNew(SBorder).BorderImage(FAppStyle::GetBrush("WhiteBrush")).BorderBackgroundColor(SceneBackground()).Padding(0)
 [SNew(SOverlay)
 +SOverlay::Slot()[MakeCameraLightingCornerArt(TAttribute<float>::CreateLambda([this]{return float(SceneCount*80+145);}))]
 +SOverlay::Slot().Padding(10)[SNew(SBox).MinDesiredWidth(340)[SNew(SVerticalBox)
 +SVerticalBox::Slot().AutoHeight().Padding(2,6,2,14)[SNew(SHorizontalBox)
  +SHorizontalBox::Slot().FillWidth(1)[SceneText(TEXT("Scene List"),10)]
  +SHorizontalBox::Slot().AutoWidth()[SNew(SButton).ButtonStyle(FAppStyle::Get(),"NoBorder").ToolTipText(FText::FromString(TEXT("Image rendering"))).OnClicked_Lambda([]{FCameraLightingEditorModule::OpenTab(FCameraLightingEditorModule::ImageTabId);return FReply::Handled();})[MakeCameraLightingGlyph(TEXT("Settings"),20)]]]
 +SVerticalBox::Slot().AutoHeight().Padding(0,0,0,8)[SNew(SBox).Visibility_Lambda([this]{return SceneCount>0?EVisibility::Visible:EVisibility::Collapsed;})
  [SNew(SButton).ButtonStyle(&CameraLightingStyle::Button()).ButtonColorAndOpacity(SceneButton()).HAlign(HAlign_Center).ContentPadding(8).OnClicked_Lambda(Create)[SceneText(TEXT("+  Create New Scene"),9)]]]
 +SVerticalBox::Slot().FillHeight(1)[SNew(SBox).MaxDesiredHeight_Lambda([this]{return FMath::Max(100.f,CachedPanelHeight-380.f);})[SNew(SScrollBox)+SScrollBox::Slot()[SAssignNew(CameraListBox,SVerticalBox)]]]
 +SVerticalBox::Slot().AutoHeight().Padding(2,6)[SNew(STextBlock).Text_Lambda([this]{return FText::FromString(CaptureStatus);}).AutoWrapText(true).Font(CameraLightingStyle::Font(8)).ColorAndOpacity(FLinearColor(.45f,.5f,.58f))]
 +SVerticalBox::Slot().AutoHeight().Padding(0,6)[MakeCameraLightingRenderSettings(false)]
 +SVerticalBox::Slot().AutoHeight()[SNew(SHorizontalBox)
  +SHorizontalBox::Slot().FillWidth(1)[SNew(SButton).ButtonStyle(&CameraLightingStyle::Button()).ButtonColorAndOpacity(SceneBlue()).HAlign(HAlign_Center).ContentPadding(8).OnClicked_Lambda([]{if(auto* S=SceneService())S->RenderCamera(S->ResolveCamera(true));return FReply::Handled();})[SceneText(TEXT("Render"),9)]]
  +SHorizontalBox::Slot().AutoWidth().Padding(6,0)[SNew(SButton).ButtonStyle(&CameraLightingStyle::Button()).ButtonColorAndOpacity(SceneButton()).ContentPadding(8).ToolTipText(FText::FromString(TEXT("Render queue and history"))).OnClicked_Lambda([]{FCameraLightingEditorModule::OpenTab(FCameraLightingEditorModule::QueueTabId);return FReply::Handled();})[MakeCameraLightingGlyph(TEXT("Queue"),20)]]]
 ]]]];
 RebuildCameraList();bNeedsRefresh=false;
}

SCameraLightingViewportPanel::~SCameraLightingViewportPanel()
{
 if(auto* Service=SceneService()) Service->OnChanged.RemoveAll(this);
}
void SCameraLightingViewportPanel::InvalidateList() { bNeedsRefresh=true; }
void SCameraLightingViewportPanel::Tick(const FGeometry& Geometry,const double Time,const float DeltaTime)
{
 SCompoundWidget::Tick(Geometry,Time,DeltaTime);
 CachedPanelHeight=Geometry.GetLocalSize().Y;
 if(Time-LastRefresh>0.75) {
  LastRefresh=Time;
  FString Current;
  if(GEditor) if(UWorld* World=GEditor->GetEditorWorldContext().World()) for(TActorIterator<AActor> It(World);It;++It)
   if(IsValid(*It) && !It->HasAnyFlags(RF_Transient) && It->FindComponentByClass<UCameraComponent>()) Current+=It->GetPathName()+It->GetActorLabel();
  if(Current!=Fingerprint) {Fingerprint=Current;bNeedsRefresh=true;}
 }
 if(bNeedsRefresh) { bNeedsRefresh=false;RebuildCameraList(); }
}
void SCameraLightingViewportPanel::RebuildCameraList()
{
 if(!CameraListBox.IsValid()) return;
 CameraListBox->ClearChildren();
 TArray<AActor*> Cameras;
 if(GEditor) if(UWorld* World=GEditor->GetEditorWorldContext().World())
  for(TActorIterator<AActor> It(World);It;++It) if(IsValid(*It) && !It->HasAnyFlags(RF_Transient) && It->FindComponentByClass<UCameraComponent>()) Cameras.Add(*It);
 Cameras.Sort([](const AActor& A,const AActor& B){return A.GetActorLabel()<B.GetActorLabel();});
 SceneCount=Cameras.Num();
 if(Cameras.IsEmpty()) {
  CameraListBox->AddSlot().AutoHeight().Padding(4,36,4,6)[SNew(SBox).HAlign(HAlign_Center)[MakeCameraLightingEmptyIllustration()]];
  CameraListBox->AddSlot().AutoHeight().Padding(4,0)[SNew(SButton).ButtonStyle(&CameraLightingStyle::Button()).ButtonColorAndOpacity(SceneButton()).HAlign(HAlign_Center).ContentPadding(8)
  .OnClicked_Lambda([this]{if(AActor* A=FCameraLightingCapture::CreateSceneFromView()){Pilot(A);CaptureStatus=TEXT("Scene created. Save the level to keep it.");}else CaptureStatus=FCameraLightingCapture::GetLastError();bNeedsRefresh=true;return FReply::Handled();})[SceneText(TEXT("+  Create New Scene"),9)]];
 }

 for(AActor* Camera:Cameras) CameraListBox->AddSlot().AutoHeight().Padding(0,0,0,4)[MakeCameraCard(Camera)];
}
namespace
{
class SCameraLightingThumbnail : public SLeafWidget
{
public:
 SLATE_BEGIN_ARGS(SCameraLightingThumbnail) {} SLATE_ARGUMENT(UTexture2D*,Texture) SLATE_END_ARGS()
 void Construct(const FArguments& Args)
 {
  UTexture2D* Saved=Args._Texture;
  const int32 Width=Saved->Source.GetSizeX(),Height=Saved->Source.GetSizeY();
  TArray64<uint8> SourcePixels;
  // Embedded source data is authoritative. Build a small display resource explicitly;
  // nested editor textures are not guaranteed to have cached platform mips on reload.
  if(Width>0 && Height>0 && Saved->Source.GetFormat()==TSF_BGRA8 && Saved->Source.GetMipData(SourcePixels,0) && SourcePixels.Num()==int64(Width)*Height*4)
  {
   for(int64 Pixel=3;Pixel<SourcePixels.Num();Pixel+=4) SourcePixels[Pixel]=255;
   Texture.Reset(UTexture2D::CreateTransient(Width,Height,PF_B8G8R8A8));Texture->SRGB=true;Texture->NeverStream=true;
   void* Data=Texture->GetPlatformData()->Mips[0].BulkData.Lock(LOCK_READ_WRITE);
   FMemory::Memcpy(Data,SourcePixels.GetData(),SourcePixels.Num());
   Texture->GetPlatformData()->Mips[0].BulkData.Unlock();Texture->UpdateResource();
  }
  else {Texture.Reset(Saved);TArray<UTexture*> Pending{Saved};FTextureCompilingManager::Get().FinishCompilation(Pending);}
  FlushRenderingCommands();
  Brush.SetResourceObject(Texture.Get());Brush.ImageSize=FVector2D(FMath::Max(Width,1),FMath::Max(Height,1));
  Brush.DrawAs=ESlateBrushDrawType::Image;Brush.ImageType=ESlateBrushImageType::FullColor;
 }
 virtual FVector2D ComputeDesiredSize(float) const override {return FVector2D(112,64);}
 virtual int32 OnPaint(const FPaintArgs& Args,const FGeometry& Geometry,const FSlateRect& Clip,FSlateWindowElementList& Elements,int32 Layer,const FWidgetStyle& Style,bool bEnabled) const override
 {
  const FVector2D Area=Geometry.GetLocalSize();
  const float Scale=FMath::Min(Area.X/FMath::Max(Brush.ImageSize.X,1.f),Area.Y/FMath::Max(Brush.ImageSize.Y,1.f));
  const FVector2D Size=FVector2D(Brush.ImageSize.X,Brush.ImageSize.Y)*Scale;
  FSlateDrawElement::MakeBox(Elements,Layer+1,Geometry.ToPaintGeometry(Size,FSlateLayoutTransform((Area-Size)*.5f)),&Brush,ESlateDrawEffect::None,FLinearColor::White);
  return Layer+1;
 }
private:
 TStrongObjectPtr<UTexture2D> Texture;
 FSlateBrush Brush;
};
}
TSharedRef<SWidget> MakeCameraLightingPreview(const UCameraLightingProfile* Profile,float Width,float Height)
{
 if(Profile)if(auto* Texture=Profile->PreviewImage.LoadSynchronous())return SNew(SBox).WidthOverride(Width).HeightOverride(Height)[SNew(SCameraLightingThumbnail).Texture(Texture)];
 return SNew(SBox).WidthOverride(Width).HeightOverride(Height).HAlign(HAlign_Center).VAlign(VAlign_Center)[MakeCameraLightingGlyph(TEXT("Camera"),24)];
}
TSharedRef<SWidget> SCameraLightingViewportPanel::MakeThumbnail(const UCameraLightingProfile* Profile)
{
 if(Profile) if(UTexture2D* Texture=Profile->PreviewImage.LoadSynchronous())
  return SNew(SBox).WidthOverride(112).HeightOverride(64)[SNew(SCameraLightingThumbnail).Texture(Texture)];
 return SNew(SBox).WidthOverride(112).HeightOverride(64).HAlign(HAlign_Center).VAlign(VAlign_Center)[MakeCameraLightingGlyph(TEXT("Camera"),18)];
}
TSharedRef<SWidget> SCameraLightingViewportPanel::MakeCameraCard(AActor* Camera)
{
 const TWeakObjectPtr<AActor> Weak=Camera;
 const auto* Component=Camera->FindComponentByClass<UCameraLightingComponent>();
 const auto* Profile=Component?Component->GetResolvedProfile():nullptr;
 auto Icon=[&](FName Kind,const FString& Tip,TFunction<void()> Action){return SNew(SButton).ButtonStyle(FAppStyle::Get(),"NoBorder").ContentPadding(FMargin(5,4)).ToolTipText(FText::FromString(Tip)).OnClicked_Lambda([Action]{Action();return FReply::Handled();})[MakeCameraLightingGlyph(Kind,20)];};
 return SNew(SBorder).BorderImage(FAppStyle::GetBrush("WhiteBrush")).Padding(FMargin(4,6))
 .OnMouseButtonDown_Lambda([this,Weak](const FGeometry&,const FPointerEvent& E){if(E.GetEffectingButton()==EKeys::LeftMouseButton){if(auto* A=Weak.Get())Pilot(A);return FReply::Handled();}return FReply::Unhandled();})
 .BorderBackgroundColor_Lambda([Weak]{auto* S=SceneService();return S && S->SelectedCamera==Weak?FLinearColor::FromSRGBColor(FColor(36,56,81)):FLinearColor::FromSRGBColor(FColor(31,34,42));})
 [SNew(SHorizontalBox)
  +SHorizontalBox::Slot().AutoWidth().VAlign(VAlign_Center)[Icon(TEXT("Update"),TEXT("Update scene lighting and preview"),[this,Weak]{if(AActor* A=Weak.Get()){CaptureStatus=FCameraLightingCapture::CaptureActor(A)?TEXT("Scene updated."):FCameraLightingCapture::GetLastError();bNeedsRefresh=true;}})]
  +SHorizontalBox::Slot().AutoWidth().VAlign(VAlign_Center).Padding(3,0,6,0)[SNew(SButton).ButtonStyle(FAppStyle::Get(),"NoBorder").ContentPadding(0).OnClicked_Lambda([this,Weak]{if(AActor* A=Weak.Get())Pilot(A);return FReply::Handled();})[MakeThumbnail(Profile)]]
  +SHorizontalBox::Slot().FillWidth(1).VAlign(VAlign_Center)[SNew(STextBlock).Font(CameraLightingStyle::Font(9)).Text(FText::FromString(Camera->GetActorLabel()))]
  +SHorizontalBox::Slot().AutoWidth().VAlign(VAlign_Center)[Icon(TEXT("Exit"),TEXT("Return to perspective viewport"),[]{GEditor->GetEditorSubsystem<UCameraLightingViewportTools>()->ExitPilot();})]
  +SHorizontalBox::Slot().AutoWidth().VAlign(VAlign_Center)[Icon(TEXT("AddQueue"),TEXT("Add scene to batch queue"),[Weak]{if(auto* S=SceneService())if(auto* A=Weak.Get())S->QueueCamera(A);})]
  +SHorizontalBox::Slot().AutoWidth().VAlign(VAlign_Center)[Icon(TEXT("Render"),TEXT("Render this scene"),[Weak]{if(auto* S=SceneService())if(AActor* A=Weak.Get())S->RenderCamera(A);})]
  +SHorizontalBox::Slot().AutoWidth().VAlign(VAlign_Center)[Icon(TEXT("Camera"),TEXT("Edit camera"),[this,Weak]{if(AActor* A=Weak.Get()){Pilot(A);GEditor->GetEditorSubsystem<UCameraLightingCameraTools>()->SelectTarget(A);FCameraLightingEditorModule::OpenTab(FCameraLightingEditorModule::CameraTabId);}})]
  +SHorizontalBox::Slot().AutoWidth().VAlign(VAlign_Center)[SNew(SComboButton).ButtonStyle(FAppStyle::Get(),"NoBorder").HasDownArrow(false).ContentPadding(4).OnGetMenuContent_Lambda([Weak]{FMenuBuilder Menu(true,nullptr);Menu.AddWidget(SNew(SEditableTextBox).Style(&CameraLightingStyle::Field()).Font(CameraLightingStyle::Font(10)).Text_Lambda([Weak]{return FText::FromString(Weak.IsValid()?Weak->GetActorLabel():FString());}).OnTextCommitted_Lambda([Weak](const FText& Name,ETextCommit::Type){if(auto* A=Weak.Get())if(!Name.IsEmpty()){FScopedTransaction T(NSLOCTEXT("CameraLighting","RenameScene","Rename scene"));A->Modify();A->SetActorLabel(Name.ToString());A->MarkPackageDirty();}}),FText::FromString(TEXT("Rename scene")));Menu.AddMenuEntry(FText::FromString(TEXT("Draft render")),FText(),FSlateIcon(),FUIAction(FExecuteAction::CreateLambda([Weak]{if(auto* S=SceneService())if(auto* A=Weak.Get())S->RenderDraftCamera(A);})));Menu.AddMenuEntry(FText::FromString(TEXT("Add to render queue")),FText(),FSlateIcon(),FUIAction(FExecuteAction::CreateLambda([Weak]{if(auto* S=SceneService())if(AActor* A=Weak.Get())S->QueueCamera(A);})));Menu.AddMenuEntry(FText::FromString(TEXT("Image settings")),FText(),FSlateIcon(),FUIAction(FExecuteAction::CreateLambda([]{FCameraLightingEditorModule::OpenTab(FCameraLightingEditorModule::ImageTabId);})));return Menu.MakeWidget();}).ButtonContent()[SceneText(TEXT("..."),10)]]];
}
void SCameraLightingViewportPanel::Pilot(AActor* Camera)
{
 if(!GEditor || !IsValid(Camera))return;
 GEditor->GetEditorSubsystem<UCameraLightingViewportTools>()->PilotScene(Camera);
}
