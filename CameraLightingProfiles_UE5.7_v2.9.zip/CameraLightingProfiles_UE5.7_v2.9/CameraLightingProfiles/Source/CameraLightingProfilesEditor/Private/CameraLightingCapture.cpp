#include "CameraLightingCapture.h"
// Copyright Hermes. All Rights Reserved.
#include "CameraLightingComponent.h"
#include "CameraLightingProfile.h"
#include "CameraLightingApply.h"
#include "AssetRegistry/AssetRegistryModule.h"
#include "Camera/CameraActor.h"
#include "Camera/CameraComponent.h"
#include "Camera/CameraTypes.h"
#include "Components/SceneCaptureComponent2D.h"
#include "Components/SkyLightComponent.h"
#include "Editor.h"
#include "Editor/EditorEngine.h"
#include "Engine/Selection.h"
#include "Engine/SceneCapture2D.h"
#include "Engine/SkyLight.h"
#include "Engine/Texture2D.h"
#include "Engine/TextureRenderTarget2D.h"
#include "Engine/World.h"
#include "EngineUtils.h"
#include "Framework/Application/SlateApplication.h"
#include "Framework/Notifications/NotificationManager.h"
#include "LevelEditorViewport.h"
#include "Misc/PackageName.h"
#include "Misc/App.h"
#include "RenderingThread.h"
#include "ScopedTransaction.h"
#include "TextureCompiler.h"
#include "TextureResource.h"
#include "UObject/SavePackage.h"
#include "UObject/StrongObjectPtr.h"
#include "UObject/UnrealType.h"
#include "Widgets/Notifications/SNotificationList.h"

DEFINE_LOG_CATEGORY_STATIC(LogCamLightCapture, Log, All);

namespace
{
FString LastCaptureError;

bool FailCapture(const FString& Message)
{
    LastCaptureError = Message;
    UE_LOG(LogCamLightCapture, Error, TEXT("%s"), *Message);
    return false;
}

void NotifyCapture(const FString& Message, bool bSuccess)
{
    if (!IsRunningCommandlet() && FSlateApplication::IsInitialized())
    {
        FNotificationInfo Info(FText::FromString(Message));
        Info.ExpireDuration = bSuccess ? 4.f : 8.f;
        if (TSharedPtr<SNotificationItem> Item = FSlateNotificationManager::Get().AddNotification(Info))
            Item->SetCompletionState(bSuccess ? SNotificationItem::CS_Success : SNotificationItem::CS_Fail);
    }
}

FLevelEditorViewportClient* PerspectiveViewport()
{
    if (!GEditor) return nullptr;
    FLevelEditorViewportClient* Fallback = nullptr;
    FViewport* Active = GEditor->GetActiveViewport();
    for (FLevelEditorViewportClient* Client : GEditor->GetLevelViewportClients())
    {
        if (Client && Client->IsPerspective() && Client->Viewport)
        {
            if (Client->Viewport == Active) return Client;
            if (!Fallback) Fallback = Client;
        }
    }
    return Fallback;
}
}

const FString& FCameraLightingCapture::GetLastError() { return LastCaptureError; }

AActor* FCameraLightingCapture::FindCaptureCamera()
{
    if (!GEditor) return nullptr;
    for (FSelectionIterator It(*GEditor->GetSelectedActors()); It; ++It)
    {
        if (AActor* Actor = Cast<AActor>(*It))
            if (IsValid(Actor) && Actor->FindComponentByClass<UCameraComponent>()) return Actor;
    }
    if (FLevelEditorViewportClient* Client = PerspectiveViewport())
    {
        AActor* Actor = Client->GetActorLock().GetLockedActor();
        if (!Actor) Actor = Client->GetCinematicActorLock().GetLockedActor();
        if (IsValid(Actor) && Actor->FindComponentByClass<UCameraComponent>()) return Actor;
    }
    return nullptr;
}

void FCameraLightingCapture::CaptureCamera(AActor* CameraActor)
{
    const bool bSuccess = CaptureActor(CameraActor);
    NotifyCapture(bSuccess ? TEXT("Scene captured. Save the level to keep its camera/profile link.") : GetLastError(), bSuccess);
}

void FCameraLightingCapture::CapturePilotedCamera()
{
    if (AActor* Camera = FindCaptureCamera()) CaptureCamera(Camera);
    else CreateSceneFromView();
}

AActor* FCameraLightingCapture::CreateSceneFromView()
{
    LastCaptureError.Reset();
    if (!GEditor || GEditor->PlayWorld)
    {
        FailCapture(TEXT("Stop Play/Simulate and open an editor level before creating a scene."));
        NotifyCapture(GetLastError(), false);
        return nullptr;
    }
    UWorld* World = GEditor->GetEditorWorldContext().World();
    FLevelEditorViewportClient* Client = PerspectiveViewport();
    if (!World || !Client)
    {
        FailCapture(TEXT("Open a perspective level viewport to create a scene from its current view. A selected camera can still be captured with Update Scene."));
        NotifyCapture(GetLastError(), false);
        return nullptr;
    }
    const FScopedTransaction Transaction(NSLOCTEXT("CameraLighting", "NewScene", "Create Camera Lighting Scene"));
    FActorSpawnParameters Spawn;
    Spawn.ObjectFlags = RF_Transactional;
    ACameraActor* Camera = World->SpawnActor<ACameraActor>(Client->GetViewLocation(), Client->GetViewRotation(), Spawn);
    if (!Camera)
    {
        FailCapture(TEXT("Could not create a camera in the current level. Make the level writable and try again."));
        NotifyCapture(GetLastError(), false);
        return nullptr;
    }
    int32 SceneNumber = 1;
    FString Label;
    bool bLabelUsed;
    do
    {
        Label = FString::Printf(TEXT("Scene %02d"), SceneNumber++);
        bLabelUsed = false;
        for (TActorIterator<AActor> It(World); It; ++It)
            if (*It != Camera && It->GetActorLabel() == Label) { bLabelUsed = true; break; }
    } while (bLabelUsed);
    Camera->SetActorLabel(Label);
    UCameraComponent* NewComponent = Camera->GetCameraComponent();
    NewComponent->SetFieldOfView(FMath::Clamp(Client->ViewFOV, 5.f, 170.f));
    const FIntPoint ViewSize = Client->Viewport->GetSizeXY();
    if (ViewSize.X > 0 && ViewSize.Y > 0) NewComponent->SetAspectRatio(float(ViewSize.X) / float(ViewSize.Y));
    if (AActor* Pilot = Client->GetActorLock().GetLockedActor())
    {
        if (UCameraComponent* SourceCamera = Pilot->FindComponentByClass<UCameraComponent>())
        {
            FMinimalViewInfo View;
            SourceCamera->GetCameraView(0.f, View);
            Camera->SetActorLocationAndRotation(View.Location, View.Rotation);
            NewComponent->SetFieldOfView(View.FOV);
            NewComponent->SetAspectRatio(View.AspectRatio);
            NewComponent->PostProcessSettings = View.PostProcessSettings;
            NewComponent->PostProcessBlendWeight = View.PostProcessBlendWeight;
        }
    }
    if (!CaptureActor(Camera))
    {
        World->DestroyActor(Camera);
        NotifyCapture(GetLastError(), false);
        return nullptr;
    }
    Camera->MarkPackageDirty();
    GEditor->SelectNone(false, true);
    GEditor->SelectActor(Camera, true, true);
    UE_LOG(LogCamLightCapture, Display, TEXT("Created scene %s from current viewport."), *Label);
    NotifyCapture(Label + TEXT(" created. Save the level to keep the scene."), true);
    return Camera;
}

bool FCameraLightingCapture::CaptureActor(AActor* CameraActor)
{
    LastCaptureError.Reset();
    if (!GEditor || GEditor->PlayWorld) return FailCapture(TEXT("Stop Play/Simulate before capturing a scene."));
    if (!IsValid(CameraActor) || !CameraActor->FindComponentByClass<UCameraComponent>())
        return FailCapture(TEXT("Select a camera or use Create New Scene to capture the current perspective view."));
    UWorld* World = GEditor->GetEditorWorldContext().World();
    if (!World || CameraActor->GetWorld() != World)
        return FailCapture(TEXT("The camera must belong to the currently open editor level."));

    if (!FApp::CanEverRender()) return FailCapture(TEXT("Scene capture needs editor rendering. Start with -RenderOffscreen for background capture; do not use -nullrhi."));
    const FScopedTransaction Transaction(NSLOCTEXT("CameraLighting", "CaptureScene", "Capture Camera Lighting"));
    CameraActor->Modify();
    UCameraLightingComponent* Component = CameraActor->FindComponentByClass<UCameraLightingComponent>();
    if (!Component)
    {
        Component = NewObject<UCameraLightingComponent>(CameraActor, NAME_None, RF_Transactional);
        CameraActor->AddInstanceComponent(Component);
        Component->OnComponentCreated();
        Component->RegisterComponent();
    }
    Component->Modify();
    UCameraLightingProfile* Profile = const_cast<UCameraLightingProfile*>(Component->GetResolvedProfile());
    if (!Profile)
    {
        Profile = CreateAndLinkProfile(CameraActor);
        if (!Profile) return FailCapture(TEXT("Could not create a lighting profile asset."));
        Component->Profile = Profile;
    }
    TStrongObjectPtr<UCameraLightingProfile> KeepProfile(Profile);
    Profile->Modify();
    SnapshotProfile(Profile, CameraActor);
    if (!RenderThumbnail(Profile, CameraActor)) return false;
    TStrongObjectPtr<UTexture2D> KeepThumbnail(Profile->PreviewImage.LoadSynchronous());
    if (!PersistProfile(Profile)) return false;
    CameraActor->MarkPackageDirty();
    UE_LOG(LogCamLightCapture, Display, TEXT("Capture succeeded: %s -> %s"), *CameraActor->GetActorLabel(), *Profile->GetPathName());
    return true;
}

UCameraLightingProfile* FCameraLightingCapture::CreateAndLinkProfile(AActor* CameraActor)
{
    const FString AssetName = TEXT("CameraLightingProfile_") + FGuid::NewGuid().ToString(EGuidFormats::Digits);
    UPackage* Package = CreatePackage(*(TEXT("/Game/CameraLightingProfiles/") + AssetName));
    UCameraLightingProfile* Profile = NewObject<UCameraLightingProfile>(Package, *AssetName, RF_Public | RF_Standalone | RF_Transactional);
    if (Profile)
    {
        Profile->UltraDynamicSky.bOverride = false;
        FAssetRegistryModule::AssetCreated(Profile);
    }
    return Profile;
}

void FCameraLightingCapture::SnapshotProfile(UCameraLightingProfile* Profile, AActor* CameraActor)
{
	if (!Profile || !CameraActor)
	{
		return;
	}

	UWorld* World = CameraActor->GetWorld();
	if (!World)
	{
		return;
	}

	Profile->bOverrideHDRI = false;
	Profile->SkyLightActorTag = NAME_None;
	// Snapshot HDRI: take the first SkyLight's cubemap + intensity + tag.
	TArray<ASkyLight*> SkyLights;
	for (TActorIterator<ASkyLight> It(World); It; ++It)
	{
		if (ASkyLight* SL = *It)
		{
			SkyLights.Add(SL);
		}
	}
	if (SkyLights.Num() > 0)
	{
		ASkyLight* SL = SkyLights[0];
		if (USkyLightComponent* Comp = SL->GetLightComponent())
		{
			Profile->bOverrideHDRI = true;
			Profile->HDRI = Comp->Cubemap;
			Profile->HDRIIntensity = Comp->Intensity;
			// If the SkyLight has our capture tag, record it so apply targets the same one.
			if (SL->ActorHasTag(TEXT("CameraLightingSkyLight")))
			{
				Profile->SkyLightActorTag = TEXT("CameraLightingSkyLight");
			}
		}
		UE_LOG(LogCamLightCapture, Display, TEXT("Snapshot HDRI from SkyLight %s (intensity %f)."),
			*SL->GetName(), Profile->HDRIIntensity);
	}

	// Only enable UDS overrides when the live fields can all be read.
	Profile->UltraDynamicSky.bOverride = false;
	if (AActor* UDS = CameraLightingApply::FindUltraDynamicSkyActor(World))
	{
		auto Read = [UDS](const TCHAR* Name, float& Value) {
			if (FNumericProperty* P = FindFProperty<FNumericProperty>(UDS->GetClass(), Name))
				if (P->IsFloatingPoint()) { Value = P->GetFloatingPointPropertyValue(P->ContainerPtrToValuePtr<void>(UDS)); return true; }
			return false;
		};
		FUDSOverride& O = Profile->UltraDynamicSky;
		const bool TimeRead = Read(TEXT("Daytime"), O.DaytimeHours) || Read(TEXT("Time"), O.DaytimeHours) || Read(TEXT("TimeOfDay"), O.DaytimeHours);
		O.bOverride = Read(TEXT("SunIntensity"), O.SunIntensity) && Read(TEXT("MoonIntensity"), O.MoonIntensity)
			&& Read(TEXT("SkyLightIntensity"), O.SkyLightIntensity) && Read(TEXT("SunElevation"), O.SunElevation)
			&& Read(TEXT("SunAzimuth"), O.SunAzimuth) && TimeRead;
	}

	// Snapshot post-process from the camera component (the grade the view is currently showing).
	if (UCameraComponent* CamComp = CameraActor->FindComponentByClass<UCameraComponent>())
	{
		Profile->bOverridePostProcess = true;
		Profile->PostProcessSettings = CamComp->PostProcessSettings;
		UE_LOG(LogCamLightCapture, Display, TEXT("Snapshoted post-process from %s."),
			*CameraActor->GetActorLabel());
	}
}


bool FCameraLightingCapture::RenderThumbnail(UCameraLightingProfile* Profile, AActor* CameraActor)
{
    UCameraComponent* Camera = CameraActor->FindComponentByClass<UCameraComponent>();
    UWorld* World = CameraActor->GetWorld();
    const FIntPoint Size(320, FMath::Clamp(FMath::RoundToInt(320.f / FMath::Max(0.1f, Camera->AspectRatio)), 64, 640));
    TStrongObjectPtr<UTextureRenderTarget2D> Target(NewObject<UTextureRenderTarget2D>(GetTransientPackage()));
    Target->RenderTargetFormat = RTF_RGBA8;
    Target->ClearColor = FLinearColor::Black;
    Target->TargetGamma = 2.2f;
    Target->InitAutoFormat(Size.X, Size.Y);
    Target->UpdateResourceImmediate(true);

    FActorSpawnParameters Spawn;
    Spawn.ObjectFlags = RF_Transient;
    ASceneCapture2D* CaptureActor = World->SpawnActor<ASceneCapture2D>(Spawn);
    if (!CaptureActor) return FailCapture(TEXT("Could not create the temporary thumbnail renderer."));
    USceneCaptureComponent2D* Capture = CaptureActor->GetCaptureComponent2D();
    FMinimalViewInfo View;
    Camera->GetCameraView(0.f, View);
    Capture->SetWorldLocationAndRotation(View.Location, View.Rotation);
    Capture->FOVAngle = View.FOV;
    Capture->ProjectionType = View.ProjectionMode;
    Capture->OrthoWidth = View.OrthoWidth;
    // Preserve the saved camera aspect ratio; letterboxing is supplied by projection.
    Capture->bUseCustomProjectionMatrix = true;
    Capture->CustomProjectionMatrix = View.CalculateProjectionMatrix();
    Capture->TextureTarget = Target.Get();
    Capture->CaptureSource = ESceneCaptureSource::SCS_FinalColorLDR;
    Capture->PostProcessSettings = View.PostProcessSettings;
    Capture->PostProcessBlendWeight = View.PostProcessBlendWeight;
    Capture->bCaptureEveryFrame = false;
    Capture->bCaptureOnMovement = false;
    Capture->bAlwaysPersistRenderingState = true;
    Capture->ShowFlags.SetSelectionOutline(false);
    for (int32 Sample = 0; Sample < 3; ++Sample)
    {
        Capture->CaptureScene();
        FlushRenderingCommands();
    }
    TArray<FColor> Pixels;
    FTextureRenderTargetResource* Resource = Target->GameThread_GetRenderTargetResource();
    FReadSurfaceDataFlags ReadFlags(RCM_UNorm);
    ReadFlags.SetLinearToGamma(false);
    const bool bRead = Resource && Resource->ReadPixels(Pixels, ReadFlags);
    Capture->TextureTarget = nullptr;
    World->DestroyActor(CaptureActor);
    if (!bRead || Pixels.Num() != Size.X * Size.Y)
        return FailCapture(TEXT("The thumbnail renderer could not read its image. Start the editor with rendering enabled (not -nullrhi), then retry."));
    // FinalColorLDR alpha is not meaningful for a scene-card preview. Keep it opaque.
    for(FColor& Pixel:Pixels) Pixel.A=255;
    UTexture2D* Thumbnail = MakeThumbnail(Profile, Size, Pixels);
    if (!Thumbnail) return FailCapture(TEXT("Could not create the persistent scene thumbnail texture."));
    Profile->StoredPreview = Thumbnail;
    Profile->PreviewImage = Thumbnail;
    return true;
}

UTexture2D* FCameraLightingCapture::MakeThumbnail(UCameraLightingProfile* Profile, FIntPoint Size, const TArray<FColor>& Pixels)
{
    if (!Profile || Pixels.Num() != Size.X * Size.Y) return nullptr;
    // Store real source data in an owned subobject so the saved asset can reload its preview.
    UTexture2D* Texture = NewObject<UTexture2D>(Profile, MakeUniqueObjectName(Profile, UTexture2D::StaticClass(), TEXT("ScenePreview")), RF_Public);
    TStrongObjectPtr<UTexture2D> KeepTexture(Texture);
    Texture->SRGB = true;
    Texture->MipGenSettings = TMGS_NoMipmaps;
    Texture->CompressionSettings = TC_EditorIcon;
    Texture->NeverStream = true;
    Texture->Source.Init(Size.X, Size.Y, 1, 1, TSF_BGRA8, reinterpret_cast<const uint8*>(Pixels.GetData()));
    Texture->PostEditChange();
    TArray<UTexture*> Textures{ Texture };
    FTextureCompilingManager::Get().FinishCompilation(Textures);
    return Texture;
}

bool FCameraLightingCapture::PersistProfile(UCameraLightingProfile* Profile)
{
    UPackage* Package = Profile ? Profile->GetOutermost() : nullptr;
    if (!Package) return FailCapture(TEXT("The captured profile has no valid asset package."));
    Package->MarkPackageDirty();
    const FString Filename = FPackageName::LongPackageNameToFilename(Package->GetName(), FPackageName::GetAssetPackageExtension());
    FSavePackageArgs Args;
    Args.TopLevelFlags = RF_Public | RF_Standalone;
    if (!UPackage::SavePackage(Package, Profile, *Filename, Args))
        return FailCapture(TEXT("Could not save the lighting profile. Check that Content/CameraLightingProfiles is writable."));
    return true;
}

bool FCameraLightingCapture::CaptureClipView(AActor* CameraActor,UCameraLightingProfile* Profile)
{
 if(!CameraActor || !Profile)return false;SnapshotProfile(Profile,CameraActor);return RenderThumbnail(Profile,CameraActor);
}
