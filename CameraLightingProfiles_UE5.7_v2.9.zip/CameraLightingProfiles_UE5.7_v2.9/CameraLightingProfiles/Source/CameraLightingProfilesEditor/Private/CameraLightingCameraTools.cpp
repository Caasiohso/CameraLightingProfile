#include "CameraLightingCameraTools.h"
#include "CameraLightingClips.h"
#include "CameraLightingRenderService.h"
#include "CameraLightingCapture.h"
#include "CameraLightingComponent.h"
#include "CameraLightingProfile.h"
#include "Editor.h"
#include "Engine/Selection.h"
#include "Engine/PostProcessVolume.h"
#include "Engine/World.h"
#include "Camera/CameraComponent.h"
#include "CineCameraComponent.h"
#include "CineCameraActor.h"
#include "ScopedTransaction.h"
UCameraComponent* UCameraLightingCameraTools::GetCamera(){if(VolumeTarget.IsValid())return nullptr;auto* S=GEditor?GEditor->GetEditorSubsystem<UCameraLightingRenderService>():nullptr;auto* A=S?S->ResolveCamera(false):nullptr;return A?A->FindComponentByClass<UCameraComponent>():nullptr;}
UCineCameraComponent* UCameraLightingCameraTools::GetCineCamera(){return Cast<UCineCameraComponent>(GetCamera());}
AActor* UCameraLightingCameraTools::GetTarget(){if(VolumeTarget.IsValid())return VolumeTarget.Get();if(auto* C=GetCamera())return C->GetOwner();return nullptr;}
FString UCameraLightingCameraTools::GetTargetName(){auto* A=GetTarget();return A?A->GetActorLabel():TEXT("Select a camera or post-process volume");}
void UCameraLightingCameraTools::SelectTarget(AActor* A){VolumeTarget=Cast<APostProcessVolume>(A);if(!VolumeTarget.IsValid() && A && A->FindComponentByClass<UCameraComponent>())GEditor->GetEditorSubsystem<UCameraLightingRenderService>()->SetSelectedCamera(A);}
void UCameraLightingCameraTools::UseSelectedTarget(){if(!GEditor)return;for(FSelectionIterator I(*GEditor->GetSelectedActors());I;++I)if(auto* A=Cast<AActor>(*I))if(A->IsA<APostProcessVolume>() || A->FindComponentByClass<UCameraComponent>()){SelectTarget(A);return;}}
FPostProcessSettings* UCameraLightingCameraTools::PostProcess(){if(auto* V=VolumeTarget.Get())return &V->Settings;if(auto* C=GetCamera())return &C->PostProcessSettings;return nullptr;}
void UCameraLightingCameraTools::Edit(TFunction<void()> Change)
{
 if(!GEditor || GEditor->PlayWorld)return;auto* S=GEditor->GetEditorSubsystem<UCameraLightingRenderService>();if(S->IsRendering())return;auto* A=GetTarget();if(!A)return;FScopedTransaction T(NSLOCTEXT("CameraLighting","CameraSettings","Edit camera settings"));A->Modify();if(auto* C=GetCamera())C->Modify();Change();A->MarkPackageDirty();if(auto* C=GetCamera()){C->PostProcessBlendWeight=1;if(auto* L=A->FindComponentByClass<UCameraLightingComponent>())if(auto* P=const_cast<UCameraLightingProfile*>(L->GetResolvedProfile())){P->Modify();P->PostProcessSettings=C->PostProcessSettings;}}GEditor->GetEditorSubsystem<UCameraLightingClipService>()->SyncCameraEdit(A);S->OnChanged.Broadcast();
}
float UCameraLightingCameraTools::GetCrop(){if(auto* C=GetCineCamera())return C->CropSettings.AspectRatio;if(auto* C=GetCamera())if(auto* D=Cast<UCameraLightingCropData>(C->GetAssetUserDataOfClass(UCameraLightingCropData::StaticClass())))return D->Ratio;return 0;}
void UCameraLightingCameraTools::SetCrop(float Ratio)
{
 Ratio=Ratio<=0?0:FMath::Clamp(Ratio,.1f,10.f);Edit([&]{if(auto* Cine=GetCineCamera()){auto S=Cine->CropSettings;S.AspectRatio=Ratio;Cine->SetCropSettings(S);Cine->bConstrainAspectRatio=true;}
 else if(auto* C=GetCamera()){auto* D=Cast<UCameraLightingCropData>(C->GetAssetUserDataOfClass(UCameraLightingCropData::StaticClass()));if(!D){D=NewObject<UCameraLightingCropData>(C,NAME_None,RF_Transactional);D->BaseAspect=C->AspectRatio;D->bBaseConstrain=C->bConstrainAspectRatio;C->AddAssetUserData(D);}D->Modify();if(D->Ratio<=0){D->BaseAspect=C->AspectRatio;D->bBaseConstrain=C->bConstrainAspectRatio;}const float OldScale=D->Ratio>0?FMath::Min(1.f,D->Ratio/FMath::Max(D->BaseAspect,.1f)):1.f;const float Tan=FMath::Tan(FMath::DegreesToRadians(C->FieldOfView*.5f))/OldScale;const float NewScale=Ratio>0?FMath::Min(1.f,Ratio/FMath::Max(D->BaseAspect,.1f)):1.f;C->SetFieldOfView(FMath::RadiansToDegrees(2*FMath::Atan(Tan*NewScale)));C->SetOrthoWidth(C->OrthoWidth/OldScale*NewScale);D->Ratio=Ratio;C->SetAspectRatio(Ratio>0?Ratio:D->BaseAspect);C->bConstrainAspectRatio=Ratio>0?true:D->bBaseConstrain;}});MatchOutputToCrop();
}
void UCameraLightingCameraTools::MatchOutputToCrop(){if(auto* C=GetCamera()){float Ratio=GetCrop();if(Ratio<=0)Ratio=C->AspectRatio;if(auto* Cine=GetCineCamera())if(GetCrop()<=0)Ratio=Cine->Filmback.SensorAspectRatio*Cine->LensSettings.SqueezeFactor;auto* S=GEditor->GetEditorSubsystem<UCameraLightingRenderService>();S->SetResolution(S->Width,FMath::RoundToInt(S->Width/FMath::Max(Ratio,.1f)));}}
float UCameraLightingCameraTools::GetValue(FName N)
{
 auto* P=PostProcess();auto* C=GetCineCamera();if(N==TEXT("Projection")){auto* Camera=GetCamera();return Camera?float(Camera->ProjectionMode):0;}if(N==TEXT("OrthoWidth")){auto* Camera=GetCamera();return Camera?Camera->OrthoWidth:512;}if(N==TEXT("ISO"))return P?P->CameraISO:100;if(N==TEXT("Shutter"))return P?P->CameraShutterSpeed:60;if(N==TEXT("Exposure"))return P?P->AutoExposureBias:0;if(N==TEXT("Aperture"))return C?C->CurrentAperture:P?P->DepthOfFieldFstop:4;if(N==TEXT("Squeeze"))return C?C->LensSettings.SqueezeFactor:1;if(N==TEXT("SensorWidth"))return C?C->Filmback.SensorWidth:36;if(N==TEXT("SensorHeight"))return C?C->Filmback.SensorHeight:20.25;if(N==TEXT("SensorAspect"))return C?C->Filmback.SensorAspectRatio:16.f/9.f;if(N==TEXT("Focus"))return C?C->FocusSettings.ManualFocusDistance:P?P->DepthOfFieldFocalDistance:0;return 0;
}
void UCameraLightingCameraTools::SetValue(FName N,float V)
{
 Edit([&]{auto* P=PostProcess();auto* C=GetCineCamera();if(N==TEXT("Projection")){if(auto* Camera=GetCamera())Camera->SetProjectionMode(V>=.5f?ECameraProjectionMode::Orthographic:ECameraProjectionMode::Perspective);}else if(N==TEXT("OrthoWidth")){if(auto* Camera=GetCamera())Camera->SetOrthoWidth(FMath::Clamp(V,1.f,1000000.f));}else if(N==TEXT("ISO") && P){P->bOverride_CameraISO=true;P->CameraISO=FMath::Clamp(V,1.f,102400.f);}else if(N==TEXT("Shutter") && P){P->bOverride_CameraShutterSpeed=true;P->CameraShutterSpeed=FMath::Clamp(V,.01f,8000.f);}else if(N==TEXT("Exposure") && P){P->bOverride_AutoExposureBias=true;P->AutoExposureBias=FMath::Clamp(V,-15.f,15.f);}else if(N==TEXT("Aperture") && P){P->bOverride_DepthOfFieldFstop=true;P->DepthOfFieldFstop=FMath::Clamp(V,.7f,64.f);if(C)C->SetCurrentAperture(V);}else if(N==TEXT("Squeeze") && C){auto S=C->LensSettings;S.SqueezeFactor=FMath::Clamp(V,1.f,2.f);C->SetLensSettings(S);}else if((N==TEXT("SensorWidth") || N==TEXT("SensorHeight")) && C){auto S=C->Filmback;const float Aspect=S.SensorAspectRatio;if(N==TEXT("SensorWidth")){S.SensorWidth=FMath::Clamp(V,.1f,100.f);if(bLockFilmbackAspect)S.SensorHeight=S.SensorWidth/FMath::Max(Aspect,.01f);}else{S.SensorHeight=FMath::Clamp(V,.1f,100.f);if(bLockFilmbackAspect)S.SensorWidth=S.SensorHeight*Aspect;}C->SetFilmback(S);}else if(N==TEXT("Focus") && P){P->bOverride_DepthOfFieldFocalDistance=true;P->DepthOfFieldFocalDistance=FMath::Max(0.f,V);if(C){auto S=C->FocusSettings;S.ManualFocusDistance=FMath::Max(0.f,V);C->SetFocusSettings(S);}}});
}
int32 UCameraLightingCameraTools::GetMetering(){auto* P=PostProcess();return P?int32(P->AutoExposureMethod):0;}
void UCameraLightingCameraTools::SetMetering(int32 M){Edit([&]{if(auto* P=PostProcess()){P->bOverride_AutoExposureMethod=true;P->AutoExposureMethod=EAutoExposureMethod(FMath::Clamp(M,0,2));}});}
bool UCameraLightingCameraTools::IsPhysicalExposure(){auto* P=PostProcess();return P && P->AutoExposureApplyPhysicalCameraExposure;}
void UCameraLightingCameraTools::SetPhysicalExposure(bool B){Edit([&]{if(auto* P=PostProcess()){P->bOverride_AutoExposureApplyPhysicalCameraExposure=true;P->AutoExposureApplyPhysicalCameraExposure=B;if(B){P->bOverride_AutoExposureMethod=true;P->AutoExposureMethod=AEM_Manual;}}});}
void UCameraLightingCameraTools::DaylightExposure(){FScopedTransaction T(NSLOCTEXT("CameraLighting","DaylightExposure","Apply daylight exposure"));SetMetering(2);SetPhysicalExposure(true);SetValue(TEXT("ISO"),100);SetValue(TEXT("Shutter"),125);SetValue(TEXT("Aperture"),8);}
void UCameraLightingCameraTools::ResetExposure(){Edit([&]{if(auto* P=PostProcess()){FPostProcessSettings D;P->AutoExposureMethod=D.AutoExposureMethod;P->AutoExposureBias=D.AutoExposureBias;P->CameraISO=D.CameraISO;P->CameraShutterSpeed=D.CameraShutterSpeed;P->DepthOfFieldFstop=D.DepthOfFieldFstop;P->AutoExposureApplyPhysicalCameraExposure=D.AutoExposureApplyPhysicalCameraExposure;P->bOverride_AutoExposureMethod=false;P->bOverride_AutoExposureBias=false;P->bOverride_CameraISO=false;P->bOverride_CameraShutterSpeed=false;P->bOverride_AutoExposureApplyPhysicalCameraExposure=false;P->bOverride_DepthOfFieldFstop=false;}});}
void UCameraLightingCameraTools::SetFilmbackPreset(const FString& N){Edit([&]{if(auto* C=GetCineCamera())C->SetFilmbackPresetByName(N);});}
int32 UCameraLightingCameraTools::GetFocusMethod(){if(auto* C=GetCineCamera())return int32(C->FocusSettings.FocusMethod);if(auto* P=PostProcess())return P->DepthOfFieldFocalDistance>0?1:3;return 0;}
void UCameraLightingCameraTools::SetFocusMethod(int32 M){Edit([&]{if(auto* C=GetCineCamera()){auto S=C->FocusSettings;S.FocusMethod=ECameraFocusMethod(FMath::Clamp(M,0,3));C->SetFocusSettings(S);}else if(auto* P=PostProcess()){P->bOverride_DepthOfFieldFocalDistance=true;P->DepthOfFieldFocalDistance=M==1?FMath::Max(P->DepthOfFieldFocalDistance,1000.f):0;}});}
void UCameraLightingCameraTools::SetFocusTarget(AActor* A){Edit([&]{if(auto* C=GetCineCamera()){auto S=C->FocusSettings;S.FocusMethod=ECameraFocusMethod::Tracking;S.TrackingFocusSettings.ActorToTrack=A;C->SetFocusSettings(S);}});}
void UCameraLightingCameraTools::FocusSelectedActor(){if(!GEditor)return;for(FSelectionIterator I(*GEditor->GetSelectedActors());I;++I)if(auto* A=Cast<AActor>(*I))if(A!=GetTarget()){if(GetCineCamera())SetFocusTarget(A);else if(auto* C=GetCamera())SetValue(TEXT("Focus"),(A->GetActorLocation()-C->GetComponentLocation()).Size());return;}}
void UCameraLightingCameraTools::SetFocusPlane(bool B){Edit([&]{if(auto* C=GetCineCamera()){auto S=C->FocusSettings;S.bDrawDebugFocusPlane=B;C->SetFocusSettings(S);}});}
bool UCameraLightingCameraTools::HasFocusPlane(){if(auto* C=GetCineCamera())return C->FocusSettings.bDrawDebugFocusPlane;return false;}
AActor* UCameraLightingCameraTools::CreateCineCameraCopy()
{
 auto* C=GetCamera();if(!C || !GEditor || GEditor->PlayWorld || GEditor->GetEditorSubsystem<UCameraLightingRenderService>()->IsRendering())return nullptr;
 FScopedTransaction Transaction(NSLOCTEXT("CameraLighting","CineCopy","Create Cine Camera copy"));auto* W=C->GetWorld();FActorSpawnParameters P;P.ObjectFlags=RF_Transactional;auto* A=W->SpawnActor<ACineCameraActor>(ACineCameraActor::StaticClass(),C->GetComponentTransform(),P);if(!A)return nullptr;A->SetActorLabel(C->GetOwner()->GetActorLabel()+TEXT(" Cine"));auto* Cine=A->GetCineCameraComponent();Cine->PostProcessSettings=C->PostProcessSettings;Cine->PostProcessBlendWeight=C->PostProcessBlendWeight;
 if(auto* Source=Cast<UCineCameraComponent>(C)){Cine->SetFilmback(Source->Filmback);Cine->SetLensSettings(Source->LensSettings);Cine->SetCropSettings(Source->CropSettings);Cine->SetCurrentFocalLength(Source->CurrentFocalLength);Cine->SetCurrentAperture(Source->CurrentAperture);Cine->SetFocusSettings(Source->FocusSettings);}
 else{float BaseAspect=C->AspectRatio;float Ratio=0;if(auto* D=Cast<UCameraLightingCropData>(C->GetAssetUserDataOfClass(UCameraLightingCropData::StaticClass()))){BaseAspect=D->BaseAspect;Ratio=D->Ratio;}auto Film=Cine->Filmback;Film.SensorWidth=36;Film.SensorHeight=36/FMath::Max(BaseAspect,.1f);Cine->SetFilmback(Film);auto Crop=Cine->CropSettings;Crop.AspectRatio=Ratio;Cine->SetCropSettings(Crop);Cine->SetFieldOfView(C->FieldOfView);Cine->SetCurrentAperture(C->PostProcessSettings.DepthOfFieldFstop);auto F=Cine->FocusSettings;F.FocusMethod=C->PostProcessSettings.DepthOfFieldFocalDistance>0?ECameraFocusMethod::Manual:ECameraFocusMethod::Disable;F.ManualFocusDistance=C->PostProcessSettings.DepthOfFieldFocalDistance;Cine->SetFocusSettings(F);}
 FCameraLightingCapture::CaptureActor(A);SelectTarget(A);return A;
}

void UCameraLightingCameraTools::Initialize(FSubsystemCollectionBase& Collection){Super::Initialize(Collection);LoadConfig();}
