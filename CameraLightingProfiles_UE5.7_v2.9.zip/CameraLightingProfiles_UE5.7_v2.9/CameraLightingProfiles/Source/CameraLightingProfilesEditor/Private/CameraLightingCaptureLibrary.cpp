#include "CameraLightingCaptureLibrary.h"
#include "CameraLightingCapture.h"
AActor* UCameraLightingCaptureLibrary::CreateSceneFromView() { return FCameraLightingCapture::CreateSceneFromView(); }
bool UCameraLightingCaptureLibrary::CaptureActor(AActor* Actor) { return FCameraLightingCapture::CaptureActor(Actor); }
FString UCameraLightingCaptureLibrary::GetLastError() { return FCameraLightingCapture::GetLastError(); }
