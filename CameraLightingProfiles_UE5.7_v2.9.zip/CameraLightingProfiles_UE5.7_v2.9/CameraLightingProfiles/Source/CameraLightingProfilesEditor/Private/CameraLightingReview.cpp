#include "CameraLightingReview.h"
#include "ImageUtils.h"
#include "ImageCore.h"
#include "Engine/Texture2D.h"
bool UCameraLightingReview::LoadImage(bool SlotA,const FString& Path)
{
 FImage Source,Linear;if(!FImageUtils::LoadImage(*Path,Source)){Status=TEXT("Could not decode image. Choose PNG, JPEG, or EXR.");return false;}const int32 I=SlotA?0:1;const float Scale=FMath::Min(1.f,2048.f/FMath::Max(Source.SizeX,Source.SizeY));Source.ResizeTo(Linear,FMath::Max(1,FMath::RoundToInt(Source.SizeX*Scale)),FMath::Max(1,FMath::RoundToInt(Source.SizeY*Scale)),ERawImageFormat::RGBA32F,EGammaSpace::Linear);Pixels[I].Reset();Pixels[I].Append(Linear.AsRGBA32F().GetData(),Linear.AsRGBA32F().Num());Widths[I]=Linear.SizeX;Heights[I]=Linear.SizeY;HDR[I]=FPaths::GetExtension(Path).Equals(TEXT("exr"),ESearchCase::IgnoreCase);if(SlotA)PathA=Path;else PathB=Path;Rebuild(I);Status=TEXT("Drag divider · display exposure does not modify your files. EXR preview uses Reinhard tone mapping.");return true;
}
void UCameraLightingReview::SetExposure(float V){Exposure=FMath::Clamp(V,-10.f,10.f);for(int32 I=0;I<2;++I)if(!Pixels[I].IsEmpty())Rebuild(I);}
void UCameraLightingReview::Rebuild(int32 I)
{
 auto* T=UTexture2D::CreateTransient(Widths[I],Heights[I],PF_B8G8R8A8);if(!T)return;auto& M=T->GetPlatformData()->Mips[0];auto* Dest=static_cast<FColor*>(M.BulkData.Lock(LOCK_READ_WRITE));const float Gain=FMath::Pow(2.f,Exposure);for(int32 P=0;P<Pixels[I].Num();++P){FLinearColor C=Pixels[I][P]*Gain;if(HDR[I]){C.R=FMath::Max(0.f,C.R)/(1+FMath::Max(0.f,C.R));C.G=FMath::Max(0.f,C.G)/(1+FMath::Max(0.f,C.G));C.B=FMath::Max(0.f,C.B)/(1+FMath::Max(0.f,C.B));}C.A=1;Dest[P]=C.ToFColorSRGB();}M.BulkData.Unlock();T->SRGB=true;T->UpdateResource();if(I==0)ImageA=T;else ImageB=T;
}
