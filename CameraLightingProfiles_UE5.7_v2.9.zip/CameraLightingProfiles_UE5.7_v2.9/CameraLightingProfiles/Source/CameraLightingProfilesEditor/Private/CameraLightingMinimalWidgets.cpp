#include "CameraLightingMinimalWidgets.h"
#include "Misc/ConfigCacheIni.h"
#include "ImageUtils.h"
#include "Widgets/SOverlay.h"
#include "Engine/Texture2D.h"
#include "UObject/StrongObjectPtr.h"
#include "CameraLightingRenderService.h"
#include "CameraLightingEditorModule.h"
#include "CameraLightingComponent.h"
#include "CameraLightingProfile.h"
#include "CameraLightingStyle.h"
#include "Brushes/SlateDynamicImageBrush.h"
#include "Interfaces/IPluginManager.h"
#include "Misc/Paths.h"
#include "Editor.h"
#include "Camera/CameraComponent.h"
#include "CineCameraComponent.h"
#include "Engine/World.h"
#include "ScopedTransaction.h"
#include "Widgets/SLeafWidget.h"
#include "Widgets/SCompoundWidget.h"
#include "Widgets/Layout/SBox.h"
#include "Widgets/Layout/SBorder.h"
#include "Widgets/Layout/SScrollBox.h"
#include "Widgets/Input/SButton.h"
#include "Widgets/Input/SComboButton.h"
#include "Widgets/Input/SNumericEntryBox.h"
#include "Widgets/Input/SCheckBox.h"
#include "Widgets/Text/STextBlock.h"
#include "Rendering/DrawElements.h"
#include "Brushes/SlateNoResource.h"
#include "Framework/MultiBox/MultiBoxBuilder.h"
namespace
{
bool bPearArtwork=false;
#include "CameraLightingCoolicons.inl"
bool bCameraLightingNumericDrag=false;
const FSpinBoxStyle& MinimalSpinStyle()
{
 static const FSpinBoxStyle Style=[] {
  FSpinBoxStyle Value=FAppStyle::Get().GetWidgetStyle<FSpinBoxStyle>("NumericEntrySpinBox");
  Value.SetBackgroundBrush(FSlateColorBrush(FLinearColor::FromSRGBColor(FColor(37,39,46))));
  Value.SetHoveredBackgroundBrush(FSlateColorBrush(FLinearColor::FromSRGBColor(FColor(46,50,60))));
  Value.SetActiveBackgroundBrush(FSlateColorBrush(FLinearColor::FromSRGBColor(FColor(36,56,81))));
  Value.SetInactiveFillBrush(FSlateNoResource());Value.SetHoveredFillBrush(FSlateNoResource());Value.SetActiveFillBrush(FSlateNoResource());
  Value.SetForegroundColor(FLinearColor(.88f,.9f,.94f));Value.SetTextPadding(FMargin(7,5));return Value;
 }();return Style;
}
class SMinimalDragNumber : public SCompoundWidget
{
public:
 SLATE_BEGIN_ARGS(SMinimalDragNumber){} SLATE_ARGUMENT(FVector2D,Range) SLATE_ARGUMENT(float,Delta) SLATE_ARGUMENT(int32,Decimals) SLATE_ARGUMENT(bool,Live) SLATE_END_ARGS()
 void Construct(const FArguments& Args,TFunction<float()> InGet,TFunction<void(float)> InSet)
 {
  Get=MoveTemp(InGet);Set=MoveTemp(InSet);Min=Args._Range.X;Max=Args._Range.Y;bLive=Args._Live;
  ChildSlot[SNew(SNumericEntryBox<float>).EditableTextBoxStyle(&CameraLightingStyle::Field()).Font(CameraLightingStyle::Font(10)).SpinBoxStyle(&MinimalSpinStyle())
   .AllowSpin(true).AllowWheel(false).Delta(Args._Delta).LinearDeltaSensitivity(5).ShiftMultiplier(10).CtrlMultiplier(.1f).MinFractionalDigits(0).MaxFractionalDigits(Args._Decimals)
   // An unbounded spin range plus fixed pixel sensitivity avoids million-unit transform ranges making tiny drags jump.
   // Public values are still clamped to the parameter's legal limits on every preview/commit.
   .MinValue(TOptional<float>()).MaxValue(TOptional<float>()).MinSliderValue(TOptional<float>()).MaxSliderValue(TOptional<float>())
   .ToolTipText(FText::FromString(TEXT("Drag left/right to adjust. Shift: faster; Ctrl: finer. Click to type.")))
   .Value_Lambda([this]{return TOptional<float>(bDragging?Pending:Get());})
   .OnBeginSliderMovement_Lambda([this]{Pending=Get();bDragging=true;bCameraLightingNumericDrag=true;Transaction=MakeUnique<FScopedTransaction>(NSLOCTEXT("CameraLighting","ScrubParameter","Adjust camera/render parameter"));})
   .OnValueChanged_Lambda([this](float Value){if(bDragging){Pending=FMath::Clamp(Value,Min,Max);if(bLive)Set(Pending);}})
   .OnValueCommitted_Lambda([this](float Value,ETextCommit::Type){if(!bDragging){FScopedTransaction Edit(NSLOCTEXT("CameraLighting","TypeParameter","Edit camera/render parameter"));Set(FMath::Clamp(Value,Min,Max));}})
   .OnEndSliderMovement_Lambda([this](float Value){Set(FMath::Clamp(Value,Min,Max));bDragging=false;bCameraLightingNumericDrag=false;Transaction.Reset();if(GEditor)GEditor->GetEditorSubsystem<UCameraLightingRenderService>()->OnChanged.Broadcast();})];
 }
 virtual ~SMinimalDragNumber(){if(bDragging)bCameraLightingNumericDrag=false;Transaction.Reset();}
private:
 TFunction<float()> Get;TFunction<void(float)> Set;float Min=0,Max=1,Pending=0;bool bDragging=false,bLive=false;TUniquePtr<FScopedTransaction> Transaction;
};

UCameraLightingRenderService* MinimalService(){return GEditor?GEditor->GetEditorSubsystem<UCameraLightingRenderService>():nullptr;}
FLinearColor BG(){return FLinearColor::FromSRGBColor(FColor(26,29,37));}
TSharedRef<STextBlock> Label(const FString& Value,int32 Size=10){return SNew(STextBlock).Text(FText::FromString(Value)).Font(CameraLightingStyle::Font(Size));}
class SMinimalGlyph : public SLeafWidget
{
public:
 SLATE_BEGIN_ARGS(SMinimalGlyph){} SLATE_ARGUMENT(FName,Kind) SLATE_ARGUMENT(float,Size) SLATE_END_ARGS()
 void Construct(const FArguments& Args){Kind=Args._Kind;Size=Args._Size;}
 virtual FVector2D ComputeDesiredSize(float) const override{return Kind==TEXT("Landscape")?FVector2D(140,76):FVector2D(Size,Size);}
 virtual int32 OnPaint(const FPaintArgs&,const FGeometry& G,const FSlateRect&,FSlateWindowElementList& Out,int32 Layer,const FWidgetStyle&,bool) const override
 {
  const auto A=G.GetLocalSize();const FLinearColor Color=FLinearColor::FromSRGBColor(FColor(190,195,205));
  PaintCoolicon(Kind,[&](const TArray<FVector2D>& Points){TArray<FVector2D>P;for(auto V:Points)P.Add(V*A);FSlateDrawElement::MakeLines(Out,Layer+1,G.ToPaintGeometry(),P,ESlateDrawEffect::None,Color,true,1.65f);});
  return Layer+1;
 }
private:FName Kind;float Size=16;
};
// Responsive line art inspired by the user supplied abstract reference.
// Native Slate geometry stays sharp at every panel size; decorative only.
class SMinimalCornerArt : public SLeafWidget
{
public:
 SLATE_BEGIN_ARGS(SMinimalCornerArt){}SLATE_ATTRIBUTE(float,ReservedTop) SLATE_END_ARGS()
 void Construct(const FArguments&){SetVisibility(EVisibility::HitTestInvisible);if(auto P=IPluginManager::Get().FindPlugin(TEXT("CameraLightingProfiles"))){Texture.Reset(FImageUtils::ImportFileAsTexture2D(P->GetBaseDir()/(bPearArtwork?TEXT("Resources/PanelPear.png"):TEXT("Resources/PanelArtwork.png"))));if(Texture.IsValid()){Brush.SetResourceObject(Texture.Get());Brush.DrawAs=ESlateBrushDrawType::Image;}}}
 virtual FVector2D ComputeDesiredSize(float)const override{return FVector2D::ZeroVector;}
 virtual int32 OnPaint(const FPaintArgs&,const FGeometry& G,const FSlateRect&,FSlateWindowElementList& Out,int32 L,const FWidgetStyle&,bool)const override{if(!Texture.IsValid())return L;const auto A=G.GetLocalSize();const float W=A.Y*Texture->GetSizeX()/FMath::Max(Texture->GetSizeY(),1);const FVector2D Size(W,A.Y),Origin(0,0);Out.PushClip(FSlateClippingZone(G));FSlateDrawElement::MakeBox(Out,L+1,G.ToPaintGeometry(Size,FSlateLayoutTransform(Origin)),&Brush,ESlateDrawEffect::None,FLinearColor(1,1,1,.85f));Out.PopClip();return L+1;}
private:TStrongObjectPtr<UTexture2D> Texture;FSlateBrush Brush;
};
UCameraComponent* Camera(){auto* S=MinimalService();AActor* A=S?S->ResolveCamera(false):nullptr;return A?A->FindComponentByClass<UCameraComponent>():nullptr;}
void ChangeCamera(TFunction<void(AActor*,UCameraComponent*)> Change)
{
 auto* S=MinimalService();AActor* A=S?S->ResolveCamera(false):nullptr;auto* C=Camera();if(!A||!C)return;
 TUniquePtr<FScopedTransaction> Transaction;if(!bCameraLightingNumericDrag)Transaction=MakeUnique<FScopedTransaction>(NSLOCTEXT("CameraLighting","EditCamera","Edit scene camera"));A->Modify();C->Modify();Change(A,C);A->MarkPackageDirty();
 if(auto* Lighting=A->FindComponentByClass<UCameraLightingComponent>())if(auto* Profile=const_cast<UCameraLightingProfile*>(Lighting->GetResolvedProfile())){Profile->Modify();Profile->PostProcessSettings=C->PostProcessSettings;}
 if(!bCameraLightingNumericDrag)S->OnChanged.Broadcast();
}
TSharedRef<SWidget> Number(TFunction<float()> Get,TFunction<void(float)> Set,float Min,float Max)
{return MakeCameraLightingDragNumber(MoveTemp(Get),MoveTemp(Set),Min,Max,(Max-Min)<=30?.1f:1.f,2,true);}
TSharedRef<SWidget> Field(const FString& Name,TSharedRef<SWidget> Content)
{return SNew(SVerticalBox)+SVerticalBox::Slot().AutoHeight().Padding(0,0,0,6)[Label(Name,9)]+SVerticalBox::Slot().AutoHeight()[Content];}
}
TSharedRef<SWidget> MakeCameraLightingDragNumber(TFunction<float()> Get,TFunction<void(float)> Set,float Min,float Max,float Delta,int32 Decimals,bool bLivePreview)
{return SNew(SMinimalDragNumber,MoveTemp(Get),MoveTemp(Set)).Range(FVector2D(Min,Max)).Delta(Delta).Decimals(Decimals).Live(bLivePreview);}
TSharedRef<SWidget> MakeCameraLightingCornerArt(TAttribute<float> ReservedTop){return SNew(SMinimalCornerArt).ReservedTop(ReservedTop);}
TSharedRef<SWidget> MakeCameraLightingGlyph(FName Kind,float Size){return SNew(SMinimalGlyph).Kind(Kind).Size(Size);}
TSharedRef<SWidget> MakeCameraLightingEmptyIllustration(){return SNew(SBox).WidthOverride(140).HeightOverride(76)[MakeCameraLightingGlyph(TEXT("Landscape"),76)];}
TSharedRef<SWidget> MakeCameraLightingTemplateSelector(bool bOpen)
{
 return SNew(SComboButton).ButtonStyle(&CameraLightingStyle::Button()).ButtonColorAndOpacity(FLinearColor::FromSRGBColor(FColor(37,39,46))).ContentPadding(FMargin(10,7))
 .OnGetMenuContent_Lambda([bOpen]{FMenuBuilder Menu(true,nullptr);if(auto* S=MinimalService())for(auto* T:S->GetTemplates())Menu.AddMenuEntry(FText::FromString(T->DisplayName),FText(),FSlateIcon(),FUIAction(FExecuteAction::CreateLambda([T,bOpen]{if(auto* Current=MinimalService()){Current->SelectTemplate(T);if(bOpen)FCameraLightingEditorModule::OpenTab(FCameraLightingEditorModule::ImageTabId);}})));return Menu.MakeWidget();})
 .ButtonContent()[SNew(STextBlock).Text_Lambda([]{auto* S=MinimalService();auto* T=S?S->GetCurrentTemplate():nullptr;return FText::FromString(T?T->DisplayName:TEXT("Render template"));})];
}

void CameraLightingBeginWindowArtwork(){int32 Count=0;GConfig->GetInt(TEXT("CameraLightingProfiles.Artwork"),TEXT("WindowOpenCount"),Count,GEditorPerProjectIni);Count=Count>=1000000?1:Count+1;bPearArtwork=(Count%5)==0;GConfig->SetInt(TEXT("CameraLightingProfiles.Artwork"),TEXT("WindowOpenCount"),Count,GEditorPerProjectIni);GConfig->Flush(false,GEditorPerProjectIni);}

TSharedRef<SWidget> MakeCameraLightingArtPanel(TSharedRef<SWidget> Content,float Padding){return SNew(SOverlay)+SOverlay::Slot()[MakeCameraLightingCornerArt()]+SOverlay::Slot().Padding(Padding)[Content];}
