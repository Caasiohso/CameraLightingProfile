#include "CameraLightingPipelineTools.h"
#include "CameraLightingRenderService.h"
#include "CameraLightingMinimalWidgets.h"
#include "CameraLightingStyle.h"
#include "Editor.h"
#include "DesktopPlatformModule.h"
#include "IDesktopPlatform.h"
#include "HAL/PlatformProcess.h"
#include "Widgets/Layout/SBorder.h"
#include "Widgets/Layout/SScrollBox.h"
#include "Widgets/Layout/SBox.h"
#include "Widgets/Layout/SWrapBox.h"
#include "Widgets/Text/STextBlock.h"
#include "Widgets/Input/SButton.h"
#include "Widgets/Input/SEditableTextBox.h"
#include "Widgets/Input/SCheckBox.h"
#include "Widgets/Input/SComboButton.h"
#include "Widgets/Notifications/SProgressBar.h"
#include "Framework/MultiBox/MultiBoxBuilder.h"
namespace{
UCameraLightingPipelineTools* T(){return GEditor->GetEditorSubsystem<UCameraLightingPipelineTools>();}
FLinearColor Dark(){return FLinearColor::FromSRGBColor(FColor(37,39,46));}
TSharedRef<SWidget> Txt(const FString& S){return SNew(STextBlock).Text(FText::FromString(S)).Font(CameraLightingStyle::Font(9));}
TSharedRef<SWidget> Action(const FString& S,TFunction<void()> F){return SNew(SButton).ButtonStyle(&CameraLightingStyle::Button()).ButtonColorAndOpacity(Dark()).ContentPadding(FMargin(10,7)).OnClicked_Lambda([F]{F();return FReply::Handled();})[Txt(S)];}
TSharedRef<SWidget> Field(const FString& Label,TFunction<FString()> Get,TFunction<void(FString)> Set,const FString& Filter,bool Directory=false){return SNew(SVerticalBox)+SVerticalBox::Slot().AutoHeight().Padding(0,0,0,5)[Txt(Label)]+SVerticalBox::Slot().AutoHeight()[SNew(SHorizontalBox)+SHorizontalBox::Slot().FillWidth(1)[SNew(SEditableTextBox).Style(&CameraLightingStyle::Field()).Text_Lambda([Get]{return FText::FromString(Get());}).OnTextCommitted_Lambda([Set](const FText& V,ETextCommit::Type){Set(V.ToString());T()->Persist();})]+SHorizontalBox::Slot().AutoWidth().Padding(6,0)[Action(TEXT("Browse"),[Get,Set,Filter,Directory]{if(auto* D=FDesktopPlatformModule::Get()){FString Result;if(Directory){if(D->OpenDirectoryDialog(nullptr,TEXT("Video destination"),Get(),Result))Set(Result);}else{TArray<FString> Files;if(D->OpenFileDialog(nullptr,TEXT("Choose file"),FPaths::GetPath(Get()),TEXT(""),Filter,0,Files) && Files.Num())Set(Files[0]);}T()->Persist();}})]];}
}
TSharedRef<SWidget> MakeCameraLightingPipelinePanel()
{
 auto Settings=SNew(SVerticalBox).IsEnabled_Lambda([]{return !T()->IsBusy();});
 Settings->AddSlot().AutoHeight().Padding(0,0,0,12)[Field(TEXT("FFmpeg executable (installed tool; not bundled)"),[]{return T()->FFmpegPath;},[](FString V){T()->FFmpegPath=V;},TEXT("Executable|*.exe"))];
 Settings->AddSlot().AutoHeight().Padding(0,0,0,12)[Field(TEXT("Audio file (optional WAV / MP3 / AAC; clear for silent video)"),[]{return T()->AudioPath;},[](FString V){T()->AudioPath=V;},TEXT("Audio|*.wav;*.mp3;*.aac;*.m4a;*.flac"))];
 Settings->AddSlot().AutoHeight().Padding(0,0,0,12)[Field(TEXT("Video destination (empty = image output folder)"),[]{return T()->VideoDirectory;},[](FString V){T()->VideoDirectory=V;},TEXT(""),true)];
 Settings->AddSlot().AutoHeight().Padding(0,0,0,12)[SNew(SWrapBox).UseAllottedSize(true).InnerSlotPadding(FVector2D(12,8))
 +SWrapBox::Slot()[SNew(SComboButton).ButtonStyle(&CameraLightingStyle::Button()).ButtonColorAndOpacity(Dark()).ContentPadding(8).OnGetMenuContent_Lambda([]{FMenuBuilder M(true,nullptr);for(auto V:{ECameraLightingVideoFormat::MP4,ECameraLightingVideoFormat::MOV})M.AddMenuEntry(FText::FromString(V==ECameraLightingVideoFormat::MP4?TEXT("MP4 Â· H.264 / AAC"):TEXT("MOV Â· ProRes HQ / PCM")),FText(),FSlateIcon(),FUIAction(FExecuteAction::CreateLambda([V]{T()->VideoFormat=V;T()->Persist();})));return M.MakeWidget();}).ButtonContent()[SNew(STextBlock).Font(CameraLightingStyle::Font(9)).Text_Lambda([]{return FText::FromString(T()->VideoFormat==ECameraLightingVideoFormat::MP4?TEXT("MP4"):TEXT("MOV Â· ProRes HQ"));})]]
 +SWrapBox::Slot().VAlign(VAlign_Center)[Txt(TEXT("Video FPS (0 = source)"))]
 +SWrapBox::Slot()[SNew(SBox).WidthOverride(70)[MakeCameraLightingDragNumber([]{return float(T()->VideoFPS);},[](float V){T()->VideoFPS=FMath::RoundToInt(V);T()->Persist();},0,120,1,0)]]
 +SWrapBox::Slot()[SNew(SCheckBox).IsChecked_Lambda([]{return T()->bLinearEXR?ECheckBoxState::Checked:ECheckBoxState::Unchecked;}).OnCheckStateChanged_Lambda([](ECheckBoxState V){T()->bLinearEXR=V==ECheckBoxState::Checked;T()->Persist();})[Txt(TEXT("Linear EXR to SDR (Reinhard)"))]]];
 Settings->AddSlot().AutoHeight().Padding(0,0,0,12)[SNew(SComboButton).ButtonStyle(&CameraLightingStyle::Button()).ButtonColorAndOpacity(FLinearColor::FromSRGBColor(FColor(0,120,255))).ContentPadding(9).OnGetMenuContent_Lambda([]{FMenuBuilder M(true,nullptr);auto* S=GEditor->GetEditorSubsystem<UCameraLightingRenderService>();for(int32 I=S->Jobs.Num()-1;I>=0;--I){auto J=S->Jobs[I];if(J.bClip && J.OutputFiles.Num()){const FString Id=J.Id;M.AddMenuEntry(FText::FromString(J.Label+TEXT(" Â· ")+J.Id.Left(8)),FText(),FSlateIcon(),FUIAction(FExecuteAction::CreateLambda([Id]{T()->ExportVideo(Id);})));}}return M.MakeWidget();}).ButtonContent()[Txt(TEXT("Export rendered clip..."))]];
 return SNew(SBorder).BorderImage(FAppStyle::GetBrush("WhiteBrush")).BorderBackgroundColor(FLinearColor::FromSRGBColor(FColor(26,29,37))).Padding(0)[MakeCameraLightingArtPanel(SNew(SScrollBox)+SScrollBox::Slot()[SNew(SVerticalBox)
 +SVerticalBox::Slot().AutoHeight().Padding(0,0,0,10)[SNew(SWrapBox).UseAllottedSize(true).InnerSlotPadding(FVector2D(8,8))+SWrapBox::Slot()[Action(TEXT("Check current camera"),[]{T()->InspectCurrentCamera();})]+SWrapBox::Slot()[Action(TEXT("Check selected queue"),[]{T()->RunPreflight();})]]
 +SVerticalBox::Slot().AutoHeight()[SNew(SBox).MaxDesiredHeight(260)[SNew(SScrollBox)+SScrollBox::Slot()[SNew(STextBlock).Text_Lambda([]{return FText::FromString(T()->LastPreflight.IsEmpty()?TEXT("Preflight reports camera, exposure/color, visibility, warm-up, storage and output checks. It never changes the look automatically."):T()->LastPreflight);}).AutoWrapText(true).Font(CameraLightingStyle::Font(9))]]]
 +SVerticalBox::Slot().AutoHeight().Padding(0,18,0,10)[Txt(TEXT("VIDEO DELIVERY"))]
 +SVerticalBox::Slot().AutoHeight()[Settings]
 +SVerticalBox::Slot().AutoHeight()[SNew(STextBlock).Text(FText::FromString(TEXT("Source frames are preserved. Optional audio is padded/trimmed to the video length. Engine/Sequencer audio is not captured automatically. EXR conversion is an SDR delivery copy; retain originals for grading."))).AutoWrapText(true).Font(CameraLightingStyle::Font(8))]
 +SVerticalBox::Slot().AutoHeight().Padding(0,14)[SNew(SProgressBar).Visibility_Lambda([]{return T()->IsBusy()?EVisibility::Visible:EVisibility::Collapsed;}).Percent_Lambda([]{return T()->GetTaskProgress();})]
 +SVerticalBox::Slot().AutoHeight()[SNew(STextBlock).Text_Lambda([]{return FText::FromString(T()->Status);}).AutoWrapText(true).Font(CameraLightingStyle::Font(9))]
 +SVerticalBox::Slot().AutoHeight().Padding(0,12)[SNew(SWrapBox).UseAllottedSize(true).InnerSlotPadding(FVector2D(8,8))+SWrapBox::Slot()[Action(TEXT("Cancel pipeline task"),[]{T()->CancelTask();})]+SWrapBox::Slot()[Action(TEXT("Open last finished video"),[]{if(!T()->LastVideo.IsEmpty())FPlatformProcess::LaunchFileInDefaultExternalApplication(*T()->LastVideo);})]]],14)];
}

TSharedRef<SWidget> MakeCameraLightingClipVideoControls(){return SNew(SHorizontalBox).IsEnabled_Lambda([]{return !T()->IsBusy() && !GEditor->GetEditorSubsystem<UCameraLightingRenderService>()->IsRendering();})
 +SHorizontalBox::Slot().AutoWidth().VAlign(VAlign_Center).Padding(0,0,6,0)[SNew(SComboButton).ButtonStyle(&CameraLightingStyle::Button()).ButtonColorAndOpacity(Dark()).ContentPadding(FMargin(8,7)).ToolTipText(FText::FromString(TEXT("Clip output: image frames, MP4 or MOV. Render starts frames and video delivery automatically."))).OnGetMenuContent_Lambda([]{FMenuBuilder M(true,nullptr);for(int32 I=0;I<3;++I)M.AddMenuEntry(FText::FromString(I==0?TEXT("Image frames"):I==1?TEXT("MP4"):TEXT("MOV (ProRes)")),FText(),FSlateIcon(),FUIAction(FExecuteAction::CreateLambda([I]{T()->bClipVideoDelivery=I!=0;T()->VideoFormat=I==2?ECameraLightingVideoFormat::MOV:ECameraLightingVideoFormat::MP4;T()->Persist();})));return M.MakeWidget();}).ButtonContent()[SNew(STextBlock).Font(CameraLightingStyle::Font(9)).Text_Lambda([]{return FText::FromString(!T()->bClipVideoDelivery?TEXT("Image frames"):T()->VideoFormat==ECameraLightingVideoFormat::MP4?TEXT("MP4"):TEXT("MOV"));})]]
 +SHorizontalBox::Slot().AutoWidth().VAlign(VAlign_Center).Padding(0,0,6,0)[SNew(SBox).WidthOverride(60).Visibility_Lambda([]{return T()->bClipVideoDelivery?EVisibility::Visible:EVisibility::Collapsed;}).ToolTipText(FText::FromString(TEXT("Video FPS: 0 follows the clip frame rate")))[MakeCameraLightingDragNumber([]{return float(T()->VideoFPS);},[](float V){T()->VideoFPS=FMath::RoundToInt(V);T()->Persist();},0,120,1,0)]]
 +SHorizontalBox::Slot().AutoWidth().VAlign(VAlign_Center).Padding(0,0,6,0)[SNew(SButton).Visibility_Lambda([]{return T()->bClipVideoDelivery?EVisibility::Visible:EVisibility::Collapsed;}).ButtonStyle(&CameraLightingStyle::Button()).ButtonColorAndOpacity(Dark()).ContentPadding(7).ToolTipText(FText::FromString(TEXT("Choose optional audio; cancel keeps the current file. Clear it in advanced video settings."))).OnClicked_Lambda([]{if(auto* D=FDesktopPlatformModule::Get()){TArray<FString> F;if(D->OpenFileDialog(nullptr,TEXT("Optional audio"),TEXT(""),TEXT(""),TEXT("Audio|*.wav;*.mp3;*.aac;*.m4a;*.flac"),0,F) && F.Num()){T()->AudioPath=F[0];T()->Persist();}}return FReply::Handled();})[Txt(TEXT("Audio"))]];}
