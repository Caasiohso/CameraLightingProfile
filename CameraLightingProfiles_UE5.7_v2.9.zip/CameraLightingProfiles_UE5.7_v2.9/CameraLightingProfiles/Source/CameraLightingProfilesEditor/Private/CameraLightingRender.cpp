#include "CameraLightingRender.h"
#include "CameraLightingRenderService.h"
#include "CameraLightingRenderWidgets.h"
#include "Editor.h"
#include "HAL/IConsoleManager.h"
namespace CameraLightingRender
{
TSharedRef<SWidget> MakePanel() {return MakeCameraLightingImagePanel();}
void Render(const TArray<AActor*>& Cameras)
{
 if(!GEditor)return;auto* Service=GEditor->GetEditorSubsystem<UCameraLightingRenderService>();
 for(AActor* Camera:Cameras) Service->QueueCamera(Camera); Service->RenderQueued();
}
static FAutoConsoleCommand RenderAll(TEXT("CameraLighting.RenderAll"),TEXT("Queue and render all loaded cameras."),FConsoleCommandDelegate::CreateLambda([]{
 if(GEditor) {auto* Service=GEditor->GetEditorSubsystem<UCameraLightingRenderService>();Service->QueueAllCameras();Service->RenderQueued();}
}));
}
