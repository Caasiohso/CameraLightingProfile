#include "CameraLightingVerificationLibrary.h"
#include "CameraLightingPipelineTools.h"
#include "CameraLightingViewportTools.h"
#include "CameraLightingReview.h"
#include "CameraLightingViewportPanel.h"
#include "CameraLightingRenderWidgets.h"
#include "CameraLightingMinimalWidgets.h"
#include "CameraLightingClips.h"
#include "CameraLightingEditorModule.h"
#include "Widgets/Layout/SExpandableArea.h"
#include "Widgets/Layout/SBorder.h"
#include "Widgets/Images/SImage.h"
#include "Widgets/Text/STextBlock.h"
#include "Styling/SlateStyleRegistry.h"
#include "Styling/ISlateStyle.h"
#include "Slate/WidgetRenderer.h"
#include "Engine/TextureRenderTarget2D.h"
#include "Engine/Texture2D.h"
#include "ImageCore.h"
#include "TextureResource.h"
#include "RenderingThread.h"
#include "ImageUtils.h"
#include "Misc/FileHelper.h"
#include "Misc/Paths.h"
#include "HAL/FileManager.h"
#include "UObject/StrongObjectPtr.h"
#include "UObject/GarbageCollection.h"
extern TSharedRef<SWidget> MakeCameraLightingZoomedRulerPreview();
extern TSharedRef<SWidget> MakeCameraLightingRibbonGroup();
bool UCameraLightingVerificationLibrary::ExportPanelPreviews(const FString& OutputDirectory,bool bExpandCamera)
{
 if(!FApp::CanEverRender())return false;
 auto Toolbar=MakeCameraLightingRibbonGroup();
 TArray<TSharedRef<SWidget>> Widgets={SNew(SCameraLightingViewportPanel),MakeCameraLightingImagePanel(),MakeCameraLightingQueuePanel(),MakeCameraLightingCameraPanel(),MakeCameraLightingClipsPanel(),MakeCameraLightingZoomedRulerPreview(),Toolbar,MakeCameraLightingComparePanel(),MakeCameraLightingCornerArt(),MakeCameraLightingCornerArt(),MakeCameraLightingGuidesOverlay(),MakeCameraLightingPipelinePanel(),MakeCameraLightingCornerArt(),MakeCameraLightingCornerArt()};
 const TArray<FVector2D> Sizes={FVector2D(600,700),FVector2D(420,560),FVector2D(920,800),FVector2D(420,bExpandCamera?2300:760),FVector2D(1180,500),FVector2D(1100,60),FVector2D(650,90),FVector2D(1000,650),FVector2D(420,700),FVector2D(1000,300),FVector2D(1000,600),FVector2D(650,1000),FVector2D(300,700),FVector2D(700,700)};
 const TArray<FString> Names={TEXT("SceneList.png"),TEXT("Image.png"),TEXT("RenderQueue.png"),TEXT("Camera.png"),TEXT("Clips.png"),TEXT("TimelineZoom.png"),TEXT("ToolbarIcons.png"),TEXT("Compare.png"),TEXT("ArtTall.png"),TEXT("ArtWide.png"),TEXT("Guides.png"),TEXT("Pipeline.png"),TEXT("ArtNarrow.png"),TEXT("ArtSquare.png")};

 if(bExpandCamera){TFunction<void(TSharedRef<SWidget>)> Expand;Expand=[&](TSharedRef<SWidget> W){if(W->GetTypeAsString()==TEXT("SExpandableArea"))StaticCastSharedRef<SExpandableArea>(W)->SetExpanded(true);if(auto* Children=W->GetChildren())for(int32 I=0;I<Children->Num();++I)Expand(Children->GetChildAt(I));};Expand(Widgets[3]);}
 // Every thumbnail must survive garbage collection while its SImage is alive.
 CollectGarbage(RF_NoFlags);
 IFileManager::Get().MakeDirectory(*OutputDirectory,true);
 bool bSuccess=true;
 for(int32 Index=0;Index<Widgets.Num();++Index)
 {
  FWidgetRenderer Renderer(false,true);
  TStrongObjectPtr<UTextureRenderTarget2D> Target(NewObject<UTextureRenderTarget2D>());
  Target->TargetGamma=1.f;
  Target->InitCustomFormat(FMath::RoundToInt(Sizes[Index].X),FMath::RoundToInt(Sizes[Index].Y),PF_FloatRGBA,true);
  Target->UpdateResourceImmediate(true);
  Renderer.DrawWidget(Target.Get(),Widgets[Index],Sizes[Index],0.016f);
  Renderer.DrawWidget(Target.Get(),Widgets[Index],Sizes[Index],0.016f);
  FlushRenderingCommands();
  TArray<FLinearColor> LinearPixels;
  FReadSurfaceDataFlags ReadFlags(RCM_MinMax);ReadFlags.SetLinearToGamma(false);
  if(!Target->GameThread_GetRenderTargetResource()->ReadLinearColorPixels(LinearPixels,ReadFlags)){bSuccess=false;continue;}
  TArray<FColor> Pixels;Pixels.Reserve(LinearPixels.Num());
  for(const FLinearColor& Color:LinearPixels) {FColor Pixel=Color.ToFColorSRGB();Pixel.A=255;Pixels.Add(Pixel);}
  TArray64<uint8> Encoded;
  FImageUtils::PNGCompressImageArray(FMath::RoundToInt(Sizes[Index].X),FMath::RoundToInt(Sizes[Index].Y),Pixels,Encoded);
  bSuccess=FFileHelper::SaveArrayToFile(Encoded,*(OutputDirectory/Names[Index]))&&bSuccess;
 }
 return bSuccess;
}

bool UCameraLightingVerificationLibrary::ExportPreviewTexture(UTexture2D* Texture,const FString& Filename)
{
 if(!Texture)return false;FImage Image;
 return FImageUtils::GetTexture2DSourceImage(Texture,Image) && FImageUtils::SaveImageByExtension(*Filename,Image);
}

#include "LevelSequence.h"
#include "MovieScene.h"
#include "MovieSceneBinding.h"
#include "Tracks/MovieScene3DTransformTrack.h"
#include "Sections/MovieScene3DTransformSection.h"
#include "Tracks/MovieSceneFloatTrack.h"
#include "Sections/MovieSceneFloatSection.h"
#include "Channels/MovieSceneChannelProxy.h"
FString UCameraLightingVerificationLibrary::SampleClipSequence(ULevelSequence* Sequence,float Seconds)
{
 if(!Sequence || !Sequence->GetMovieScene())return TEXT("{}");auto* M=Sequence->GetMovieScene();double V[9]={0,0,0,0,0,0,1,1,1};float Fov=90;const FFrameTime Time=FFrameTime::FromDecimal(double(Seconds)*M->GetTickResolution().AsDecimal());
 for(const auto& Binding:M->GetBindings())for(auto* Track:Binding.GetTracks())
 {
  if(auto* T=Cast<UMovieScene3DTransformTrack>(Track))for(auto* Section:T->GetAllSections())if(auto* S=Cast<UMovieScene3DTransformSection>(Section)){auto Channels=S->GetChannelProxy().GetChannels<FMovieSceneDoubleChannel>();for(int32 I=0;I<FMath::Min(Channels.Num(),9);++I)Channels[I]->Evaluate(Time,V[I]);}
  if(auto* T=Cast<UMovieSceneFloatTrack>(Track))if(T->GetPropertyName()==TEXT("FieldOfView"))for(auto* Section:T->GetAllSections())if(auto* S=Cast<UMovieSceneFloatSection>(Section))S->GetChannel().Evaluate(Time,Fov);
 }
 return FString::Printf(TEXT("{\"x\":%.6f,\"y\":%.6f,\"z\":%.6f,\"roll\":%.6f,\"pitch\":%.6f,\"yaw\":%.6f,\"fov\":%.6f}"),V[0],V[1],V[2],V[3],V[4],V[5],Fov);
}

extern FString CameraLightingVerifyTimelineWheel();
FString UCameraLightingVerificationLibrary::VerifyTimelineNavigation(){return CameraLightingVerifyTimelineWheel();}

extern FString CameraLightingVerifyShotDrag();
FString UCameraLightingVerificationLibrary::VerifyShotDragging(){return CameraLightingVerifyShotDrag();}

extern bool CameraLightingVerifyCameraDrop(AActor* Camera);
bool UCameraLightingVerificationLibrary::VerifyCameraDrop(AActor* Camera){return CameraLightingVerifyCameraDrop(Camera);}

extern bool CameraLightingVerifyPanelRecovery();
bool UCameraLightingVerificationLibrary::VerifyPanelRecovery(){return CameraLightingVerifyPanelRecovery();}
