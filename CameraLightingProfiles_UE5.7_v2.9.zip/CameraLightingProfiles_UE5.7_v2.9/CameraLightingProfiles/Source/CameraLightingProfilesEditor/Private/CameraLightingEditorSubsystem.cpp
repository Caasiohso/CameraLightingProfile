#include "CameraLightingEditorSubsystem.h"
// Copyright Hermes. All Rights Reserved.

#include "CameraLightingComponent.h"
#include "CameraLightingApply.h"
#include "CameraLightingProfile.h"

#include "Engine/World.h"
#include "EngineUtils.h"
#include "Engine/SkyLight.h"
#include "Components/SkyLightComponent.h"
#include "LevelEditorViewport.h"
#include "Editor.h"
#include "Editor/EditorEngine.h"

DEFINE_LOG_CATEGORY_STATIC(LogCamLightEditor, Log, All);

void UCameraLightingEditorSubsystem::Initialize(FSubsystemCollectionBase& Collection)
{
	Super::Initialize(Collection);
	if (GEditor)
	{
		FEditorDelegates::OnEditorCameraMoved.AddUObject(
			this, &UCameraLightingEditorSubsystem::OnCameraMoved);
	}
	TickHandle = FTSTicker::GetCoreTicker().AddTicker(
		FTickerDelegate::CreateUObject(this, &UCameraLightingEditorSubsystem::Tick));
}

void UCameraLightingEditorSubsystem::Deinitialize()
{
	if (GEditor)
	{
		FEditorDelegates::OnEditorCameraMoved.RemoveAll(this);
	}
	if (TickHandle.IsValid())
	{
		FTSTicker::GetCoreTicker().RemoveTicker(TickHandle);
	}
	Super::Deinitialize();
}

void UCameraLightingEditorSubsystem::OnCameraMoved(
	const FVector& Position, const FRotator& Rotation, ELevelViewportType ViewportType, int32 ViewIndex)
{
	// When a viewport is locked to (piloting) a camera actor, apply its profile.
	if (!GEditor)
	{
		return;
	}
	for (FLevelEditorViewportClient* VC : GEditor->GetLevelViewportClients())
	{
		if (!VC)
		{
			continue;
		}
		AActor* Locked = VC->GetActorLock().GetLockedActor();
		if (Locked)
		{
			ApplyForActor(Locked);
			return;
		}
	}
}

bool UCameraLightingEditorSubsystem::Tick(float DeltaTime)
{
	// Catch piloting that may not emit a camera-moved event on the first frame.
	if (!GEditor)
	{
		return false;
	}
	for (FLevelEditorViewportClient* VC : GEditor->GetLevelViewportClients())
	{
		if (!VC)
		{
			continue;
		}
		if (AActor* Locked = VC->GetActorLock().GetLockedActor())
		{
			ApplyForActor(Locked);
			return true;
		}
	}
	return true;
}

void UCameraLightingEditorSubsystem::ApplyForActor(AActor* CameraActor)
{
	if (!CameraActor || CurrentCameraActor.Get() == CameraActor)
	{
		return;
	}
	CurrentCameraActor = CameraActor;

	if (UCameraLightingComponent* Comp = CameraActor->FindComponentByClass<UCameraLightingComponent>())
	{
		if (!Comp->bAutoApply)
		{
			return;
		}
		const UCameraLightingProfile* Profile = Comp->GetResolvedProfile();
		if (!Profile)
		{
			return;
		}
		// Cache defaults once (first SkyLight we touch) so Restore can revert.
		if (!bCached)
		{
			if (UWorld* World = CameraActor->GetWorld())
			{
				for (TActorIterator<ASkyLight> It(World); It; ++It)
				{
					CachedSkyLight = *It;
					if (USkyLightComponent* C = (*It)->GetLightComponent())
					{
						CachedCubemap = C->Cubemap;
						CachedIntensity = C->Intensity;
						bCached = true;
					}
					break;
				}
			}
		}
		// In the editor we don't bind post-process to a camera (no active view),
		// but we still apply UDS + HDRI to the level.
		CameraLightingApply::ApplyProfile(CameraActor->GetWorld(), Profile, nullptr);
		UE_LOG(LogCamLightEditor, Display, TEXT("Editor: applied profile for piloted camera %s."),
			*CameraActor->GetName());
	}
}

void UCameraLightingEditorSubsystem::PilotCamera(AActor* CameraActor)
{
	if (CameraActor)
	{
		ApplyForActor(CameraActor);
	}
}

void UCameraLightingEditorSubsystem::ApplyToCurrent()
{
	if (GEditor)
	{
		for (FLevelEditorViewportClient* VC : GEditor->GetLevelViewportClients())
		{
			if (VC && VC->GetActorLock().GetLockedActor())
			{
				ApplyForActor(VC->GetActorLock().GetLockedActor());
				return;
			}
		}
	}
}

void UCameraLightingEditorSubsystem::RestoreDefaults()
{
	if (ASkyLight* SL = CachedSkyLight.Get())
	{
		if (USkyLightComponent* C = SL->GetLightComponent())
		{
			C->Cubemap = CachedCubemap;
			C->Intensity = CachedIntensity;
		}
		SL->MarkComponentsRenderStateDirty();
	}
	CurrentCameraActor = nullptr;
	UE_LOG(LogCamLightEditor, Display, TEXT("Editor: restored default SkyLight/HDRI."));
}
