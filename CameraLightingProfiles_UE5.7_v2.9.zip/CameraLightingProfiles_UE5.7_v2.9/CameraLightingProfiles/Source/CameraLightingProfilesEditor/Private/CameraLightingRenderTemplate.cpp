#include "CameraLightingRenderTemplate.h"
#include "CameraLightingRenderService.h"
#include "CameraLightingProfile.h"
#include "MoviePipelinePrimaryConfig.h"
#include "MoviePipelineAntiAliasingSetting.h"
#include "MoviePipelineDeferredPasses.h"
#include "MoviePipelineOutputSetting.h"
#include "Engine/Scene.h"
#include "Editor.h"
#include "Subsystems/AssetEditorSubsystem.h"
#include "AssetRegistry/AssetRegistryModule.h"
#include "Misc/PackageName.h"
#include "UObject/SavePackage.h"
#include "HAL/IConsoleManager.h"

bool CameraLightingTemplates::Save(UObject* Asset)
{
 if(!Asset)return false;UPackage* Package=Asset->GetOutermost();Package->MarkPackageDirty();
 FSavePackageArgs Args;Args.TopLevelFlags=RF_Public|RF_Standalone;
 return UPackage::SavePackage(Package,Asset,*FPackageName::LongPackageNameToFilename(Package->GetName(),FPackageName::GetAssetPackageExtension()),Args);
}
void UCameraLightingRenderTemplate::PostEditChangeProperty(FPropertyChangedEvent& Event)
{
 Super::PostEditChangeProperty(Event);
 if(auto* Preset=FullPreset.LoadSynchronous())
 {
  auto* AA=CastChecked<UMoviePipelineAntiAliasingSetting>(Preset->FindOrAddSettingByClass(UMoviePipelineAntiAliasingSetting::StaticClass()));
  const FName Name=Event.GetPropertyName();
  if(Name==GET_MEMBER_NAME_CHECKED(UCameraLightingRenderTemplate,SpatialSamples)) {Preset->Modify();AA->SpatialSampleCount=SpatialSamples;}
  if(Name==GET_MEMBER_NAME_CHECKED(UCameraLightingRenderTemplate,TemporalSamples)) {Preset->Modify();AA->TemporalSampleCount=TemporalSamples;}
  if(Name==GET_MEMBER_NAME_CHECKED(UCameraLightingRenderTemplate,EngineWarmUp)) {Preset->Modify();AA->EngineWarmUpCount=EngineWarmUp;}
  if(Name==GET_MEMBER_NAME_CHECKED(UCameraLightingRenderTemplate,RenderWarmUp)) {Preset->Modify();AA->RenderWarmUpCount=RenderWarmUp;}
 }
}
UMoviePipelinePrimaryConfig* CameraLightingTemplates::Build(UCameraLightingRenderTemplate* Template,UObject* Outer)
{
 auto* Config=NewObject<UMoviePipelinePrimaryConfig>(Outer,NAME_None,RF_Transactional);
 auto* Native=Template?Template->FullPreset.LoadSynchronous():nullptr;
 if(Native) Config->CopyFrom(Native);
 // The renderer is selected by the template. Other native MRQ settings are preserved.
 for(auto* Setting:Config->GetUserSettings()) if(Setting->IsA<UMoviePipelineDeferredPassBase>()) Config->RemoveSetting(Setting);
 if(Template && Template->Renderer==ECameraLightingRenderer::PathTracer)
 {
  auto* Pass=CastChecked<UMoviePipelineDeferredPass_PathTracer>(Config->FindOrAddSettingByClass(UMoviePipelineDeferredPass_PathTracer::StaticClass()));Pass->bReferenceMotionBlur=false;
 }
 else Config->FindOrAddSettingByClass(UMoviePipelineDeferredPassBase::StaticClass());
 if(!Native)
 {
  auto* AA=CastChecked<UMoviePipelineAntiAliasingSetting>(Config->FindOrAddSettingByClass(UMoviePipelineAntiAliasingSetting::StaticClass()));
  AA->SpatialSampleCount=Template?Template->SpatialSamples:8;AA->TemporalSampleCount=Template?Template->TemporalSamples:1;
  AA->bOverrideAntiAliasing=true;AA->AntiAliasingMethod=AAM_None;
  AA->bUseCameraCutForWarmUp=false;AA->EngineWarmUpCount=Template?Template->EngineWarmUp:32;AA->RenderWarmUpCount=Template?Template->RenderWarmUp:32;
  AA->bRenderWarmUpFrames=!(Template && Template->Renderer==ECameraLightingRenderer::PathTracer);
 }
 Config->FindOrAddSettingByClass(UMoviePipelineOutputSetting::StaticClass());return Config;
}
void CameraLightingTemplates::ApplyLook(FPostProcessSettings& PP,const UCameraLightingRenderTemplate* Template)
{
 if(!Template)return;
 if(Template->Renderer==ECameraLightingRenderer::PathTracer)
 {
  PP.bOverride_PathTracingMaxBounces=true;PP.PathTracingMaxBounces=Template->MaxBounces;
  PP.bOverride_PathTracingEnableDenoiser=true;PP.PathTracingEnableDenoiser=Template->bDenoise;
 }
 else
 {
  PP.bOverride_DynamicGlobalIlluminationMethod=true;PP.DynamicGlobalIlluminationMethod=EDynamicGlobalIlluminationMethod::Lumen;
  PP.bOverride_ReflectionMethod=true;PP.ReflectionMethod=EReflectionMethod::Lumen;
  PP.bOverride_LumenSceneLightingQuality=true;PP.LumenSceneLightingQuality=Template->SceneQuality;
  PP.bOverride_LumenFinalGatherQuality=true;PP.LumenFinalGatherQuality=Template->FinalGatherQuality;
  PP.bOverride_LumenReflectionQuality=true;PP.LumenReflectionQuality=Template->ReflectionQuality;
 }
 // Temporal samples require a nonzero shutter interval in MRQ, even for a static still.
 int32 Temporal=Template->TemporalSamples;if(auto* Native=Template->FullPreset.LoadSynchronous())if(auto* AA=Native->FindSetting<UMoviePipelineAntiAliasingSetting>())Temporal=AA->TemporalSampleCount;
 PP.bOverride_MotionBlurAmount=true;PP.MotionBlurAmount=Temporal>1?.5f:0.f;
}
TArray<UCameraLightingRenderTemplate*> UCameraLightingRenderService::GetTemplates()
{
 if(!bTemplatesInitialized)
 {
  bTemplatesInitialized=true;
  const FString WillsPath=TEXT("/Game/CameraLightingTemplates/Wills_Lumen");
  auto* Wills=FPackageName::DoesPackageExist(WillsPath)?LoadObject<UCameraLightingRenderTemplate>(nullptr,*(WillsPath+TEXT(".Wills_Lumen"))):nullptr;
  auto* Base=LoadObject<UMoviePipelinePrimaryConfig>(nullptr,TEXT("/CameraLightingProfiles/Templates/WillsRenderSettings_5_5.WillsRenderSettings_5_5"));
  if(!Wills && Base)
  {
   auto* Package=CreatePackage(*WillsPath);Wills=NewObject<UCameraLightingRenderTemplate>(Package,TEXT("Wills_Lumen"),RF_Public|RF_Standalone|RF_Transactional);
   Wills->DisplayName=TEXT("Will's — Lumen");Wills->SpatialSamples=1;Wills->TemporalSamples=15;
   const FString NativePath=TEXT("/Game/CameraLightingTemplates/Wills_Lumen_MRQ");auto* NativePackage=CreatePackage(*NativePath);
   auto* Native=DuplicateObject<UMoviePipelinePrimaryConfig>(Base,NativePackage,TEXT("Wills_Lumen_MRQ"));Native->SetFlags(RF_Public|RF_Standalone|RF_Transactional);Wills->FullPreset=Native;
   FAssetRegistryModule::AssetCreated(Native);CameraLightingTemplates::Save(Native);FAssetRegistryModule::AssetCreated(Wills);CameraLightingTemplates::Save(Wills);
   SelectedTemplate=Wills;Format=ECameraLightingImageFormat::EXR;PersistSettings();
  }
  if(Wills)TemplateCache.Add(Wills);
  for(int32 Index=0;Index<4;++Index)
  {
   const TCHAR* Names[]={TEXT("Lumen_Preview"),TEXT("Lumen_Final"),TEXT("PathTracer_Preview"),TEXT("PathTracer_Final")};
   const FString PackagePath=TEXT("/Game/CameraLightingTemplates/")+FString(Names[Index]);
   auto* Template=FPackageName::DoesPackageExist(PackagePath)?LoadObject<UCameraLightingRenderTemplate>(nullptr,*(PackagePath+TEXT(".")+Names[Index])):nullptr;
   if(!Template)
   {
    auto* Package=CreatePackage(*PackagePath);Template=NewObject<UCameraLightingRenderTemplate>(Package,Names[Index],RF_Public|RF_Standalone|RF_Transactional);
    Template->DisplayName=Index<2?(Index==0?TEXT("Lumen Preview"):TEXT("Lumen Final")):(Index==2?TEXT("Path Tracer Preview"):TEXT("Path Tracer Final"));
    if(Index<2){Template->SpatialSamples=Index==0?8:32;Template->EngineWarmUp=Index==0?32:64;Template->RenderWarmUp=Index==0?32:64;Template->SceneQuality=Index==0?1:2;Template->FinalGatherQuality=Index==0?1:4;Template->ReflectionQuality=Index==0?1:4;}
    else {Template->Renderer=ECameraLightingRenderer::PathTracer;Template->SpatialSamples=Index==2?64:256;Template->EngineWarmUp=Index==2?8:16;Template->RenderWarmUp=0;Template->MaxBounces=Index==2?8:12;}
    FAssetRegistryModule::AssetCreated(Template);CameraLightingTemplates::Save(Template);
   }
   // Build suggested variations from Will's complete native preset, never replace user-linked presets.
   if(Base && Template->FullPreset.IsNull())
   {
    auto* NativePackage=CreatePackage(*(PackagePath+TEXT("_MRQ")));
    auto* Native=DuplicateObject<UMoviePipelinePrimaryConfig>(Base,NativePackage,*(FString(Names[Index])+TEXT("_MRQ")));Native->SetFlags(RF_Public|RF_Standalone|RF_Transactional);
    auto* AA=CastChecked<UMoviePipelineAntiAliasingSetting>(Native->FindOrAddSettingByClass(UMoviePipelineAntiAliasingSetting::StaticClass()));
    AA->SpatialSampleCount=Template->SpatialSamples;AA->TemporalSampleCount=Template->TemporalSamples;AA->EngineWarmUpCount=Template->EngineWarmUp;AA->RenderWarmUpCount=Template->RenderWarmUp;AA->bRenderWarmUpFrames=Index<2;
    Template->FullPreset=Native;FAssetRegistryModule::AssetCreated(Native);CameraLightingTemplates::Save(Native);CameraLightingTemplates::Save(Template);
   }
   TemplateCache.AddUnique(Template);
  }
  FARFilter Filter;Filter.ClassPaths.Add(UCameraLightingRenderTemplate::StaticClass()->GetClassPathName());Filter.bRecursiveClasses=true;
  TArray<FAssetData> Assets;FModuleManager::LoadModuleChecked<FAssetRegistryModule>(TEXT("AssetRegistry")).Get().GetAssets(Filter,Assets);
  for(const auto& Data:Assets) if(auto* Template=Cast<UCameraLightingRenderTemplate>(Data.GetAsset()))TemplateCache.AddUnique(Template);
 }
 TArray<UCameraLightingRenderTemplate*> Result;for(const auto& Template:TemplateCache)Result.Add(Template.Get());return Result;
}
UCameraLightingRenderTemplate* UCameraLightingRenderService::GetCurrentTemplate()
{GetTemplates();if(auto* Template=SelectedTemplate.LoadSynchronous())return Template;return TemplateCache.IsEmpty()?nullptr:TemplateCache[0];}
void UCameraLightingRenderService::SelectTemplate(UCameraLightingRenderTemplate* Template)
{if(Template){SelectedTemplate=Template;PersistSettings();OnChanged.Broadcast();}}
void UCameraLightingRenderService::SaveTemplate()
{auto* Template=GetCurrentTemplate();CameraLightingTemplates::Save(Template);if(Template)CameraLightingTemplates::Save(Template->FullPreset.LoadSynchronous());OnChanged.Broadcast();}
void UCameraLightingRenderService::DuplicateTemplate()
{
 auto* Original=GetCurrentTemplate();if(!Original)return;
 const FString Name=TEXT("Custom_")+FGuid::NewGuid().ToString(EGuidFormats::Digits).Left(12);
 auto* Package=CreatePackage(*(TEXT("/Game/CameraLightingTemplates/")+Name));
 auto* Copy=DuplicateObject<UCameraLightingRenderTemplate>(Original,Package,*Name);Copy->SetFlags(RF_Public|RF_Standalone|RF_Transactional);Copy->DisplayName=Original->DisplayName+TEXT(" Copy");
 // Give copies independent native MRQ settings as well.
 if(auto* Native=Original->FullPreset.LoadSynchronous())
 {
  auto* NativePackage=CreatePackage(*(TEXT("/Game/CameraLightingTemplates/")+Name+TEXT("_MRQ")));
  auto* NativeCopy=DuplicateObject<UMoviePipelinePrimaryConfig>(Native,NativePackage,*(Name+TEXT("_MRQ")));NativeCopy->SetFlags(RF_Public|RF_Standalone);Copy->FullPreset=NativeCopy;
  FAssetRegistryModule::AssetCreated(NativeCopy);CameraLightingTemplates::Save(NativeCopy);
 }
 FAssetRegistryModule::AssetCreated(Copy);CameraLightingTemplates::Save(Copy);TemplateCache.Add(Copy);SelectTemplate(Copy);
}
void UCameraLightingRenderService::EditTemplate()
{if(auto* Template=GetCurrentTemplate())GEditor->GetEditorSubsystem<UAssetEditorSubsystem>()->OpenEditorForAsset(Template);}
void UCameraLightingRenderService::EditFullPreset()
{
 auto* Template=GetCurrentTemplate();if(!Template)return;
 auto* Config=Template->FullPreset.LoadSynchronous();
 if(!Config)
 {
  const FString Name=Template->GetName()+TEXT("_MRQ");auto* Package=CreatePackage(*(TEXT("/Game/CameraLightingTemplates/")+Name));
  Config=CameraLightingTemplates::Build(Template,Package);Config->Rename(*Name,Package);Config->SetFlags(RF_Public|RF_Standalone);
  Template->Modify();Template->FullPreset=Config;FAssetRegistryModule::AssetCreated(Config);CameraLightingTemplates::Save(Config);CameraLightingTemplates::Save(Template);
 }
 GEditor->GetEditorSubsystem<UAssetEditorSubsystem>()->OpenEditorForAsset(Config);
}
int32 UCameraLightingRenderService::GetTemplateSamples()
{
 auto* Template=GetCurrentTemplate();if(!Template)return 8;
 if(auto* Config=Template->FullPreset.LoadSynchronous())if(auto* AA=Config->FindSetting<UMoviePipelineAntiAliasingSetting>())return AA->SpatialSampleCount;
 return Template->SpatialSamples;
}
void UCameraLightingRenderService::SetTemplateSamples(int32 Samples)
{
 auto* Template=GetCurrentTemplate();if(!Template)return;Template->Modify();Template->SpatialSamples=FMath::Clamp(Samples,1,4096);
 if(auto* Config=Template->FullPreset.LoadSynchronous()) {Config->Modify();auto* AA=CastChecked<UMoviePipelineAntiAliasingSetting>(Config->FindOrAddSettingByClass(UMoviePipelineAntiAliasingSetting::StaticClass()));AA->SpatialSampleCount=Template->SpatialSamples;}
 SaveTemplate();
}
FString UCameraLightingRenderService::GetTemplateReadiness()
{
 auto* Template=GetCurrentTemplate();if(!Template)return TEXT("No template selected.");
 auto Value=[](const TCHAR* Name){auto* C=IConsoleManager::Get().FindConsoleVariable(Name);return C?C->GetInt():0;};
 if(Template->Renderer==ECameraLightingRenderer::PathTracer && (!Value(TEXT("r.RayTracing")) || !Value(TEXT("r.PathTracing"))))return TEXT("Path Tracer requires DX12, hardware ray tracing and Path Tracing enabled in Project Settings.");
 if(Template->Renderer==ECameraLightingRenderer::Lumen && !Value(TEXT("r.GenerateMeshDistanceFields")) && !(Value(TEXT("r.RayTracing")) && Value(TEXT("r.Lumen.HardwareRayTracing"))))return TEXT("Lumen needs Generate Mesh Distance Fields or hardware ray tracing enabled in Project Settings. Restart after changing these settings.");
 return FString();
}

int32 UCameraLightingRenderService::GetTemplateTemporalSamples()
{
 auto* Template=GetCurrentTemplate();if(!Template)return 1;
 if(auto* Config=Template->FullPreset.LoadSynchronous())if(auto* AA=Config->FindSetting<UMoviePipelineAntiAliasingSetting>())return AA->TemporalSampleCount;
 return Template->TemporalSamples;
}
void UCameraLightingRenderService::SetTemplateTemporalSamples(int32 Samples)
{
 auto* Template=GetCurrentTemplate();if(!Template)return;Template->Modify();Template->TemporalSamples=FMath::Clamp(Samples,1,4096);
 if(auto* Config=Template->FullPreset.LoadSynchronous()){Config->Modify();auto* AA=CastChecked<UMoviePipelineAntiAliasingSetting>(Config->FindOrAddSettingByClass(UMoviePipelineAntiAliasingSetting::StaticClass()));AA->TemporalSampleCount=Template->TemporalSamples;}
 SaveTemplate();
}

int32 UCameraLightingRenderService::GetTemplateWarmup(){auto* T=GetCurrentTemplate();if(!T)return 32;if(auto* C=T->FullPreset.LoadSynchronous())if(auto* AA=C->FindSetting<UMoviePipelineAntiAliasingSetting>())return AA->EngineWarmUpCount;return T->EngineWarmUp;}
void UCameraLightingRenderService::SetTemplateWarmup(int32 Frames){auto* T=GetCurrentTemplate();if(!T)return;T->Modify();T->EngineWarmUp=T->RenderWarmUp=FMath::Clamp(Frames,0,600);if(auto* C=T->FullPreset.LoadSynchronous()){C->Modify();auto* AA=CastChecked<UMoviePipelineAntiAliasingSetting>(C->FindOrAddSettingByClass(UMoviePipelineAntiAliasingSetting::StaticClass()));AA->EngineWarmUpCount=T->EngineWarmUp;AA->RenderWarmUpCount=T->RenderWarmUp;}SaveTemplate();}
