#include "CameraLightingReview.h"
#include "CameraLightingMinimalWidgets.h"
#include "CameraLightingStyle.h"
#include "CameraLightingRenderService.h"
#include "Editor.h"
#include "Engine/Texture2D.h"
#include "DesktopPlatformModule.h"
#include "IDesktopPlatform.h"
#include "Widgets/SLeafWidget.h"
#include "Widgets/Layout/SBorder.h"
#include "Widgets/Layout/SBox.h"
#include "Widgets/Input/SButton.h"
#include "Widgets/Input/SComboButton.h"
#include "Widgets/Text/STextBlock.h"
#include "Rendering/DrawElements.h"
#include "Framework/MultiBox/MultiBoxBuilder.h"
namespace
{
UCameraLightingReview* Review(){return GEditor->GetEditorSubsystem<UCameraLightingReview>();}
class SWipeCanvas : public SLeafWidget
{
public:
 SLATE_BEGIN_ARGS(SWipeCanvas){} SLATE_END_ARGS()
 void Construct(const FArguments&){SetCursor(EMouseCursor::ResizeLeftRight);}
 virtual FVector2D ComputeDesiredSize(float)const override{return {800,450};}
 virtual int32 OnPaint(const FPaintArgs&,const FGeometry& G,const FSlateRect&,FSlateWindowElementList& Out,int32 L,const FWidgetStyle&,bool)const override
 {
  auto* S=Review();const auto Area=G.GetLocalSize();const float Divider=Area.X*S->Split;
  for(int32 I=0;I<2;++I){auto* T=I==0?S->ImageA.Get():S->ImageB.Get();if(!T)continue;const float Scale=FMath::Min(Area.X/T->GetSizeX(),Area.Y/T->GetSizeY());const FVector2D Size(T->GetSizeX()*Scale,T->GetSizeY()*Scale);FSlateBrush Brush;Brush.SetResourceObject(T);Brush.DrawAs=ESlateBrushDrawType::Image;const auto AbsA=G.LocalToAbsolute(FVector2D(I==0?0:Divider,0)),AbsB=G.LocalToAbsolute(FVector2D(I==0?Divider:Area.X,Area.Y));Out.PushClip(FSlateClippingZone(FSlateRect(AbsA.X,AbsA.Y,AbsB.X,AbsB.Y)));FSlateDrawElement::MakeBox(Out,L+1,G.ToPaintGeometry(Size,FSlateLayoutTransform((Area-Size)*.5)),&Brush,ESlateDrawEffect::None,FLinearColor::White);Out.PopClip();}
  TArray<FVector2D> P{{Divider,0},{Divider,Area.Y}};FSlateDrawElement::MakeLines(Out,L+2,G.ToPaintGeometry(),P,ESlateDrawEffect::None,FLinearColor::White,true,2);return L+2;
 }
 void DragAt(const FGeometry& G,const FPointerEvent& E){Review()->SetSplit(G.AbsoluteToLocal(E.GetScreenSpacePosition()).X/FMath::Max(1.,G.GetLocalSize().X));Invalidate(EInvalidateWidgetReason::Paint);}
 virtual FReply OnMouseButtonDown(const FGeometry& G,const FPointerEvent& E)override{if(E.GetEffectingButton()!=EKeys::LeftMouseButton)return FReply::Unhandled();DragAt(G,E);return FReply::Handled().CaptureMouse(SharedThis(this));}
 virtual FReply OnMouseMove(const FGeometry& G,const FPointerEvent& E)override{if(!HasMouseCapture())return FReply::Unhandled();DragAt(G,E);return FReply::Handled();}
 virtual FReply OnMouseButtonUp(const FGeometry&,const FPointerEvent&)override{return FReply::Handled().ReleaseMouseCapture();}
};
TSharedRef<SWidget> Picker(bool A){return SNew(SComboButton).ButtonStyle(&CameraLightingStyle::Button()).ButtonColorAndOpacity(FLinearColor::FromSRGBColor(FColor(37,39,46))).ContentPadding(8).OnGetMenuContent_Lambda([A]{FMenuBuilder M(true,nullptr);M.AddMenuEntry(FText::FromString(TEXT("Choose image file...")),FText(),FSlateIcon(),FUIAction(FExecuteAction::CreateLambda([A]{if(auto* D=FDesktopPlatformModule::Get()){TArray<FString> Files;if(D->OpenFileDialog(nullptr,TEXT("Choose render"),TEXT(""),TEXT(""),TEXT("Images|*.png;*.jpg;*.jpeg;*.exr"),0,Files) && Files.Num())Review()->LoadImage(A,Files[0]);}})));for(const auto& J:GEditor->GetEditorSubsystem<UCameraLightingRenderService>()->Jobs)if(J.State==ECameraLightingJobState::Completed && J.OutputFiles.Num()){const FString P=J.OutputFiles[0];M.AddMenuEntry(FText::FromString(J.Label),FText::FromString(P),FSlateIcon(),FUIAction(FExecuteAction::CreateLambda([A,P]{Review()->LoadImage(A,P);})));}return M.MakeWidget();}).ButtonContent()[SNew(STextBlock).Text_Lambda([A]{const FString P=A?Review()->PathA:Review()->PathB;return FText::FromString((A?TEXT("A · "):TEXT("B · "))+(P.IsEmpty()?TEXT("Choose render"):FPaths::GetCleanFilename(P)));}).Font(CameraLightingStyle::Font(9))];}
}
TSharedRef<SWidget> MakeCameraLightingComparePanel(){return SNew(SBorder).BorderImage(FAppStyle::GetBrush("WhiteBrush")).BorderBackgroundColor(FLinearColor(.012,.014,.019)).Padding(0)[MakeCameraLightingArtPanel(SNew(SVerticalBox)+SVerticalBox::Slot().AutoHeight()[SNew(SHorizontalBox)+SHorizontalBox::Slot().FillWidth(1).Padding(0,0,8,0)[Picker(true)]+SHorizontalBox::Slot().FillWidth(1)[Picker(false)]+SHorizontalBox::Slot().AutoWidth().Padding(12,0)[SNew(STextBlock).Text(FText::FromString(TEXT("Display EV"))).Font(CameraLightingStyle::Font(9))]+SHorizontalBox::Slot().AutoWidth()[SNew(SBox).WidthOverride(85)[MakeCameraLightingDragNumber([]{return Review()->Exposure;},[](float V){Review()->SetExposure(V);},-10,10,.1f,1)]]]+SVerticalBox::Slot().FillHeight(1).Padding(0,12)[SNew(SWipeCanvas)]+SVerticalBox::Slot().AutoHeight()[SNew(STextBlock).Text_Lambda([]{return FText::FromString(Review()->GetStatus());}).Font(CameraLightingStyle::Font(9))],12)];}
