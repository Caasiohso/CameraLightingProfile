// Copyright Hermes. All Rights Reserved.

using UnrealBuildTool;

public class CameraLightingProfilesEditor : ModuleRules
{
	public CameraLightingProfilesEditor(ReadOnlyTargetRules Target) : base(Target)
	{
		PCHUsage = PCHUsageMode.UseExplicitOrSharedPCHs;

		PublicDependencyModuleNames.AddRange(
			new[]
			{
				"Core", "InputCore", "RenderCore", "ImageCore", "CinematicCamera", "Json", "JsonUtilities", "DesktopPlatform", "UMG",
				"CoreUObject",
				"Engine",
				"UnrealEd",
				"EditorSubsystem",
				"Projects",
				"CameraLightingProfiles",
				"Slate",
				"SlateCore",
				"LevelEditor",
				"ToolMenus",
				"WorkspaceMenuStructure", "MovieRenderPipelineCore", "MovieRenderPipelineEditor",
                "MovieRenderPipelineRenderPasses", "LevelSequence", "MovieScene", "MovieSceneTracks", "AssetRegistry"
			});
	}
}

