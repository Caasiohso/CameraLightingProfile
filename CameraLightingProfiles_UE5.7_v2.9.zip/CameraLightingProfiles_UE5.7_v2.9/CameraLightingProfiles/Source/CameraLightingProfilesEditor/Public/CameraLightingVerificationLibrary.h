#pragma once
#include "CoreMinimal.h"
#include "Kismet/BlueprintFunctionLibrary.h"
#include "CameraLightingVerificationLibrary.generated.h"
UCLASS()
class CAMERALIGHTINGPROFILESEDITOR_API UCameraLightingVerificationLibrary : public UBlueprintFunctionLibrary
{
 GENERATED_BODY()
public:
 /** Draws the real Slate panels into offscreen render targets; does not open or activate any desktop window. */
 UFUNCTION(BlueprintCallable,Category="Camera Lighting|Verification")
 static bool ExportPanelPreviews(const FString& OutputDirectory,bool bExpandCamera=false);
 UFUNCTION(BlueprintCallable,Category="Camera Lighting|Verification")
 static bool ExportPreviewTexture(class UTexture2D* Texture,const FString& Filename);
 UFUNCTION(BlueprintCallable,Category="Camera Lighting|Verification")
 static FString SampleClipSequence(class ULevelSequence* Sequence,float Seconds);
 UFUNCTION(BlueprintCallable,Category="Camera Lighting|Verification")
 static FString VerifyTimelineNavigation();
 UFUNCTION(BlueprintCallable,Category="Camera Lighting|Verification") static bool VerifyPanelRecovery();
 UFUNCTION(BlueprintCallable,Category="Camera Lighting|Verification") static bool VerifyCameraDrop(AActor* Camera);
 UFUNCTION(BlueprintCallable,Category="Camera Lighting|Verification") static FString VerifyShotDragging();
};
