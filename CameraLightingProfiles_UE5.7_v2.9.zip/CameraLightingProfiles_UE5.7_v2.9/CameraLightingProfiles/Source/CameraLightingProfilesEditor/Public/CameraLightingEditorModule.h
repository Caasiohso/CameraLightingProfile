#pragma once
#include "CoreMinimal.h"
#include "Modules/ModuleManager.h"
class FAutoConsoleCommand;
class ILevelEditor;
class SDockTab;
class FSpawnTabArgs;

class FCameraLightingEditorModule : public IModuleInterface
{
public:
 virtual void StartupModule() override;
 virtual void ShutdownModule() override;
 static const FName PanelTabId;
 static const FName ImageTabId;
 static const FName QueueTabId;
 static const FName CameraTabId;
 static const FName ClipsTabId;
 static const FName CompareTabId;
 static const FName PipelineTabId;
 TSharedRef<SDockTab> SpawnPipeline(const FSpawnTabArgs& Args);
 TSharedRef<SDockTab> SpawnCompare(const FSpawnTabArgs& Args);
 static void OpenTab(FName Id);
 void EnsurePanels(){RegisterTabs();}
private:
 TSharedRef<class SDockTab> SpawnCamera(const class FSpawnTabArgs& Args);
 TSharedRef<SDockTab> SpawnClips(const FSpawnTabArgs& Args);
 void RegisterTabs();
 void RegisterMenus();
 void OnLevelEditorCreated(TSharedPtr<ILevelEditor> Editor);
 TSharedRef<SDockTab> SpawnScenes(const FSpawnTabArgs& Args);
 TSharedRef<SDockTab> SpawnImage(const FSpawnTabArgs& Args);
 TSharedRef<SDockTab> SpawnQueue(const FSpawnTabArgs& Args);
 FDelegateHandle LevelEditorCreatedHandle;
 TArray<TUniquePtr<FAutoConsoleCommand>> ConsoleCommands;

};

TSharedRef<class SWidget> MakeCameraLightingRibbonAction(FName Kind,const FString& Label,FName Tab);
