#pragma once
#include "CoreMinimal.h"
#include "EditorSubsystem.h"
#include "CameraLightingReview.generated.h"
UCLASS()
class CAMERALIGHTINGPROFILESEDITOR_API UCameraLightingReview : public UEditorSubsystem
{
 GENERATED_BODY()
public:
 UPROPERTY(Transient) TObjectPtr<class UTexture2D> ImageA;
 UPROPERTY(Transient) TObjectPtr<class UTexture2D> ImageB;
 UPROPERTY(Transient,BlueprintReadOnly,Category="Review") FString PathA;
 UPROPERTY(Transient,BlueprintReadOnly,Category="Review") FString PathB;
 UPROPERTY(Transient,BlueprintReadOnly,Category="Review") float Split=.5f;
 UPROPERTY(Transient,BlueprintReadOnly,Category="Review") float Exposure=0;
 UFUNCTION(BlueprintCallable,Category="Review") bool LoadImage(bool SlotA,const FString& Path);
 UFUNCTION(BlueprintCallable,Category="Review") void SetSplit(float Value){Split=FMath::Clamp(Value,0.f,1.f);}
 UFUNCTION(BlueprintCallable,Category="Review") void SetExposure(float Value);
 UFUNCTION(BlueprintCallable,Category="Review") FString GetStatus()const{return Status;}
private:
 TArray<FLinearColor> Pixels[2];int32 Widths[2]={0,0},Heights[2]={0,0};bool HDR[2]={false,false};
 FString Status=TEXT("Choose two renders, then drag the divider to compare.");
 void Rebuild(int32 Slot);
};
TSharedRef<class SWidget> MakeCameraLightingComparePanel();
