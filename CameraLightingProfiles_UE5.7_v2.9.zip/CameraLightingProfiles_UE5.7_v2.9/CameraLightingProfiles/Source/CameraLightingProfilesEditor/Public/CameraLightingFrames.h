#pragma once
#include "CoreMinimal.h"
struct FCameraLightingStillJob;
FString CameraLightingFramePrefix(const FCameraLightingStillJob& Job);
TMap<int32,FString> CameraLightingFindFrames(const FCameraLightingStillJob& Job);
