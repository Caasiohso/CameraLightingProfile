#pragma once
#include "CoreMinimal.h"
#include "Engine/DataAsset.h"
#include "CameraLightingRenderTemplate.generated.h"
class UMoviePipelinePrimaryConfig;
UENUM(BlueprintType)
enum class ECameraLightingRenderer : uint8 { Lumen, PathTracer };
/** Reusable still-image template. FullPreset is an ordinary native Movie Render Queue preset. */
UCLASS(BlueprintType)
class CAMERALIGHTINGPROFILESEDITOR_API UCameraLightingRenderTemplate : public UDataAsset
{
 GENERATED_BODY()
public:
 UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="Template") FString DisplayName;
 UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="Template") ECameraLightingRenderer Renderer=ECameraLightingRenderer::Lumen;
 UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="Sampling",meta=(ClampMin="1",ClampMax="4096")) int32 SpatialSamples=8;
 UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="Sampling",meta=(ClampMin="1",ClampMax="4096")) int32 TemporalSamples=1;
 UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="Sampling",meta=(ClampMin="0",ClampMax="600")) int32 EngineWarmUp=32;
 UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="Sampling",meta=(ClampMin="0",ClampMax="600")) int32 RenderWarmUp=32;
 UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="Lumen",meta=(EditCondition="Renderer==ECameraLightingRenderer::Lumen",EditConditionHides,ClampMin="0.25",ClampMax="8")) float SceneQuality=1;
 UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="Lumen",meta=(EditCondition="Renderer==ECameraLightingRenderer::Lumen",EditConditionHides,ClampMin="0.25",ClampMax="8")) float FinalGatherQuality=1;
 UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="Lumen",meta=(EditCondition="Renderer==ECameraLightingRenderer::Lumen",EditConditionHides,ClampMin="0.25",ClampMax="8")) float ReflectionQuality=1;
 UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="Path Tracer",meta=(EditCondition="Renderer==ECameraLightingRenderer::PathTracer",EditConditionHides,ClampMin="1",ClampMax="100")) int32 MaxBounces=8;
 UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="Path Tracer",meta=(EditCondition="Renderer==ECameraLightingRenderer::PathTracer",EditConditionHides)) bool bDenoise=true;
 UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="Full MRQ Settings") TSoftObjectPtr<UMoviePipelinePrimaryConfig> FullPreset;
 virtual void PostEditChangeProperty(FPropertyChangedEvent& Event) override;
};
namespace CameraLightingTemplates
{
 UMoviePipelinePrimaryConfig* Build(UCameraLightingRenderTemplate* Template,UObject* Outer);
 void ApplyLook(struct FPostProcessSettings& Settings,const UCameraLightingRenderTemplate* Template);
 bool Save(UObject* Asset);
}
