#pragma once
#include "CoreMinimal.h"
#include "EditorSubsystem.h"
#include "Containers/Ticker.h"
#include "HAL/PlatformProcess.h"
#include "Async/Future.h"
#include "CameraLightingPipelineTools.generated.h"
struct FCameraLightingStillJob;
struct FCLPTaskResult{bool OK=false;FString Error,Manifest,WorkDir,Encoders;TArray<FIntPoint> Ranges;TArray<FString> BadFiles;int32 Valid=0;};
USTRUCT(BlueprintType)
struct FCameraLightingPreflightIssue{GENERATED_BODY() UPROPERTY(BlueprintReadOnly,Category="Preflight") FString Severity;UPROPERTY(BlueprintReadOnly,Category="Preflight") FString Message;UPROPERTY(BlueprintReadOnly,Category="Preflight") FString Code;};
UENUM(BlueprintType) enum class ECameraLightingVideoFormat:uint8{MP4,MOV};
UCLASS(Config=EditorPerProjectUserSettings)
class CAMERALIGHTINGPROFILESEDITOR_API UCameraLightingPipelineTools:public UEditorSubsystem
{
 GENERATED_BODY()
public:
 virtual void Initialize(FSubsystemCollectionBase& C)override;
 virtual void Deinitialize()override;
 UPROPERTY(Config,EditAnywhere,BlueprintReadWrite,Category="Video") bool bClipVideoDelivery=false;
 UFUNCTION(BlueprintCallable,Category="Video") bool RenderCurrentClipVideo();
 UPROPERTY(Transient,BlueprintReadOnly,Category="Video") FString PendingVideoJob;
 UPROPERTY(Config,EditAnywhere,BlueprintReadWrite,Category="Video") FString FFmpegPath;
 UPROPERTY(Config,EditAnywhere,BlueprintReadWrite,Category="Video") FString AudioPath;
 UPROPERTY(Config,EditAnywhere,BlueprintReadWrite,Category="Video") FString VideoDirectory;
 UPROPERTY(Config,EditAnywhere,BlueprintReadWrite,Category="Video") ECameraLightingVideoFormat VideoFormat=ECameraLightingVideoFormat::MP4;
 UPROPERTY(Config,EditAnywhere,BlueprintReadWrite,Category="Video") int32 VideoFPS=0;
 UPROPERTY(Config,EditAnywhere,BlueprintReadWrite,Category="Video") bool bLinearEXR=true;
 UPROPERTY(Transient,BlueprintReadOnly,Category="Pipeline") FString Status;
 UPROPERTY(Transient,BlueprintReadOnly,Category="Preflight") FString LastPreflight;
 UPROPERTY(Transient,BlueprintReadOnly,Category="Video") FString LastVideo;
 UFUNCTION(BlueprintCallable,Category="Preflight") FString RunPreflight(bool SelectedOnly=true);
 UFUNCTION(BlueprintCallable,Category="Preflight") FString InspectCurrentCamera();
 UFUNCTION(BlueprintCallable,Category="Preflight") FString InspectJob(const FString& Id);
 TArray<FCameraLightingPreflightIssue> Inspect(const TArray<FString>& Ids,bool ForRender=false);
 UFUNCTION(BlueprintCallable,Category="Video") bool ExportVideo(const FString& Id);
 UFUNCTION(BlueprintCallable,Category="Recovery") bool RecoverJob(const FString& Id);
 UFUNCTION(BlueprintCallable,Category="Pipeline") void CancelTask();
 UFUNCTION(BlueprintCallable,Category="Pipeline") bool IsBusy()const{return Operation!=0 || !PendingVideoJob.IsEmpty();}
 UFUNCTION(BlueprintCallable,Category="Pipeline") float GetTaskProgress()const;
 UFUNCTION(BlueprintCallable,Category="Pipeline") void Persist(){SaveConfig();}
private:
 FTSTicker::FDelegateHandle Ticker;
 TFuture<FCLPTaskResult> Future;
 TSharedPtr<TAtomic<bool>,ESPMode::ThreadSafe> Cancel;
 TSharedPtr<TAtomic<int32>,ESPMode::ThreadSafe> Done;
 FProcHandle Process;void* PipeRead=nullptr;void* PipeWrite=nullptr;
 int32 Operation=0,TotalFrames=0;FString FrozenEncoder,JobId,Command,ProcessLog,TempDir,VideoTarget,ProgressFile,LogFile;
 double ProcessStarted=0;
 bool Tick(float Delta);void StartEncoder(const FCLPTaskResult& R);void CloseProcess();void FinishVideo(bool OK,const FString& Error);
};
TSharedRef<class SWidget> MakeCameraLightingPipelinePanel();

TSharedRef<class SWidget> MakeCameraLightingClipVideoControls();
