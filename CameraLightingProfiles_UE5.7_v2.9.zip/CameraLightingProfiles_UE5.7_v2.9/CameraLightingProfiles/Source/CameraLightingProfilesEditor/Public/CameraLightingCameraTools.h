#pragma once
#include "CoreMinimal.h"
#include "EditorSubsystem.h"
#include "Engine/AssetUserData.h"
#include "CameraLightingCameraTools.generated.h"
class AActor;
struct FPostProcessSettings;
class UCameraComponent;
class UCineCameraComponent;
class APostProcessVolume;
UCLASS()
class CAMERALIGHTINGPROFILESEDITOR_API UCameraLightingCropData : public UAssetUserData
{
 GENERATED_BODY()
public:
 UPROPERTY() float Ratio=0;
 UPROPERTY() float BaseAspect=16.f/9.f;
 UPROPERTY() bool bBaseConstrain=false;
 virtual bool IsEditorOnly() const override{return true;}
};
UCLASS(Config=EditorPerProjectUserSettings)
class CAMERALIGHTINGPROFILESEDITOR_API UCameraLightingCameraTools : public UEditorSubsystem
{
 GENERATED_BODY()
public:
 virtual void Initialize(FSubsystemCollectionBase& Collection) override;
 UPROPERTY(Transient,BlueprintReadOnly,Category="Camera") TWeakObjectPtr<APostProcessVolume> VolumeTarget;
 UPROPERTY(Config,EditAnywhere,BlueprintReadWrite,Category="Camera") bool bLockFilmbackAspect=true;
 UFUNCTION(BlueprintCallable,Category="Camera") void SelectTarget(AActor* Actor);
 UFUNCTION(BlueprintCallable,Category="Camera") void UseSelectedTarget();
 UFUNCTION(BlueprintCallable,Category="Camera") AActor* GetTarget();
 UFUNCTION(BlueprintCallable,Category="Camera") UCameraComponent* GetCamera();
 UFUNCTION(BlueprintCallable,Category="Camera") UCineCameraComponent* GetCineCamera();
 UFUNCTION(BlueprintCallable,Category="Camera") FString GetTargetName();
 UFUNCTION(BlueprintCallable,Category="Camera") float GetCrop();
 UFUNCTION(BlueprintCallable,Category="Camera") void SetCrop(float Ratio);
 UFUNCTION(BlueprintCallable,Category="Camera") void MatchOutputToCrop();
 UFUNCTION(BlueprintCallable,Category="Camera") float GetValue(FName Property);
 UFUNCTION(BlueprintCallable,Category="Camera") void SetValue(FName Property,float Value);
 UFUNCTION(BlueprintCallable,Category="Camera") void SetMetering(int32 Mode);
 UFUNCTION(BlueprintCallable,Category="Camera") int32 GetMetering();
 UFUNCTION(BlueprintCallable,Category="Camera") bool IsPhysicalExposure();
 UFUNCTION(BlueprintCallable,Category="Camera") void SetPhysicalExposure(bool Enabled);
 UFUNCTION(BlueprintCallable,Category="Camera") void DaylightExposure();
 UFUNCTION(BlueprintCallable,Category="Camera") void ResetExposure();
 UFUNCTION(BlueprintCallable,Category="Camera") void SetFilmbackPreset(const FString& Name);
 UFUNCTION(BlueprintCallable,Category="Camera") void SetFocusMethod(int32 Method);
 UFUNCTION(BlueprintCallable,Category="Camera") int32 GetFocusMethod();
 UFUNCTION(BlueprintCallable,Category="Camera") void SetFocusTarget(AActor* Actor);
 UFUNCTION(BlueprintCallable,Category="Camera") void FocusSelectedActor();
 UFUNCTION(BlueprintCallable,Category="Camera") void SetFocusPlane(bool Enabled);
 UFUNCTION(BlueprintCallable,Category="Camera") bool HasFocusPlane();
 UFUNCTION(BlueprintCallable,Category="Camera") AActor* CreateCineCameraCopy();
private:
 FPostProcessSettings* PostProcess();
 void Edit(TFunction<void()> Change);
};
