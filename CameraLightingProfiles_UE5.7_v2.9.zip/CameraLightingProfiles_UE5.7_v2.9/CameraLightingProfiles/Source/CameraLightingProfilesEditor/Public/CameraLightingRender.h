#pragma once
#include "CoreMinimal.h"
class AActor;
namespace CameraLightingRender
{
 TSharedRef<class SWidget> MakePanel();
 void Render(const TArray<AActor*>& Cameras);
}
