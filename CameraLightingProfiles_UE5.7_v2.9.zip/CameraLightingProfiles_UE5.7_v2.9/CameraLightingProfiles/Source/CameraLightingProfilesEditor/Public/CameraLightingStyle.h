#pragma once
#include "CoreMinimal.h"
#include "Styling/AppStyle.h"
#include "Styling/SlateTypes.h"
#include "Brushes/SlateColorBrush.h"
#include "Fonts/CompositeFont.h"
#include "HAL/PlatformMisc.h"
#include "Misc/Paths.h"
namespace CameraLightingStyle
{
inline FSlateFontInfo Font(int32 Size)
{
 static TSharedPtr<FCompositeFont> Face=[]()->TSharedPtr<FCompositeFont>{FString Path=FPlatformMisc::GetEnvironmentVariable(TEXT("LOCALAPPDATA"))/TEXT("Microsoft/Windows/Fonts/Roxbyte.otf");if(!FPaths::FileExists(Path))return TSharedPtr<FCompositeFont>();auto Default=FCoreStyle::GetDefaultFontStyle("Regular",10);auto F=MakeShared<FCompositeFont>(*Default.GetCompositeFont());F->FallbackTypeface.Typeface=F->DefaultTypeface;for(auto& Entry:F->DefaultTypeface.Fonts)Entry.Font=FFontData(Path,EFontHinting::Default,EFontLoadingPolicy::LazyLoad);return F;}();
 return Face.IsValid()?FSlateFontInfo(Face,Size):FCoreStyle::GetDefaultFontStyle("Regular",Size);
}
inline const FButtonStyle& Button()
{
 static const FButtonStyle Style=[] {
  FButtonStyle Value=FAppStyle::Get().GetWidgetStyle<FButtonStyle>("Button");
  Value.SetNormal(FSlateColorBrush(FLinearColor::White));
  Value.SetHovered(FSlateColorBrush(FLinearColor::White));
  Value.SetPressed(FSlateColorBrush(FLinearColor(.8f,.8f,.8f)));
  Value.SetNormalForeground(FLinearColor::White);Value.SetHoveredForeground(FLinearColor::White);Value.SetPressedForeground(FLinearColor::White);
  Value.SetNormalPadding(FMargin(0));Value.SetPressedPadding(FMargin(0));return Value;
 }();return Style;
}
inline const FEditableTextBoxStyle& Field()
{
 static const FEditableTextBoxStyle Style=[] {
  FEditableTextBoxStyle Value=FAppStyle::Get().GetWidgetStyle<FEditableTextBoxStyle>("NormalEditableTextBox");
  const FSlateColorBrush Brush(FLinearColor::FromSRGBColor(FColor(37,39,46)));
  Value.SetBackgroundImageNormal(Brush);Value.SetBackgroundImageHovered(Brush);Value.SetBackgroundImageFocused(Brush);Value.SetBackgroundImageReadOnly(Brush);
  Value.SetFont(Font(10));Value.SetForegroundColor(FLinearColor(.88f,.9f,.94f));Value.SetPadding(FMargin(7,5));return Value;
 }();return Style;
}
}
