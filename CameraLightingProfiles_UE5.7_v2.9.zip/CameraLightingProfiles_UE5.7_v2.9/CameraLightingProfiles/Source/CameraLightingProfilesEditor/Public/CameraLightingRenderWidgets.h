#pragma once
#include "CoreMinimal.h"
#include "Widgets/SCompoundWidget.h"

TSharedRef<SWidget> MakeCameraLightingImagePanel();
TSharedRef<SWidget> MakeCameraLightingQueuePanel();

class SCameraLightingQueuePanel : public SCompoundWidget
{
public:
 SLATE_BEGIN_ARGS(SCameraLightingQueuePanel) {} SLATE_END_ARGS()
 void Construct(const FArguments& Args);
 virtual ~SCameraLightingQueuePanel();
 virtual void Tick(const FGeometry& Geometry,const double Time,const float DeltaTime) override;
private:
 TSharedPtr<SVerticalBox> Rows;
 bool bHistory=false;
 bool bNewest=true;
 bool bNeedsRefresh=true;
 FString StateFilter=TEXT("All States");
 void RebuildRows();
 void InvalidateRows();
 TSharedRef<SWidget> MakeSortMenu();
 TSharedRef<SWidget> MakeStateMenu();
};

TSharedRef<class SWidget> MakeCameraLightingRenderSettings(bool Batch=false);
