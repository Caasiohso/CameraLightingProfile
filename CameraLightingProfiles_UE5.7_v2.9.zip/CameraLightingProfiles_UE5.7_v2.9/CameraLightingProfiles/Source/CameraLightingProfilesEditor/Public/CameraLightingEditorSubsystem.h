// Copyright Hermes. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Containers/Ticker.h"
#include "Engine/EngineTypes.h"
#include "EditorSubsystem.h"
#include "CameraLightingEditorSubsystem.generated.h"

/**
 * Editor-only: detects when you PILOT a camera in a viewport (the viewport locks
 * to that actor) and applies its UCameraLightingProfile. Also exposes
 * ApplyToCurrent() / RestoreDefaults() for Editor Utility Widgets or a toolbar.
 */
UCLASS()
class UCameraLightingEditorSubsystem : public UEditorSubsystem
{
	GENERATED_BODY()

public:
	virtual void Initialize(FSubsystemCollectionBase& Collection) override;
	virtual void Deinitialize() override;

	// Blueprint-callable: apply the profile of whatever camera is currently piloted/active.
	UFUNCTION(BlueprintCallable, Category = "Camera Lighting (Editor)")
	void ApplyToCurrent();

	// Blueprint-callable: restore the previously-recorded default SkyLight/HDRI.
	UFUNCTION(BlueprintCallable, Category = "Camera Lighting (Editor)")
	void RestoreDefaults();

	// Pilot a specific camera: cache defaults if needed and apply its profile.
	// Called by the Camera Lighting panel when you click a camera (D5-style swap).
	UFUNCTION(BlueprintCallable, Category = "Camera Lighting (Editor)")
	void PilotCamera(AActor* CameraActor);

private:
	void OnCameraMoved(const FVector& Position, const FRotator& Rotation, ELevelViewportType ViewportType, int32 ViewIndex);
	bool Tick(float DeltaTime);
	void ApplyForActor(AActor* CameraActor);

	UPROPERTY()
	TWeakObjectPtr<AActor> CurrentCameraActor;

	// Snapshot of the first SkyLight's original cubemap/intensity for restore.
	UPROPERTY()
	TWeakObjectPtr<class ASkyLight> CachedSkyLight;
	UPROPERTY()
	TObjectPtr<class UTextureCube> CachedCubemap;
	float CachedIntensity = 1.f;
	bool bCached = false;

	FTSTicker::FDelegateHandle TickHandle;
};

