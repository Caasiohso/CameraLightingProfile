#pragma once
#include "CoreMinimal.h"
#include "Widgets/SCompoundWidget.h"
class UCameraLightingProfile;

/** A compact saved-scene sidebar. Rebuilds are deferred until Tick. */
class SCameraLightingViewportPanel : public SCompoundWidget
{
public:
 SLATE_BEGIN_ARGS(SCameraLightingViewportPanel) {} SLATE_END_ARGS()
 void Construct(const FArguments& Args);
 virtual ~SCameraLightingViewportPanel();
 virtual void Tick(const FGeometry& Geometry,const double Time,const float DeltaTime) override;
 void RebuildCameraList();
private:
 TSharedPtr<SVerticalBox> CameraListBox;
 FString Fingerprint;
 FString CaptureStatus;
 double LastRefresh=0;
 float CachedPanelHeight=620;
 int32 SceneCount=0;
 bool bNeedsRefresh=true;
 void InvalidateList();
 TSharedRef<SWidget> MakeCameraCard(AActor* Camera);
 TSharedRef<SWidget> MakeThumbnail(const UCameraLightingProfile* Profile);
 void Pilot(AActor* Camera);
};
