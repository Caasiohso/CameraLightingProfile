// Copyright Hermes. All Rights Reserved.
#pragma once
#include "CoreMinimal.h"
#include "Kismet/BlueprintFunctionLibrary.h"
#include "CameraLightingCaptureLibrary.generated.h"

class AActor;

/** Editor scripting entry points for automated scene capture without desktop input. */
UCLASS()
class CAMERALIGHTINGPROFILESEDITOR_API UCameraLightingCaptureLibrary : public UBlueprintFunctionLibrary
{
    GENERATED_BODY()
public:
    UFUNCTION(BlueprintCallable, Category="Camera Lighting|Capture", meta=(DevelopmentOnly))
    static AActor* CreateSceneFromView();
    UFUNCTION(BlueprintCallable, Category="Camera Lighting|Capture", meta=(DevelopmentOnly))
    static bool CaptureActor(AActor* CameraActor);
    UFUNCTION(BlueprintPure, Category="Camera Lighting|Capture")
    static FString GetLastError();
};
