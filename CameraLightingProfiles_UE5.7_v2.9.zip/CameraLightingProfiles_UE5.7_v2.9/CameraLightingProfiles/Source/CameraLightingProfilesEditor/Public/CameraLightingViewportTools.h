#pragma once
#include "CoreMinimal.h"
#include "EditorSubsystem.h"
#include "Containers/Ticker.h"
#include "CameraLightingViewportTools.generated.h"
class SLevelViewport;
UCLASS(Config=EditorPerProjectUserSettings)
class CAMERALIGHTINGPROFILESEDITOR_API UCameraLightingViewportTools : public UEditorSubsystem
{
 GENERATED_BODY()
public:
 virtual void Initialize(FSubsystemCollectionBase& Collection) override;
 virtual void Deinitialize() override;
 UPROPERTY(Config,EditAnywhere,BlueprintReadWrite,Category="Guides") bool bThirds=false;
 UPROPERTY(Config,EditAnywhere,BlueprintReadWrite,Category="Guides") bool bCenter=false;
 UPROPERTY(Config,EditAnywhere,BlueprintReadWrite,Category="Guides") bool bSafeAreas=false;
 UPROPERTY(Config,EditAnywhere,BlueprintReadWrite,Category="Guides") bool bCropGuide=false;
 UPROPERTY(Config,EditAnywhere,BlueprintReadWrite,Category="Guides") bool bGoldenRatio=false;
 UPROPERTY(Config,EditAnywhere,BlueprintReadWrite,Category="Guides") bool bDiagonals=false;
 UPROPERTY(Config,EditAnywhere,BlueprintReadWrite,Category="Guides") bool bTriangle=false;
 UPROPERTY(Config,EditAnywhere,BlueprintReadWrite,Category="Guides") bool bSpiral=false;
 UPROPERTY(Config,EditAnywhere,BlueprintReadWrite,Category="Guides") bool bHorizon=false;
 UPROPERTY(Config,EditAnywhere,BlueprintReadWrite,Category="Guides") bool bSquare=false;
 UPROPERTY(Config,EditAnywhere,BlueprintReadWrite,Category="Guides") bool bLetterbox=false;
 UFUNCTION(BlueprintCallable,Category="Guides") bool IsGuideEnabled(FName Guide)const;
 UPROPERTY(Transient,BlueprintReadOnly,Category="Focus") bool bPickingFocus=false;
 UFUNCTION(BlueprintCallable,Category="Guides") void SetGuide(FName Guide,bool Enabled);
 UFUNCTION(BlueprintCallable,Category="Focus") bool ArmFocusPick(bool TrackActor=false);
 UFUNCTION(BlueprintCallable,Category="Focus") void CancelFocusPick();
 UFUNCTION(BlueprintCallable,Category="Focus") bool FocusWorldPoint(FVector Point,AActor* TrackActor=nullptr);
 UFUNCTION(BlueprintCallable,Category="Focus") bool PickFocusAtPixel(FVector2D Pixel);
 UFUNCTION(BlueprintCallable,Category="Focus") FVector2D ProjectWorldPoint(FVector Point);
 UFUNCTION(BlueprintCallable,Category="Scene") void PilotScene(AActor* Camera);
 UFUNCTION(BlueprintCallable,Category="Scene") void ExitPilot();
 UFUNCTION(BlueprintCallable,Category="Scene") bool IsPiloting();
 UFUNCTION(BlueprintCallable,Category="Focus") FString GetStatus() const{return Status;}
private:
 FTSTicker::FDelegateHandle TickHandle;
 TWeakPtr<SLevelViewport> Attached;
 TSharedPtr<class SWidget> Overlay;
 bool Tick(float Delta);
 bool bTrackPick=false;
 FString Status;
};
TSharedRef<class SWidget> MakeCameraLightingGuidesOverlay();
