#pragma once
#include "CoreMinimal.h"
class SWidget;
TSharedRef<SWidget> MakeCameraLightingGlyph(FName Kind,float Size=20);
TSharedRef<SWidget> MakeCameraLightingEmptyIllustration();
TSharedRef<SWidget> MakeCameraLightingCameraPanel();
TSharedRef<SWidget> MakeCameraLightingTemplateSelector(bool bOpenImageOnSelect=false);

/** Native horizontal scrub control. Drag changes are committed once; optional live camera preview uses one undo transaction. */
TSharedRef<SWidget> MakeCameraLightingDragNumber(TFunction<float()> Get,TFunction<void(float)> Set,float Min,float Max,float Delta=1.f,int32 Decimals=2,bool bLivePreview=false);
TSharedRef<SWidget> MakeCameraLightingCornerArt(TAttribute<float> ReservedTop=0.f);

TSharedRef<SWidget> MakeCameraLightingPreview(const class UCameraLightingProfile* Profile,float Width,float Height);

void CameraLightingBeginWindowArtwork();

TSharedRef<SWidget> MakeCameraLightingArtPanel(TSharedRef<SWidget> Content,float Padding);
