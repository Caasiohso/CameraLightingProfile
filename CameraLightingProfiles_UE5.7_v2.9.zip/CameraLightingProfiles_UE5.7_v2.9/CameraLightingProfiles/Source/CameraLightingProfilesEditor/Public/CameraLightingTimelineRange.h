#pragma once
#include "CoreMinimal.h"
/** Timeline viewport navigation independent of clip duration. Times are seconds. */
struct FCameraLightingTimelineRange
{
 double Start=0,Span=3;
 void Fit(double Duration){Start=0;Span=FMath::Max(Duration,.001);}
 void Zoom(double Wheel,double Anchor,int32 Fps){const double Time=Start+Span*Anchor;Span=FMath::Clamp(Span*FMath::Pow(.8,Wheel),4./FMath::Max(Fps,1),86400.);Start=FMath::Max(0.,Time-Span*Anchor);}
 void Pan(double Seconds){Start=FMath::Clamp(Start+Seconds,0.,FMath::Max(0.,86400.-Span));}
 double At(double Normalized)const{return Start+Normalized*Span;}
 double TickStep(double Pixels,int32 Fps)const
 {
  const double Wanted=Span*80./FMath::Max(Pixels,80.);const double P=FMath::Pow(10.,FMath::FloorToDouble(FMath::LogX(10.,Wanted)));const double N=Wanted/P;const double Step=(N<=1?1:N<=2?2:N<=5?5:10)*P;return FMath::Max(1./FMath::Max(Fps,1),Step);
 }
};
