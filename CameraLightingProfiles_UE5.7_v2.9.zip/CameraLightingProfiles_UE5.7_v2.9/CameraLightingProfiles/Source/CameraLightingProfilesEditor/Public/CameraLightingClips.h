#pragma once
#include "CoreMinimal.h"
#include "EditorSubsystem.h"
#include "Engine/DataAsset.h"
#include "Containers/Ticker.h"
#include "CameraLightingClips.generated.h"
class ULevelSequence;
class UCameraLightingProfile;
class ACameraActor;
USTRUCT(BlueprintType)
struct FCameraLightingClipView
{
 GENERATED_BODY()
 UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="View") FTransform Transform;
 UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="View") float Fov=90;
 UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="View") float Time=-1;
 UPROPERTY(VisibleAnywhere,BlueprintReadOnly,Category="View") TObjectPtr<UCameraLightingProfile> Lighting;
};
UENUM(BlueprintType)
enum class ECameraLightingInterpolation : uint8 {Linear,Smooth,Constant};
USTRUCT(BlueprintType)
struct FCameraLightingShot
{
 GENERATED_BODY()
 UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="Shot") FString Id;
 UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="Shot") FString Label;
 UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="Shot") float Start=0;
 UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="Shot") float Length=3;
 UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="Shot") ECameraLightingInterpolation Interpolation=ECameraLightingInterpolation::Linear;
 UPROPERTY(EditAnywhere,BlueprintReadOnly,Category="Shot") TSoftObjectPtr<AActor> CameraActor;
 UPROPERTY(EditAnywhere,BlueprintReadOnly,Category="Shot") bool bRecorded=false;
 UPROPERTY(EditAnywhere,BlueprintReadOnly,Category="Shot") TArray<FCameraLightingClipView> Views;
};
UCLASS(BlueprintType)
class CAMERALIGHTINGPROFILESEDITOR_API UCameraLightingClip : public UDataAsset
{
 GENERATED_BODY()
public:
 UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="Clip") FString DisplayName=TEXT("Clip");
 UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="Clip",meta=(ClampMin="0.1",ClampMax="86400")) float Duration=3;
 UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="Clip",meta=(ClampMin="1",ClampMax="120")) int32 FrameRate=24;
 UPROPERTY(EditAnywhere,BlueprintReadOnly,Category="Clip") TArray<FCameraLightingClipView> Views;
 UPROPERTY(EditAnywhere,BlueprintReadOnly,Category="Clip") TArray<FCameraLightingShot> Shots;
 UPROPERTY(VisibleAnywhere,Category="Clip") TSoftObjectPtr<ULevelSequence> LegacySequenceBackup;
 UPROPERTY(VisibleAnywhere,BlueprintReadOnly,Category="Clip") TSoftObjectPtr<ULevelSequence> Sequence;
 UPROPERTY(VisibleAnywhere,BlueprintReadOnly,Category="Clip") FString MapPath;
};
DECLARE_MULTICAST_DELEGATE(FOnCameraLightingClipsChanged);
UCLASS(Config=EditorPerProjectUserSettings)
class CAMERALIGHTINGPROFILESEDITOR_API UCameraLightingClipService : public UEditorSubsystem
{
 GENERATED_BODY()
public:
 virtual void Initialize(FSubsystemCollectionBase& Collection) override;
 virtual void Deinitialize() override;
 UPROPERTY(Transient,BlueprintReadOnly,Category="Clips") TArray<TObjectPtr<UCameraLightingClip>> Clips;
 UPROPERTY(Transient,BlueprintReadOnly,Category="Clips") TObjectPtr<UCameraLightingClip> SelectedClip;
 UPROPERTY(Transient,BlueprintReadOnly,Category="Clips") TObjectPtr<ACameraActor> PreviewCamera;
 FOnCameraLightingClipsChanged OnChanged;
 UFUNCTION(BlueprintCallable,Category="Clips") TArray<UCameraLightingClip*> GetClips();
 UFUNCTION(BlueprintCallable,Category="Clips") UCameraLightingClip* CreateClip();
 UFUNCTION(BlueprintCallable,Category="Clips") void SelectClip(UCameraLightingClip* Clip);
 UFUNCTION(BlueprintCallable,Category="Clips") void RenameClip(const FString& Name);
 UFUNCTION(BlueprintCallable,Category="Clips") void DuplicateClip();
 UFUNCTION(BlueprintCallable,Category="Clips") bool AddView();
 UFUNCTION(BlueprintCallable,Category="Clips") bool AddCameraView(AActor* Camera);
 UFUNCTION(BlueprintCallable,Category="Clips") bool UpdateView(int32 Index);
 UFUNCTION(BlueprintCallable,Category="Clips") void RemoveView(int32 Index);
 UFUNCTION(BlueprintCallable,Category="Clips") void MoveView(int32 Index,int32 Direction);
 UFUNCTION(BlueprintCallable,Category="Clips") void SetDuration(float Seconds);
 UFUNCTION(BlueprintCallable,Category="Clips") void SetFrameRate(int32 Fps);
 UFUNCTION(BlueprintCallable,Category="Clips") bool SaveClip();
 UFUNCTION(BlueprintCallable,Category="Clips") void Scrub(float Seconds);
 UFUNCTION(BlueprintCallable,Category="Clips") void TogglePlay();
 UFUNCTION(BlueprintCallable,Category="Clips") void StopPreview();
 UFUNCTION(BlueprintCallable,Category="Clips") bool IsPlaying() const{return bPlaying;}
 UFUNCTION(BlueprintCallable,Category="Clips") float GetPlayhead() const{return Playhead;}
 UFUNCTION(BlueprintCallable,Category="Clips") FCameraLightingClipView EvaluateView(float Seconds) const;
 UFUNCTION(BlueprintCallable,Category="Clips") FString QueueClip();
 UFUNCTION(BlueprintCallable,Category="Clips") bool RenderClip();
 UFUNCTION(BlueprintCallable,Category="Clips") ULevelSequence* ExportToSequencer();
 UFUNCTION(BlueprintCallable,Category="Clips") FString GetStatus() const{return Status;}
 UFUNCTION(BlueprintCallable,Category="Clips") void SetShotRange(int32 Index,float Start,float Length);
 UFUNCTION(BlueprintCallable,Category="Clips") bool AddMotionView(int32 ShotIndex);
 UFUNCTION(BlueprintCallable,Category="Clips") bool RenderDraft();
 UPROPERTY(Config,EditAnywhere,BlueprintReadWrite,Category="Recording") int32 RecordFPS=24;
 UPROPERTY(Config,EditAnywhere,BlueprintReadWrite,Category="Recording") ECameraLightingInterpolation RecordInterpolation=ECameraLightingInterpolation::Linear;
 UPROPERTY(Transient,BlueprintReadOnly,Category="Recording") bool bRecording=false;
 UPROPERTY(Transient,BlueprintReadOnly,Category="Clips") FString SelectedShotId;
 UFUNCTION(BlueprintCallable,Category="Clips") bool SelectShot(int32 Index,bool OpenSettings=true);
 UFUNCTION(BlueprintCallable,Category="Clips") void SyncCameraEdit(AActor* Actor);
 UFUNCTION(BlueprintCallable,Category="Clips") void SetInterpolation(ECameraLightingInterpolation Value);
 UFUNCTION(BlueprintCallable,Category="Clips") ECameraLightingInterpolation GetInterpolation()const;
 UFUNCTION(BlueprintCallable,Category="Recording") bool StartRecording();
 UFUNCTION(BlueprintCallable,Category="Recording") bool StopRecording(bool Keep=true);
 UFUNCTION(BlueprintCallable,Category="Recording") float GetRecordingSeconds()const;
 UFUNCTION(BlueprintCallable,Category="Recording") int32 GetRecordedFrameCount()const{return RecordedFrames.Num();}
 UFUNCTION(BlueprintCallable,Category="Clips") bool DropCamera(AActor* Camera,float Start);
 void Migrate(UCameraLightingClip* Clip);
private:
 FTSTicker::FDelegateHandle TickHandle;
 bool bLoaded=false,bPlaying=false;
 float Playhead=0;
 FString Status=TEXT("Create a clip, then add camera views.");
 TWeakObjectPtr<AActor> PreviousLock;
 FVector PreviousLocation=FVector::ZeroVector;
 FRotator PreviousRotation=FRotator::ZeroRotator;
 float PreviousFov=90;
 bool bSavedViewport=false;
 bool bSyncing=false;
 double RecordStart=0,PreviousSampleTime=0;int32 NextRecordFrame=1;
 FCameraLightingClipView PreviousSample;
 TArray<FCameraLightingClipView> RecordedFrames;
 bool SampleViewport(FCameraLightingClipView& Out)const;
 void TickRecording();
 bool Tick(float Delta);
 bool CaptureView(FCameraLightingClipView& Out,AActor* Camera);
 bool RebuildSequence();
 bool CanEdit();
 void Error(const FString& Message);
};
TSharedRef<class SWidget> MakeCameraLightingClipsPanel();
