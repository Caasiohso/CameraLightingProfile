// Copyright Hermes. All Rights Reserved.
#pragma once
#include "CoreMinimal.h"

class AActor;
class UCameraLightingProfile;
class UTexture2D;

/** Editor capture backend. All operations run on the editor game thread. */
class CAMERALIGHTINGPROFILESEDITOR_API FCameraLightingCapture
{
public:
    // Compatibility entry points used by older panel/toolbar code.
    static void CaptureCamera(AActor* CameraActor);
    static void CapturePilotedCamera();

    // CaptureActor reports failure instead of silently accepting a failed thumbnail/save.
    static bool CaptureActor(AActor* CameraActor);
    static bool CaptureClipView(AActor* CameraActor,UCameraLightingProfile* Profile);
    // Always creates a new scene camera at the current perspective view.
    static AActor* CreateSceneFromView();
    // Selected camera first, then the active piloted camera. Does not create an actor.
    static AActor* FindCaptureCamera();
    static const FString& GetLastError();

private:
    static UCameraLightingProfile* CreateAndLinkProfile(AActor* CameraActor);
    static void SnapshotProfile(UCameraLightingProfile* Profile, AActor* CameraActor);
    static bool RenderThumbnail(UCameraLightingProfile* Profile, AActor* CameraActor);
    static bool PersistProfile(UCameraLightingProfile* Profile);
    static UTexture2D* MakeThumbnail(UCameraLightingProfile* Profile, FIntPoint Size, const TArray<FColor>& Pixels);
};
