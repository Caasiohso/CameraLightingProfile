#pragma once
#include "CoreMinimal.h"
#include "EditorSubsystem.h"
#include "Containers/Ticker.h"
#include "CameraLightingRenderTemplate.h"
#include "CameraLightingRenderService.generated.h"

class ULevelSequence;
class UMoviePipelineQueue;
class UMoviePipelinePIEExecutor;
class UMoviePipelineExecutorBase;
class UMoviePipelineExecutorJob;
class UMoviePipeline;
struct FMoviePipelineOutputData;

UENUM(BlueprintType)
enum class ECameraLightingImageFormat : uint8 { PNG, JPEG, EXR };
UENUM(BlueprintType)
enum class ECameraLightingJobState : uint8 { Waiting, Rendering, Completed, Failed, Canceled };

USTRUCT(BlueprintType)
struct FCameraLightingStillJob
{
 GENERATED_BODY()
 UPROPERTY(BlueprintReadOnly,Category="Render Queue") FString Id;
 UPROPERTY(BlueprintReadOnly,Category="Render Queue") FString Label;
 UPROPERTY(BlueprintReadOnly,Category="Render Queue") FString CameraPath;
 UPROPERTY(BlueprintReadOnly,Category="Render Queue") FString MapPath;
 UPROPERTY(BlueprintReadOnly,Category="Render Queue") int32 Width=1920;
 UPROPERTY(BlueprintReadOnly,Category="Render Queue") int32 Height=1080;
 UPROPERTY(BlueprintReadOnly,Category="Render Queue") ECameraLightingImageFormat Format=ECameraLightingImageFormat::EXR;
 UPROPERTY(BlueprintReadOnly,Category="Render Queue") ECameraLightingJobState State=ECameraLightingJobState::Waiting;
 UPROPERTY(BlueprintReadOnly,Category="Render Queue") bool bSelected=true;
 UPROPERTY(BlueprintReadOnly,Category="Render Queue") FString OutputDirectory;
 UPROPERTY(BlueprintReadOnly,Category="Render Queue") FString Prefix;
 UPROPERTY(BlueprintReadOnly,Category="Render Queue") FString Error;
 UPROPERTY(BlueprintReadOnly,Category="Render Queue") TArray<FString> OutputFiles;
 UPROPERTY(BlueprintReadOnly,Category="Render Queue") FString CreatedAt;
 UPROPERTY(BlueprintReadOnly,Category="Render Queue") FString CompletedAt;
 UPROPERTY(BlueprintReadOnly,Category="Render Queue") FString SequencePath;
 UPROPERTY(BlueprintReadOnly,Category="Render Queue") FString TemplateName;
 UPROPERTY(BlueprintReadOnly,Category="Render Queue") FString RenderConfigPath;
 UPROPERTY(BlueprintReadOnly,Category="Render Queue") bool bPathTracing=false;
 UPROPERTY(BlueprintReadOnly,Category="Render Queue") bool bClip=false;
 UPROPERTY(BlueprintReadOnly,Category="Render Queue") bool bDraft=false;
 UPROPERTY(BlueprintReadOnly,Category="Render Queue") bool bRecovering=false;
 UPROPERTY(BlueprintReadOnly,Category="Render Queue") TArray<FIntPoint> RecoveryRanges;
 UPROPERTY(BlueprintReadOnly,Category="Render Queue") TArray<FString> VideoFiles;
 UPROPERTY(BlueprintReadOnly,Category="Render Queue") FString DeliveryError;
 UPROPERTY(BlueprintReadOnly,Category="Render Queue") int32 CompletedFrames=0;
 UPROPERTY(BlueprintReadOnly,Category="Render Queue") double ElapsedSeconds=0;
 UPROPERTY(BlueprintReadOnly,Category="Render Queue") int32 FrameRate=24;
 UPROPERTY(BlueprintReadOnly,Category="Render Queue") int32 FrameCount=1;
};

DECLARE_MULTICAST_DELEGATE(FOnCameraLightingRenderChanged);

UCLASS(Config=EditorPerProjectUserSettings)
class CAMERALIGHTINGPROFILESEDITOR_API UCameraLightingRenderService : public UEditorSubsystem
{
 GENERATED_BODY()
public:
 virtual void Initialize(FSubsystemCollectionBase& Collection) override;
 virtual void Deinitialize() override;
 UPROPERTY(Config,EditAnywhere,BlueprintReadWrite,Category="Image") int32 Width=1920;
 UPROPERTY(Config,EditAnywhere,BlueprintReadWrite,Category="Image") int32 Height=1080;
 UPROPERTY(Config,EditAnywhere,BlueprintReadWrite,Category="Image") bool bLockAspect=true;
 UPROPERTY(Config,EditAnywhere,BlueprintReadWrite,Category="Image") FString AspectPreset=TEXT("16:9");
 UPROPERTY(Config,EditAnywhere,BlueprintReadWrite,Category="Image") ECameraLightingImageFormat Format=ECameraLightingImageFormat::EXR;
 UPROPERTY(Config,EditAnywhere,BlueprintReadWrite,Category="Image") int32 SpatialSamples=8;
 UPROPERTY(Config,EditAnywhere,BlueprintReadWrite,Category="Image") FString OutputDirectory;
 UPROPERTY(Config,EditAnywhere,BlueprintReadWrite,Category="Image") FString FilePrefix=TEXT("Image");
 UPROPERTY(Transient,BlueprintReadOnly,Category="Image") TArray<FCameraLightingStillJob> Jobs;
 UPROPERTY(Transient) TWeakObjectPtr<AActor> SelectedCamera;
 UPROPERTY(Config,EditAnywhere,BlueprintReadWrite,Category="Templates") TSoftObjectPtr<UCameraLightingRenderTemplate> SelectedTemplate;
 UPROPERTY(Transient) TArray<TObjectPtr<UCameraLightingRenderTemplate>> TemplateCache;
 FOnCameraLightingRenderChanged OnChanged;
 UPROPERTY(Config,EditAnywhere,BlueprintReadWrite,Category="Batch") bool bUseBatchSettings=true;
 UFUNCTION(BlueprintCallable,Category="Batch") int32 ApplySettingsToSelectedJobs();
 UFUNCTION(BlueprintCallable,Category="Templates") int32 GetTemplateWarmup();
 UFUNCTION(BlueprintCallable,Category="Templates") void SetTemplateWarmup(int32 Frames);
 UFUNCTION(BlueprintCallable,Category="Templates") TArray<UCameraLightingRenderTemplate*> GetTemplates();
 UFUNCTION(BlueprintCallable,Category="Templates") UCameraLightingRenderTemplate* GetCurrentTemplate();
 UFUNCTION(BlueprintCallable,Category="Templates") void SelectTemplate(UCameraLightingRenderTemplate* Template);
 UFUNCTION(BlueprintCallable,Category="Templates") void SaveTemplate();
 UFUNCTION(BlueprintCallable,Category="Templates") void DuplicateTemplate();
 UFUNCTION(BlueprintCallable,Category="Templates") void EditTemplate();
 UFUNCTION(BlueprintCallable,Category="Templates") void EditFullPreset();
 UFUNCTION(BlueprintCallable,Category="Templates") int32 GetTemplateSamples();
 UFUNCTION(BlueprintCallable,Category="Templates") void SetTemplateSamples(int32 Samples);
 UFUNCTION(BlueprintCallable,Category="Templates") int32 GetTemplateTemporalSamples();
 UFUNCTION(BlueprintCallable,Category="Templates") void SetTemplateTemporalSamples(int32 Samples);
 UFUNCTION(BlueprintCallable,Category="Clips") FString QueueClip(ULevelSequence* Sequence,const FString& Label,int32 Fps,int32 Frames);
 UFUNCTION(BlueprintCallable,Category="Clips") bool RenderClip(ULevelSequence* Sequence,const FString& Label,int32 Fps,int32 Frames);
 UFUNCTION(BlueprintCallable,Category="Templates") FString GetTemplateReadiness();
 UFUNCTION(BlueprintCallable,Category="Image") void PersistSettings();
 UFUNCTION(BlueprintCallable,Category="Image") void SetResolution(int32 InWidth,int32 InHeight);
 UFUNCTION(BlueprintCallable,Category="Image") void SetImageWidth(int32 InWidth);
 UFUNCTION(BlueprintCallable,Category="Image") void SetImageHeight(int32 InHeight);
 UFUNCTION(BlueprintCallable,Category="Image") void SetAspectPreset(const FString& Preset);
 UFUNCTION(BlueprintCallable,Category="Image") void SetPresetSize(int32 LongEdge);
 UFUNCTION(BlueprintCallable,Category="Image") void SetSelectedCamera(AActor* Camera);
 UFUNCTION(BlueprintCallable,Category="Image") AActor* ResolveCamera(bool bCreateFromView=false);
 UFUNCTION(BlueprintCallable,Category="Image") float GetCameraFov();
 UFUNCTION(BlueprintCallable,Category="Image") float GetCameraCropRatio();
 UFUNCTION(BlueprintCallable,Category="Image") float GetFocalLength();
 UFUNCTION(BlueprintCallable,Category="Image") void SetCameraFov(float Degrees);
 UFUNCTION(BlueprintCallable,Category="Image") void SetFocalLength(float Millimeters);
 UFUNCTION(BlueprintCallable,Category="Image") FString QueueCamera(AActor* Camera);
 UFUNCTION(BlueprintCallable,Category="Image") int32 QueueAllCameras();
 UFUNCTION(BlueprintCallable,Category="Image") bool RenderCamera(AActor* Camera);
 UFUNCTION(BlueprintCallable,Category="Image") bool RenderQueued();
 UFUNCTION(BlueprintCallable,Category="Clips") bool RenderJob(const FString& Id);
 UFUNCTION(BlueprintCallable,Category="Image") void CancelRendering();
 UFUNCTION(BlueprintCallable,Category="Image") bool IsRendering() const;
 UFUNCTION(BlueprintCallable,Category="Image") FString GetStatusText() const;
 UFUNCTION(BlueprintCallable,Category="Image") void SetJobSelected(const FString& Id,bool bSelected);
 UFUNCTION(BlueprintCallable,Category="Image") void RemoveQueuedJob(const FString& Id);
 UFUNCTION(BlueprintCallable,Category="Recovery") FString NewAttempt(const FString& Id);
 bool StartRecovery(const FString& Id,const TArray<FIntPoint>& Ranges);
 UFUNCTION(BlueprintCallable,Category="Image") void RetryJob(const FString& Id);
 UFUNCTION(BlueprintCallable,Category="Image") void OpenOutputDirectory();
 UFUNCTION(BlueprintCallable,Category="Image") void SaveQueue();
 UFUNCTION(BlueprintCallable,Category="Image") void SetBackgroundRendering(bool bEnabled);
 UFUNCTION(BlueprintCallable,Category="Draft") FString QueueDraftCamera(AActor* Camera);
 UFUNCTION(BlueprintCallable,Category="Draft") bool RenderDraftCamera(AActor* Camera);
 UFUNCTION(BlueprintCallable,Category="Draft") bool RenderDraftClip(ULevelSequence* Sequence,const FString& Label,int32 Fps,int32 Frames);
 UFUNCTION(BlueprintCallable,Category="Progress") float GetBatchProgress() const;
 UFUNCTION(BlueprintCallable,Category="Progress") float GetEstimatedSecondsRemaining() const;
 UFUNCTION(BlueprintCallable,Category="Progress") FString GetProgressText() const;
private:
 UPROPERTY(Transient) TObjectPtr<UMoviePipelineQueue> ActiveQueue;
 UPROPERTY(Transient) TObjectPtr<UMoviePipelinePIEExecutor> Executor;
 TMap<TWeakObjectPtr<UMoviePipelineExecutorJob>,FString> ActiveJobs;
 TMap<TWeakObjectPtr<UMoviePipelineExecutorJob>,FIntPoint> ActiveRanges;
 TWeakObjectPtr<UMoviePipelineExecutorJob> ExecutingJob;
 TMap<FString,int32> RemainingRanges;
 TSet<FString> FailedRangeJobs;
 FString StatusText;
 bool bTemplatesInitialized=false;
 bool bPreparingRender=false;
 bool bCancelRequested=false;
 bool bBackgroundRendering=false;
 FTSTicker::FDelegateHandle ProgressTickHandle;
 bool TickProgress(float Delta);
 bool MakeDraft(const FString& Id);
 double BatchStart=0,JobStart=0,RateSampleTime=0,SecondsPerFrame=0;
 int32 BatchFrames=0,BatchCompleted=0,RateSampleFrames=0;
 bool BuildJobSequence(FCameraLightingStillJob& Job,AActor* Camera);
 bool PrepareAndRender(const TArray<FString>& JobIds);
 void HandleJobStarted(UMoviePipelineExecutorJob* Job);
 void HandleJobFinished(FMoviePipelineOutputData Data);
 void HandleFinished(UMoviePipelineExecutorBase* InExecutor,bool bSuccess);
 void HandleError(UMoviePipelineExecutorBase*,UMoviePipeline*,bool bFatal,FText Text);
 void LoadQueue();
 void Fail(const FString& Message);
 FCameraLightingStillJob* FindJob(const FString& Id);
};
