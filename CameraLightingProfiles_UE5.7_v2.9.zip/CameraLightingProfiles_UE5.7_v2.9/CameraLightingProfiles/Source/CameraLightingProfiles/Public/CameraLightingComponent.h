// Copyright Hermes. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "CameraLightingProfile.h"
#include "CameraLightingComponent.generated.h"

class UCameraComponent;

/**
 * Attach this to a CameraActor (or any actor with a UCameraComponent).
 * It binds a UCameraLightingProfile to that camera. The CameraLightingSubsystem
 * automatically applies the profile when the camera becomes the active view
 * target (runtime) or when you pilot it in the editor viewport, and restores
 * the previous global lighting state when you switch away.
 */
UCLASS(ClassGroup = (Rendering), meta = (BlueprintSpawnableComponent))
class CAMERALIGHTINGPROFILES_API UCameraLightingComponent : public UActorComponent
{
	GENERATED_BODY()

public:
	UCameraLightingComponent();

	// The lighting profile to apply for this camera.
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Camera Lighting")
	TSoftObjectPtr<UCameraLightingProfile> Profile;

	// When true (default), the subsystem auto-applies on view-target / pilot change.
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Camera Lighting")
	bool bAutoApply = true;

	// Resolve the soft reference (loads if needed). Returns nullptr if unset/invalid.
	UFUNCTION(BlueprintCallable, Category = "Camera Lighting")
	const UCameraLightingProfile* GetResolvedProfile() const;

	// The camera component on the owning actor (or any child), if present.
	UFUNCTION(BlueprintCallable, Category = "Camera Lighting")
	UCameraComponent* GetCameraComponent() const;
};
