// Copyright Hermes. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Containers/Ticker.h"
#include "Engine/EngineTypes.h"
#include "Subsystems/WorldSubsystem.h"
#include "CameraLightingSubsystem.generated.h"

class UCameraLightingComponent;
class UCameraLightingProfile;

/**
 * Watches the active view target each tick. When it changes to an actor that
 * owns a UCameraLightingComponent, that camera's profile is applied to the
 * world. When it changes away, defaults are restored. Runs at runtime.
 */
UCLASS()
class CAMERALIGHTINGPROFILES_API UCameraLightingSubsystem : public UWorldSubsystem
{
	GENERATED_BODY()

public:
	virtual void Initialize(FSubsystemCollectionBase& Collection) override;
	virtual void Deinitialize() override;
	virtual void OnWorldBeginPlay(UWorld& InWorld) override;
	virtual bool DoesSupportWorldType(EWorldType::Type WorldType) const override;

	// Force-apply the profile for a specific camera-bearing actor (e.g. from Blueprint/editor).
	UFUNCTION(BlueprintCallable, Category = "Camera Lighting")
	void ApplyForActor(AActor* CameraActor);

	UFUNCTION(BlueprintCallable, Category = "Camera Lighting")
	void RestoreDefaults();

private:
	bool Tick(float DeltaTime);
	void HandleActiveCameraChanged(AActor* NewViewTarget);

	UPROPERTY()
	TWeakObjectPtr<AActor> CurrentCameraActor;

	// Snapshot of the SkyLight/HDR we last touched, so we can restore. (Lightweight:
	// we restore by re-applying the previous active camera's profile, or defaults.)
	bool bHasApplied = false;

	FTSTicker::FDelegateHandle TickHandle;
};

