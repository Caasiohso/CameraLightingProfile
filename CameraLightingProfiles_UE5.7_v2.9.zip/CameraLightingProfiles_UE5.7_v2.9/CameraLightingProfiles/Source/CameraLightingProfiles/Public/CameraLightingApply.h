// Copyright Hermes. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "CameraLightingProfile.h"

class UWorld;
class UCameraComponent;
class UCameraLightingProfile;
class AActor;

namespace CameraLightingApply
{
	// Apply a full profile to the world. If TargetCamera is provided, the
	// post-process block is bound to that camera (so it only affects its view);
	// if null, post-process is skipped (the editor primarily drives UDS + HDRI).
	void CAMERALIGHTINGPROFILES_API ApplyProfile(UWorld* World, const UCameraLightingProfile* Profile, UCameraComponent* TargetCamera = nullptr);

	// --- Internal, exposed for the editor module ---
	void ApplyUltraDynamicSky(UWorld* World, const FUDSOverride& Override);
	void ApplyHDRI(UWorld* World, const UCameraLightingProfile* Profile);
	void ApplyPostProcess(UCameraComponent* Camera, const UCameraLightingProfile* Profile);

	// Find a candidate UltraDynamicSky actor by class name (no hard dependency).
	CAMERALIGHTINGPROFILES_API AActor* FindUltraDynamicSkyActor(UWorld* World);
}
