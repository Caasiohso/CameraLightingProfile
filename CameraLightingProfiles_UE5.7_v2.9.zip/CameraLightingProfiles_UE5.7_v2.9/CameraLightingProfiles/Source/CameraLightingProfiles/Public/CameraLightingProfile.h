// Copyright Hermes. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Engine/DataAsset.h"
#include "Engine/TextureCube.h"
#include "Engine/Scene.h"
#include "CameraLightingProfile.generated.h"

/**
 * Override block for an UltraDynamicSky actor.
 *
 * Applied via property reflection (not a hard C++ dependency on the UDS plugin),
 * so the plugin compiles and runs even when UDS is absent or renamed. Property
 * names are matched case-sensitively against the live UDS actor; any that are
 * missing are logged and skipped rather than crashing.
 */
USTRUCT(BlueprintType)
struct CAMERALIGHTINGPROFILES_API FUDSOverride
{
	GENERATED_BODY()

	// Master switch for this whole block.
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "UltraDynamicSky")
	bool bOverride = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "UltraDynamicSky", meta = (EditCondition = "bOverride"))
	float SunIntensity = 10.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "UltraDynamicSky", meta = (EditCondition = "bOverride"))
	float MoonIntensity = 2.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "UltraDynamicSky", meta = (EditCondition = "bOverride"))
	float SkyLightIntensity = 3.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "UltraDynamicSky", meta = (EditCondition = "bOverride"))
	float SunElevation = 45.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "UltraDynamicSky", meta = (EditCondition = "bOverride"))
	float SunAzimuth = 135.f;

	// UDS exposes the time-of-day under different names across versions
	// ("Daytime", "Time", "TimeOfDay"). We try each; first hit wins.
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "UltraDynamicSky", meta = (EditCondition = "bOverride"))
	float DaytimeHours = 12.f;
};

/**
 * A reusable, asset-based lighting profile for a single camera.
 * Create one of these (Content Browser -> Right Click -> Miscellaneous -> Data Asset -> CameraLightingProfile)
 * per distinct look you need (e.g. "Exterior_Day", "Interior_Warm", "Night_Cool").
 */
UCLASS(BlueprintType)
class CAMERALIGHTINGPROFILES_API UCameraLightingProfile : public UDataAsset
{
	GENERATED_BODY()

public:
	// --- Post-process grade (exposure, white balance, LUT, bloom, DoF, etc.) ---
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "PostProcess")
	bool bOverridePostProcess = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "PostProcess", meta = (EditCondition = "bOverridePostProcess"))
	FPostProcessSettings PostProcessSettings;

	// --- UltraDynamicSky (sun/moon/skylight/time) ---
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "UltraDynamicSky")
	FUDSOverride UltraDynamicSky;

	// --- HDRI / SkyLight backdrop ---
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "HDRI")
	bool bOverrideHDRI = true;

	// Soft reference so the profile asset doesn't hard-load the cubemap.
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "HDRI", meta = (EditCondition = "bOverrideHDRI"))
	TSoftObjectPtr<UTextureCube> HDRI;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "HDRI", meta = (EditCondition = "bOverrideHDRI"))
	float HDRIIntensity = 1.f;

	// If set, only a SkyLight actor carrying this tag is driven. Otherwise the first SkyLight found wins.
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "HDRI")
	FName SkyLightActorTag = NAME_None;

	// Thumbnail captured from the editor viewport when a profile is created / re-captured.
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Thumbnail")
	TSoftObjectPtr<UTexture2D> PreviewImage;

    // Hard ownership makes the embedded preview part of the serialized asset graph.
    UPROPERTY(VisibleAnywhere, Category = "Thumbnail")
    TObjectPtr<UTexture2D> StoredPreview;

};
