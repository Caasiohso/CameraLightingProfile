// Copyright Hermes. All Rights Reserved.

#include "CameraLightingApply.h"
#include "CameraLightingProfile.h"
#include "CameraLightingComponent.h"

#include "Engine/World.h"
#include "EngineUtils.h"
#include "Engine/SkyLight.h"
#include "Components/SkyLightComponent.h"
#include "Camera/CameraComponent.h"
#include "UObject/UnrealType.h"

DEFINE_LOG_CATEGORY_STATIC(LogCameraLighting, Log, All);

namespace CameraLightingApply
{
	AActor* FindUltraDynamicSkyActor(UWorld* World)
	{
		if (!World)
		{
			return nullptr;
		}
		for (TActorIterator<AActor> It(World); It; ++It)
		{
			AActor* A = *It;
			const FString Name = A->GetClass()->GetName();
			if (Name.Contains(TEXT("UltraDynamicSky")) || Name.Contains(TEXT("UDS")))
			{
				return A;
			}
		}
		return nullptr;
	}

	static bool SetFloatProperty(AActor* Actor, const TCHAR* PropName, float Value)
	{
		if (!Actor)
		{
			return false;
		}
		FProperty* Prop = FindFProperty<FProperty>(Actor->GetClass(), FName(PropName));
		if (!Prop)
		{
			UE_LOG(LogCameraLighting, Warning,
				TEXT("UDS property '%s' not found on class %s (version mismatch?). Skipped."),
				PropName, *Actor->GetClass()->GetName());
			return false;
		}
		FNumericProperty* Num = CastField<FNumericProperty>(Prop);
		if (Num && Num->IsFloatingPoint())
		{
			void* Container = Prop->ContainerPtrToValuePtr<void>(Actor);
			Num->SetFloatingPointPropertyValue(Container, Value);
			return true;
		}
		UE_LOG(LogCameraLighting, Warning,
			TEXT("UDS property '%s' on %s is not a float. Skipped."), PropName, *Actor->GetClass()->GetName());
		return false;
	}

	static void SetTimeOfDay(AActor* Actor, float Hours)
	{
		// Different UDS versions name this differently; first existing wins.
		static const TCHAR* Candidates[] = { TEXT("Daytime"), TEXT("Time"), TEXT("TimeOfDay") };
		for (const TCHAR* Name : Candidates)
		{
			if (SetFloatProperty(Actor, Name, Hours))
			{
				return;
			}
		}
		UE_LOG(LogCameraLighting, Warning,
			TEXT("UDS time-of-day property not found (tried Daytime/Time/TimeOfDay). Skipped."));
	}

	void ApplyUltraDynamicSky(UWorld* World, const FUDSOverride& O)
	{
		if (!O.bOverride)
		{
			return;
		}
		AActor* UDS = FindUltraDynamicSkyActor(World);
		if (!UDS)
		{
			UE_LOG(LogCameraLighting, Warning,
				TEXT("No UltraDynamicSky actor in level; UDS overrides skipped."));
			return;
		}
		SetFloatProperty(UDS, TEXT("SunIntensity"), O.SunIntensity);
		SetFloatProperty(UDS, TEXT("MoonIntensity"), O.MoonIntensity);
		SetFloatProperty(UDS, TEXT("SkyLightIntensity"), O.SkyLightIntensity);
		SetFloatProperty(UDS, TEXT("SunElevation"), O.SunElevation);
		SetFloatProperty(UDS, TEXT("SunAzimuth"), O.SunAzimuth);
		SetTimeOfDay(UDS, O.DaytimeHours);
		UE_LOG(LogCameraLighting, Display, TEXT("Applied UDS overrides to %s."), *UDS->GetName());
	}

	void ApplyHDRI(UWorld* World, const UCameraLightingProfile* Profile)
	{
		if (!Profile || !Profile->bOverrideHDRI)
		{
			return;
		}
		UTextureCube* Cube = Profile->HDRI.LoadSynchronous();
		for (TActorIterator<ASkyLight> It(World); It; ++It)
		{
			ASkyLight* SL = *It;
			if (Profile->SkyLightActorTag != NAME_None && !SL->ActorHasTag(Profile->SkyLightActorTag))
			{
				continue;
			}
			if (USkyLightComponent* Comp = SL->GetLightComponent())
			{
				if (Cube)
				{
					Comp->Cubemap = Cube;
					Comp->SourceType = ESkyLightSourceType::SLS_SpecifiedCubemap;
				}
				Comp->Intensity = Profile->HDRIIntensity;
				Comp->SetCaptureIsDirty();
			}
			SL->MarkComponentsRenderStateDirty();
			UE_LOG(LogCameraLighting, Display, TEXT("Applied HDRI to SkyLight %s."), *SL->GetName());
			return;
		}
		UE_LOG(LogCameraLighting, Warning,
			TEXT("No SkyLight found (tag '%s') to apply HDRI."),
			*Profile->SkyLightActorTag.ToString());
	}

	void ApplyPostProcess(UCameraComponent* Camera, const UCameraLightingProfile* Profile)
	{
		if (!Camera || !Profile || !Profile->bOverridePostProcess)
		{
			return;
		}
		Camera->PostProcessSettings = Profile->PostProcessSettings;
		Camera->PostProcessBlendWeight = 1.f;
		UE_LOG(LogCameraLighting, Display, TEXT("Bound post-process to camera %s."), *Camera->GetName());
	}

	void ApplyProfile(UWorld* World, const UCameraLightingProfile* Profile, UCameraComponent* TargetCamera)
	{
		if (!World || !Profile)
		{
			return;
		}
		ApplyUltraDynamicSky(World, Profile->UltraDynamicSky);
		ApplyHDRI(World, Profile);
		ApplyPostProcess(TargetCamera, Profile);
	}
}
