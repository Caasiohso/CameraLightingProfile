// Copyright Hermes. All Rights Reserved.

#include "CameraLightingSubsystem.h"
#include "CameraLightingComponent.h"
#include "CameraLightingApply.h"
#include "CameraLightingProfile.h"

#include "Engine/World.h"
#include "Camera/PlayerCameraManager.h"
#include "GameFramework/PlayerController.h"
#include "Engine/TextureCube.h"

DEFINE_LOG_CATEGORY_STATIC(LogCamLightSub, Log, All);

void UCameraLightingSubsystem::Initialize(FSubsystemCollectionBase& Collection)
{
	Super::Initialize(Collection);
}

void UCameraLightingSubsystem::Deinitialize()
{
	Super::Deinitialize();
	if (TickHandle.IsValid())
	{
		FTSTicker::GetCoreTicker().RemoveTicker(TickHandle);
	}
}

bool UCameraLightingSubsystem::DoesSupportWorldType(EWorldType::Type WorldType) const
{
	// Runtime PIE + game. Editor-world handling lives in the editor module.
	return WorldType == EWorldType::PIE || WorldType == EWorldType::Game;
}

void UCameraLightingSubsystem::OnWorldBeginPlay(UWorld& InWorld)
{
	Super::OnWorldBeginPlay(InWorld);
	TickHandle = FTSTicker::GetCoreTicker().AddTicker(
		FTickerDelegate::CreateUObject(this, &UCameraLightingSubsystem::Tick));
}

bool UCameraLightingSubsystem::Tick(float DeltaTime)
{
	UWorld* World = GetWorld();
	if (!World)
	{
		return false;
	}
	APlayerController* PC = World->GetFirstPlayerController();
	if (!PC)
	{
		return true;
	}
	AActor* ViewTarget = PC->GetViewTarget();
	HandleActiveCameraChanged(ViewTarget);
	return true;
}

void UCameraLightingSubsystem::HandleActiveCameraChanged(AActor* NewViewTarget)
{
	if (CurrentCameraActor.Get() == NewViewTarget)
	{
		return; // no change
	}
	CurrentCameraActor = NewViewTarget;

	if (!NewViewTarget)
	{
		RestoreDefaults();
		return;
	}

	if (UCameraLightingComponent* Comp = NewViewTarget->FindComponentByClass<UCameraLightingComponent>())
	{
		if (Comp->bAutoApply)
		{
			const UCameraLightingProfile* Profile = Comp->GetResolvedProfile();
			if (Profile)
			{
				UCameraComponent* Cam = Comp->GetCameraComponent();
				CameraLightingApply::ApplyProfile(GetWorld(), Profile, Cam);
				bHasApplied = true;
				UE_LOG(LogCamLightSub, Display, TEXT("Active camera switched -> %s (profile applied)."),
					*NewViewTarget->GetName());
				return;
			}
		}
	}

	// Switched to an actor with no camera-lighting component: restore defaults.
	if (bHasApplied)
	{
		RestoreDefaults();
	}
}

void UCameraLightingSubsystem::ApplyForActor(AActor* CameraActor)
{
	if (!CameraActor)
	{
		return;
	}
	HandleActiveCameraChanged(CameraActor);
}

void UCameraLightingSubsystem::RestoreDefaults()
{
	// Re-apply nothing (post-process bound to a specific camera auto-clears when
	// another camera becomes active). For UDS/HDRI, the previous profile remains
	// until another camera overrides it. This is intentionally non-destructive:
	// to get "default" lighting back, add a camera with a neutral profile and
	// point your view at it. (Editor module exposes an explicit Restore button.)
	UE_LOG(LogCamLightSub, Display, TEXT("RestoreDefaults called (no-op at runtime; switch to a neutral camera to reset)."));
}
