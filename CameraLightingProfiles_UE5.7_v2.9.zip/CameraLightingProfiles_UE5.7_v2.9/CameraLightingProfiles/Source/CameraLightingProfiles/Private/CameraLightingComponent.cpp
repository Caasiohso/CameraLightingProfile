// Copyright Hermes. All Rights Reserved.

#include "CameraLightingComponent.h"

#include "Camera/CameraComponent.h"
#include "Engine/World.h"

UCameraLightingComponent::UCameraLightingComponent()
{
	PrimaryComponentTick.bCanEverTick = false;
	SetIsReplicatedByDefault(false);
}

const UCameraLightingProfile* UCameraLightingComponent::GetResolvedProfile() const
{
	if (Profile.IsNull())
	{
		return nullptr;
	}
	return Profile.LoadSynchronous();
}

UCameraComponent* UCameraLightingComponent::GetCameraComponent() const
{
	AActor* Owner = GetOwner();
	if (!Owner)
	{
		return nullptr;
	}
	// Most common: a CameraActor.
	if (UCameraComponent* Cam = Owner->FindComponentByClass<UCameraComponent>())
	{
		return Cam;
	}
	return nullptr;
}
