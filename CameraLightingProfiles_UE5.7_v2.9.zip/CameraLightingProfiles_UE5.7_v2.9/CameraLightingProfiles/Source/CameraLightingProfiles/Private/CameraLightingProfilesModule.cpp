// Copyright Hermes. All Rights Reserved.

#include "CoreMinimal.h"
#include "Modules/ModuleManager.h"

DEFINE_LOG_CATEGORY_STATIC(LogCamLightRuntime, Log, All);

class FCameraLightingProfilesModule : public IModuleInterface
{
public:
	virtual void StartupModule() override
	{
		UE_LOG(LogCamLightRuntime, Display, TEXT("CameraLightingProfiles runtime module started."));
	}

	virtual void ShutdownModule() override
	{
	}
};

IMPLEMENT_MODULE(FCameraLightingProfilesModule, CameraLightingProfiles);
