// Copyright Hermes. All Rights Reserved.

using UnrealBuildTool;

public class CameraLightingProfiles : ModuleRules
{
	public CameraLightingProfiles(ReadOnlyTargetRules Target) : base(Target)
	{
		PCHUsage = PCHUsageMode.UseExplicitOrSharedPCHs;

		PublicDependencyModuleNames.AddRange(
			new[]
			{
				"Core",
				"CoreUObject",
				"Engine",
				"RenderCore"
			});

		PrivateDependencyModuleNames.AddRange(
			new[]
			{
				"Projects"
			});
	}
}
