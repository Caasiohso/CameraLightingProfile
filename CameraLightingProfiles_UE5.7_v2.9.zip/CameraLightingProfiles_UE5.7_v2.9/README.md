# Camera Lighting Profiles 2.9 - Unreal Engine 5.7

## Changes in 2.9
Clips uses icon buttons for render settings, rendering, draft preview and queue insertion. Choose Image frames, MP4 or MOV directly in Clips; for video, the render icon renders the clip then encodes automatically. Video FPS (0 = clip FPS) and optional audio are available beside the output selector; advanced encoder/destination settings remain in Preflight & Video Delivery.

Artwork reaches the panel edge with no added margin or fill. A persistent project-wide opening counter selects the supplied transparent pear artwork every fifth plugin-panel creation; existing open panels retain their own artwork. Focusing an already open tab does not count as a new opening.

## Previous interface changes
The original black-line portrait retains its transparency with no added backing and is anchored left at full panel height. Clips paints one background layer, Queue now shares it, and the ribbon groups Scenes/Clips/Queue in an outlined, subtly raised frame.

## Rendering features
The supplied portrait artwork is fitted to each panel's full height at its original aspect ratio, anchored to the left. Width changes reveal or crop it horizontally. A subdued overlay keeps controls readable; the PNG itself is unchanged.

**Preflight & Video Delivery** is available from Window, Clips and Render Queue. Preflight checks frozen camera/cuts, exposure differences, renderer readiness, sampling, output permissions and available storage. Blocking errors stop rendering; warnings explain possible differences without changing the scene's look.

**Recover missing** checks every saved frame, groups missing/corrupt frames into ranges and renders those ranges with the job's frozen settings and original destination. Valid existing images stay untouched. Corrupt images are moved to a recovery quarantine with a manifest. Recovery does not restore a prior version of the map, and temporal effects or simulations can differ across restarted ranges. Use **New full render** for a separate complete attempt with a new job ID.

**Export video** combines a rendered clip's images into MP4 or ProRes MOV using a configured local FFmpeg executable. Optional audio is padded/trimmed to clip duration; frame rate can follow the source or be resampled. Sequencer audio is not captured automatically: choose an audio file. Source images are retained, and video errors show the encoder log separately from render status. EXR delivery creates temporary 8-bit SDR PNG copies, with optional Reinhard mapping for linear HDR; retain the original EXRs for grading. FFmpeg is not bundled.

The supplied Windows binaries and demo are verified on UE5.7. Separate source preparation/build tools target UE5.1-5.8, but those other SDKs are not installed here and are not certified. Do not reuse UE5.7 binaries or newer saved demo assets in older engines. See the accompanying source compatibility matrix.

## Install and test
Close Unreal before replacing the plugin. Copy the complete `CameraLightingProfiles` folder into your project's `Plugins` folder. Win64 binaries, precompiled support files, source, Will's base preset and Coolicons attribution are included. Open **RenderStudio29Demo/RenderStudio29Demo.uproject** for the example project.

Open **Window > Scene List, Image Render, Camera, Clips, Render Queue, Render Compare, or Preflight & Video Delivery**. The ribbon contains Scenes, Clips and Queue. The render-template selector has moved into the rendering panels.

## Render controls where you use them
**Scene List** now has a visible render-settings section above its Render button. **Render Queue** has the same section above the job list. Choose a **Render template**, adjust width/height, spatial/temporal sampling and format, or expand **Lighting, bounces & warm-up** for Lumen lighting/reflections, Path Tracer bounces/denoising and native MRQ warm-up. **Full MRQ...** opens the selected template's complete native Movie Render Queue preset. **Edit template...** opens the template asset. Image Render retains the full simplified template editor and its duplicate/save menu.

The Scene List gear opens Image Render. All new one-click jobs use the current settings. In Queue, **Use these MRQ settings for selected waiting jobs** makes Save & Render refresh those jobs' saved configurations before rendering. **Apply now** updates them immediately. Uncheck it to keep each job's frozen configuration. Unselected jobs and completed history are left alone. Draft jobs retain their lightweight sampling, PNG format and size cap.

Will's supplied settings remain the base, with Lumen and Path Tracer variations. Full native preset settings are preserved when creating job snapshots. Save an untitled level before queueing or recording. Queue snapshots freeze camera/lighting, template and clip timing; other scene contents use the saved map at render time.

## Shot timeline and camera editing
Drag camera actors from Unreal's **World Outliner onto the shot track**. Multiple selected cameras become consecutive shots from the drop position; other actor types are ignored. Existing saved-scene selection and capture-from-viewport buttons remain available.

- Drag a shot's body to move it; drag either edge to change its start/end. Overlap edits push later shots forward.
- Click a shot's title/time or right-click for exact Start and Length fields.
- Click its thumbnail/body without dragging to open that camera in the plugin Camera inspector. Captured views without a source actor get an editable Cine Camera. Camera settings are also available in the shot's context menu.
- The inspector exposes aperture, exposure, focus, aspect/crop, lens, sensor and position/rotation controls. Edits update the selected shot's saved snapshot. Moving a recorded camera offsets the entire recorded path, preserving relative movement; changing its base FOV offsets the lens keys.
- Ctrl + wheel on the ruler or shot track zooms around the pointer. Wheel pans; middle/right drag on the ruler pans. Left drag on the ruler scrubs. F or Fit fits the playback range.
- End (s) is independent of zoom and shot positions. It can extend or truncate playback without rescaling shot timing. Gaps hold the preceding shot's last pose; before the first shot its first pose is held.
- Export copy to Sequencer creates an independent native sequence for advanced work.

Clips remain perspective-camera image-sequence workflows. Camera crop can also match shared output dimensions; clip frames use the explicit shared output size. Existing pre-2.4 motion clips retain their continuous motion and original native sequence backup.

## Record viewport movement
Set **Record FPS** (1-120), then press **Record viewport**. Navigate the perspective viewport normally. Recording releases camera piloting so you can move freely. The red status displays elapsed time and captured samples.

**Stop recording** creates a new clip group and a real Cine Camera saved with the level. The take contains fixed-rate position, rotation and FOV keys. Its camera appears in Scene List and the World Outliner. Click its shot to edit it with the same camera inspector. Save the level to keep the new camera. **Discard** cancels without creating a take or actor. Recording stops automatically after ten minutes.

The interpolation dropdown edits the selected shot and supplies the setting for the next take:

- **Linear:** straight interpolation between keys.
- **Smooth:** zero-tangent cubic easing between keys.
- **Constant:** hold a key's value until the next key.

Preview and generated native Sequencer tracks use the same interpolation. Recording uses editor-time viewport samples rather than Play/Simulate. If the editor falls below the requested FPS, intermediate samples interpolate the observed poses. Clip FPS can be changed independently for output; drag-trimming the shot retimes its saved path across the new length.

## Composition and appearance
Camera > Composition guides now offers thirds, center, safe areas, crop frame, golden ratio, diagonals, golden triangle, golden spiral, horizon, square 1:1 and cinema 2.39 guides. These editor overlays are not baked into output. Focus picking and optional Cine actor tracking remain available.

The abstract line artwork uses a single uniform scale and keeps its square design proportions, anchored to the available corner. It no longer stretches with window width/height independently. Icons use Coolicons vectors; the Scene List render-settings shortcut uses a gear. Main UI text uses the installed Roxbyte font with default-font fallback; no font file is redistributed.

## Existing rendering and review tools
One-click still rendering, mixed still/clip batches, draft renders, progress/ETA, A/B wipe comparison, native camera tools and full template editing remain available. Draft output caps the long edge at 960 pixels. Render Compare loads PNG/JPEG/EXR, uses preview-only EV, and tone maps EXR with Reinhard for display. ETA is approximate. Clip rendering produces image sequences; MP4 encoding is not included.

Templates: `/Game/CameraLightingTemplates`; clips: `/Game/CameraLightingClips`; camera profiles: `/Game/CameraLightingProfiles`; queued snapshots: `/Game/CameraLightingRenders`; history: `Saved/CameraLightingRenders/queue-history.json`.

See V26-verification.md and JSON results for the checks performed. Tests use hidden offscreen Unreal editors without desktop input automation. Hardware Path Tracer output is not validated on this machine.
